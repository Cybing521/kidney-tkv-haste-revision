import json
d=json.load(open('/Users/cyibin/Documents/first-year/docx/11.18/小六/02_工作/服务器/revision_r1_stats.json'))
print('keys', list(d.keys()))
print('BUDGET haste')
for b,e in d['chaos_budget']['haste_init'].items():
    print(' ',b,{k:e[k] for k in ('n_folds','median_of_fold_medians','fold_medians','fold_mae','n_train_scans_per_fold','labelled_scans_total_per_fold')})
print('BUDGET resample')
for b,e in d['chaos_budget']['resample_haste'].items():
    print(' ',b,{k:e[k] for k in ('n_folds','median_of_fold_medians','fold_medians')})
print('BUDGET scratch')
for b,e in d['chaos_budget']['scratch'].items():
    print(' ',b,{k:e[k] for k in ('n_folds','median_of_fold_medians','fold_medians','fold_mae')})
