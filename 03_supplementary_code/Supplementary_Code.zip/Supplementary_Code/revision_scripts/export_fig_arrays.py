#!/usr/bin/env python3
"""Export overlay arrays WITH image for figure re-render + polar FP stats."""
from __future__ import annotations
import json, sys
from pathlib import Path
import numpy as np
from scipy import ndimage
import torch
import torch.nn.functional as F

ROOT = Path("/root/autodl-tmp/ckd_t2mri_morphometry")
sys.path.insert(0, str(ROOT/"scripts"))
from train import _build_model, resize2d

OUT = ROOT/"runs_rev2026"; (OUT/"overlay_arrays").mkdir(parents=True, exist_ok=True)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
m = _build_model("unetpp").to(device)
ck = torch.load(ROOT/"runs/unetpp/best.pt", map_location="cpu", weights_only=False)
m.load_state_dict(ck["model"]); m.eval()

def predict(npz_path):
    with np.load(npz_path) as z:
        img, gt, sp = z["image"], z["mask"] > 0, z["spacing"]
    axis = int(np.argmin(img.shape)); sl = np.moveaxis(img, axis, 0)
    outs = []
    with torch.no_grad():
        for i in range(sl.shape[0]):
            x = torch.from_numpy(resize2d(sl[i], 256)[None, None]).to(device)
            pr = F.interpolate(torch.sigmoid(m(x)[0]), size=sl[i].shape, mode="bilinear", align_corners=False)
            outs.append(pr[0, 0].cpu().numpy())
    return (np.moveaxis(np.stack(outs, 0), 0, axis).astype(np.float32), gt, sp, img.astype(np.float32))

# --- Fig4 panels ---
meta = json.loads((ROOT/"runs/unetpp/fig_overlay_nottingham.json").read_text())
saved = {}
for panel in ("A", "B", "C", "D_E_F"):
    sid = meta["panels"][panel]["scan_id"]
    prob, gt, sp, img = predict(ROOT/"data/npz"/f"{sid}.npz")
    np.savez_compressed(OUT/"overlay_arrays"/f"{panel}_{sid}.npz", prob=prob, gt=gt, spacing=sp, image=img)
    saved[panel] = sid

# --- Fig6: CHAOS case nearest mean Dice (recompute from existing rows) ---
rows = json.loads((ROOT/"runs/unetpp/chaos_rows.json").read_text())
mean_dice = float(np.mean([r["dice"] for r in rows]))
best = min(rows, key=lambda r: abs(r["dice"]-mean_dice))
sid = best["scan_id"]
prob, gt, sp, img = predict(ROOT/"data/chaos_npz"/f"{sid}.npz")
np.savez_compressed(OUT/"overlay_arrays"/f"F_{sid}.npz", prob=prob, gt=gt, spacing=sp, image=img)
saved["F"] = sid
saved["F_dice"] = best["dice"]

# --- CHAOS component audit (with components per case) ---
ch = []
for r in rows:
    p2, g2, s2, _ = predict(ROOT/"data/chaos_npz"/f"{r['scan_id']}.npz")
    pred = p2 > 0.5
    ch.append({"scan_id": r["scan_id"], "dice": r["dice"],
               "n_comp_pred": int(ndimage.label(pred)[1]),
               "gt_tkv": r["gt"]["tkv_ml"], "pred_tkv": r["pr"]["tkv_ml"]})
chaos_audit = {
    "n": len(ch),
    "dice_median": float(np.median([c["dice"] for c in ch])),
    "n_comp_pred_median": float(np.median([c["n_comp_pred"] for c in ch])),
    "n_comp_pred_max": int(max(c["n_comp_pred"] for c in ch)),
    "n_comp_min": int(min(c["n_comp_pred"] for c in ch)),
    "n_zero_or_one_comp": int(sum(c["n_comp_pred"] <= 1 for c in ch)),
}
(OUT/"chaos_audit.json").write_text(json.dumps({**chaos_audit, "rows": ch}, indent=2))

# --- polar / mid FP volume descriptive stats ---
pb = json.loads((ROOT/"runs/novelty/protocol_boundary.json").read_text())
prows = pb["haste_polar"]["rows"]
def desc(vals):
    v = np.array([x for x in vals if x is not None], float)
    return {"n": int(len(v)), "mean": float(v.mean()), "sd": float(v.std(ddof=0)),
            "median": float(np.median(v)), "q25": float(np.percentile(v, 25)), "q75": float(np.percentile(v, 75))}
polar_stats = {
    "polar_dice": desc([r.get("dice_polar") for r in prows if r.get("dice_polar") is not None]),
    "mid_dice": desc([r.get("dice_mid") for r in prows]),
    "polar_fp_ml": desc([r.get("polar_fp_ml") for r in prows]),
    "mid_fp_ml": desc([r.get("mid_fp_ml") for r in prows]),
    "polar_fn_ml": desc([r.get("polar_fn_ml") for r in prows]),
    "n_polar_slices_total": int(sum(r.get("n_polar", 0) for r in prows)),
    "n_mid_slices_total": int(sum(r.get("n_mid", 0) for r in prows)),
    "n_scans_without_polar": int(sum(1 for r in prows if not r.get("dice_polar"))),
    "corr_polar_fp_abs_tkv": pb["haste_polar"]["summary"].get("corr_abs_tkv_polar_fp"),
}
(OUT/"polar_stats.json").write_text(json.dumps(polar_stats, indent=2))
print(json.dumps({"saved": saved, "chaos": chaos_audit, "polar": polar_stats}, indent=2))
