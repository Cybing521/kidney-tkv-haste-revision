import json
d=json.load(open('/Users/cyibin/Documents/first-year/docx/11.18/小六/00_历史交付/肾病_医工交叉_delivery/数据/处理后/protocol_boundary.json'))
print(list(d.keys()))
print(json.dumps(d['haste_polar']['summary'], indent=1))
print('POLAR ROWS sample', json.dumps(d['haste_polar'].get('rows',[])[:2], indent=1)[:800])
