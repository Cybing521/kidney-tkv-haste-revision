import numpy as np, glob, os
for p in sorted(glob.glob('/Users/cyibin/Documents/first-year/docx/11.18/小六/02_工作/服务器/overlay_arrays/*.npz')):
    z=np.load(p); print(os.path.basename(p), list(z.keys()), z['image'].shape if 'image' in z else None)
