#!/usr/bin/env python3
"""Revision addendum analyses for R1.4/R1.5/R1.2/R1.3 (rerun on project server)."""
from __future__ import annotations
import json, sys, itertools
from pathlib import Path
import numpy as np
from scipy import ndimage
import torch
import torch.nn.functional as F

ROOT = Path("/root/autodl-tmp/ckd_t2mri_morphometry")
sys.path.insert(0, str(ROOT / "scripts"))
from train import _build_model, resize2d  # noqa: E402

OUT = ROOT / "runs_rev2026"
OUT.mkdir(exist_ok=True)
res = {}

# ---------- 1. fold reproduction check ----------
def make_folds(scans, seed=42, k=5):
    from collections import defaultdict
    by = defaultdict(list); cohort = {}
    for r in scans:
        by[r["subject"]].append(r["scan_id"]); cohort[r["subject"]] = r["cohort"]
    repeat = sorted(s for s, ids in by.items() if len(ids) >= 5)
    singles = sorted(s for s in by if s not in set(repeat))
    hc = [s for s in singles if s.startswith("HC")]; ckd = [s for s in singles if s.startswith("CKD")]
    rng = np.random.RandomState(seed); rng.shuffle(hc); rng.shuffle(ckd)
    folds = []
    for f in range(k):
        te = sorted(hc[f*5:(f+1)*5] + ckd[f*5:(f+1)*5])
        rest = [s for s in singles if s not in set(te)]
        rh = sorted(s for s in rest if s.startswith("HC")); rc = sorted(s for s in rest if s.startswith("CKD"))
        val = sorted(rh[:4] + rc[:4]); tr = sorted(set(rest) - set(val))
        folds.append({"fold": f, "test_subjects": te, "val_subjects": val, "train_subjects": tr})
    return folds, repeat

scans = json.loads((ROOT/"data/scans.json").read_text())
folds, repeat_subj = make_folds(scans)
check = {}
for f in folds:
    rows = json.loads((ROOT/f"runs_cv5/fold{f['fold']}/unetpp/test_rows.json").read_text())
    got = sorted({r["subject"] for r in rows})
    check[f"fold{f['fold']}"] = {"reproduced": got == f["test_subjects"], "n_scan": len(rows)}
res["fold_reproduction"] = check

# ---------- 2. CoV bootstrap CI (R1.4) ----------
def cov_ci(model_dir, n_boot=10000, seed=42):
    rows = json.loads((Path(model_dir)/"test_rows.json").read_text())
    by = {}
    for r in rows:
        by.setdefault(r["subject"], []).append(r["pr"]["tkv_ml"])
    subj_cov, subj_mae = [], []
    for s, v in by.items():
        v = np.array(v, float)
        subj_cov.append(v.std(ddof=1)/v.mean())
        subj_mae.append(np.mean([r["tkv_abs_ml"] for r in rows if r["subject"] == s]))
    cov = np.array(subj_cov); mae = np.array(subj_mae)
    rng = np.random.RandomState(seed)
    boots = np.array([cov[rng.randint(0, len(cov), len(cov))].mean() for _ in range(n_boot)])
    bmae = np.array([mae[rng.randint(0, len(mae), len(mae))].mean() for _ in range(n_boot)])
    # manual CoV (GT volumes) per subject
    mt = {}
    for r in rows:
        mt.setdefault(r["subject"], []).append(r["gt"]["tkv_ml"])
    man = np.array([np.std(v, ddof=1)/np.mean(v) for v in mt.values()])
    return {
        "n_subjects": int(len(cov)),
        "cov_mean": float(cov.mean()), "cov_sd": float(cov.std(ddof=1)),
        "cov_median": float(np.median(cov)),
        "cov_min": float(cov.min()), "cov_max": float(cov.max()),
        "cov_ci95_bootstrap": [float(np.percentile(boots, 2.5)), float(np.percentile(boots, 97.5))],
        "manual_cov_mean": float(man.mean()), "manual_cov_sd": float(man.std(ddof=1)),
        "subject_mae_mean": float(mae.mean()),
        "subject_mae_ci95": [float(np.percentile(bmae, 2.5)), float(np.percentile(bmae, 97.5))],
        "per_subject_cov": {s: float(c) for s, c in zip(by.keys(), cov)},
    }

res["cov_ci"] = {m: cov_ci(ROOT/f"runs/{m}") for m in ("unet", "attunet", "unetpp")}

# ---------- 3. CHAOS label budget: per-fold sensitivity + annotation counts (R1.2/R1.3) ----------
ladder = json.loads((ROOT/"runs/novelty/chaos_ladder.json").read_text())
scratch = json.loads((ROOT/"runs/novelty/chaos_ladder_scratch.json").read_text())
resample = json.loads((ROOT/"runs/novelty/chaos_ladder_resample.json").read_text())

def per_fold(entries, key=lambda e: str(e["budget"])):
    out = {}
    for e in entries:
        out.setdefault(key(e), []).append(e)
    agg = {}
    for b, es in out.items():
        med = [e["metrics"]["dice_median"] for e in es]
        mae = [e["metrics"]["tkv_mae_ml"] for e in es]
        mean = [e["metrics"]["dice_mean"] for e in es]
        ntrain = [len(e.get("train_ids") or []) for e in es]
        nval = [len(set(e.get("val_ids") or [])) for e in es]
        agg[b] = {
            "n_folds": len(es),
            "median_of_fold_medians": float(np.median(med)),
            "fold_medians": [float(x) for x in med],
            "fold_medians_min": float(np.min(med)), "fold_medians_max": float(np.max(med)),
            "fold_mean_dice": [float(x) for x in mean],
            "fold_mae": [round(float(x), 1) for x in mae],
            "mae_fold_min": float(np.min(mae)), "mae_fold_max": float(np.max(mae)),
            "n_train_scans_per_fold": ntrain,
            "n_val_scans_per_fold": nval,
            "labelled_scans_total_per_fold": [t + v + 4 for t, v in zip(ntrain, nval)],
        }
    return agg

res["chaos_budget"] = {
    "haste_init": per_fold(ladder),
    "scratch": per_fold(scratch),
    "resample_haste": per_fold(resample),
}
res["chaos_annotation_requirement"] = {
    "n_exam_labelled_total": 20,
    "per_fold": {"train": "k (budget)", "val_checkpoint_selection": 4, "test": 4},
    "note": "pool = 16 exams; for k=1 and k=4, 4 pool exams are held for checkpoint Dice and are not in the k labelled training draws; k=16 uses the whole 16-exam pool as training and selects the checkpoint on training Dice",
}

# ---------- 4. GPU: threshold sensitivity + connected-component audit (R1.5) ----------
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

def load_model(name, ckpt):
    m = _build_model(name).to(device)
    ck = torch.load(ckpt, map_location="cpu", weights_only=False)
    m.load_state_dict(ck["model"]); m.eval(); return m

def predict_prob(model, npz_path, thr=0.5):
    with np.load(npz_path) as z:
        img, gt, sp = z["image"], z["mask"] > 0, z["spacing"]
    axis = int(np.argmin(img.shape))
    sl = np.moveaxis(img, axis, 0)
    probs = []
    with torch.no_grad():
        for i in range(sl.shape[0]):
            x = torch.from_numpy(resize2d(sl[i], 256)[None, None]).to(device)
            logit = model(x)[0]
            pr = F.interpolate(torch.sigmoid(logit), size=sl[i].shape, mode="bilinear", align_corners=False)
            probs.append(pr[0, 0].cpu().numpy())
    prob = np.moveaxis(np.stack(probs, 0), 0, axis)
    return prob, gt, sp

def tkv_from_mask(mask, sp):
    return float(mask.sum() * np.prod(sp) / 1000.0)

def clean2(mask):
    lab, n = ndimage.label(mask)
    if n <= 2:
        return mask
    sizes = ndimage.sum(mask, lab, index=list(range(1, n+1)))
    keep = np.argsort(sizes)[::-1][:2] + 1
    return np.isin(lab, keep)

split = json.loads((ROOT/"data/split.json").read_text())
test_ids = split["scans"]["test"]
model = load_model("unetpp", ROOT/"runs/unetpp/best.pt")

thr_grid = [0.3, 0.4, 0.5, 0.6, 0.7]
thr_rows = {t: {"dice": [], "tkv_abs": [], "tkv_signed": []} for t in thr_grid}
comp_rows = []
for sid in test_ids:
    p = ROOT/"data/npz"/f"{sid}.npz"
    prob, gt, sp = predict_prob(model, p)
    gt_tkv = tkv_from_mask(gt, sp)
    for t in thr_grid:
        pred = prob > t
        d = (2*float((pred & gt).sum()) + 1e-6)/(pred.sum()+gt.sum()+1e-6)
        pt = tkv_from_mask(pred, sp)
        thr_rows[t]["dice"].append(d); thr_rows[t]["tkv_abs"].append(abs(pt-gt_tkv)); thr_rows[t]["tkv_signed"].append(pt-gt_tkv)
    # component audit at 0.5
    pred = prob > 0.5
    lab_p, np_ = ndimage.label(pred); lab_g, ng_ = ndimage.label(gt)
    sizes_p = np.sort(ndimage.sum(pred, lab_p, index=list(range(1, np_+1))))[::-1] if np_ else np.array([])
    tkv_raw = tkv_from_mask(pred, sp)
    pred_c = clean2(pred)
    tkv_clean = tkv_from_mask(pred_c, sp)
    comp_rows.append({
        "scan_id": sid,
        "n_components_pred": int(np_),
        "n_components_gt": int(ng_),
        "largest_frac": float(sizes_p[0]/sizes_p.sum()) if np_ else 0.0,
        "top2_frac": float(sizes_p[:2].sum()/sizes_p.sum()) if np_ else 1.0,
        "discarded_volume_ml": float(tkv_raw - tkv_clean),
        "tkv_raw_ml": tkv_raw, "tkv_clean_ml": tkv_clean, "gt_tkv_ml": gt_tkv,
        "abs_err_raw": abs(tkv_raw-gt_tkv), "abs_err_clean": abs(tkv_clean-gt_tkv),
        "dice_raw": (2*float((pred & gt).sum())+1e-6)/(pred.sum()+gt.sum()+1e-6),
        "dice_clean": (2*float((pred_c & gt).sum())+1e-6)/(pred_c.sum()+gt.sum()+1e-6),
    })

res["threshold_sensitivity"] = {str(t): {
    "n": len(v["dice"]),
    "dice_mean": float(np.mean(v["dice"])), "dice_sd": float(np.std(v["dice"])),
    "tkv_mae": float(np.mean(v["tkv_abs"])),
    "tkv_bias": float(np.mean(v["tkv_signed"])),
} for t, v in thr_rows.items()}

arr = lambda k: np.array([r[k] for r in comp_rows], float)
res["component_audit_cov_split"] = {
    "n_scans": len(comp_rows),
    "n_comp_pred_mean": float(arr("n_components_pred").mean()),
    "n_comp_pred_median": float(np.median(arr("n_components_pred"))),
    "n_comp_pred_max": int(arr("n_components_pred").max()),
    "n_scans_gt_gt2": int((arr("n_components_gt") > 2).sum()),
    "n_scans_pred_gt2": int((arr("n_components_pred") > 2).sum()),
    "n_scans_pred_gt10": int((arr("n_components_pred") > 10).sum()),
    "top2_frac_mean": float(arr("top2_frac").mean()),
    "top2_frac_median": float(np.median(arr("top2_frac"))),
    "top2_frac_min": float(arr("top2_frac").min()),
    "discarded_volume_ml_mean": float(arr("discarded_volume_ml").mean()),
    "discarded_volume_ml_max": float(arr("discarded_volume_ml").max()),
    "tkv_mae_raw": float(arr("abs_err_raw").mean()),
    "tkv_mae_clean": float(arr("abs_err_clean").mean()),
    "dice_raw_mean": float(arr("dice_raw").mean()),
    "dice_clean_mean": float(arr("dice_clean").mean()),
    "scans_discard_gt5ml": int((arr("discarded_volume_ml") > 5).sum()),
    "per_scan": comp_rows,
}

# CHAOS component + threshold audit
chaos_npz = ROOT/"data/chaos_npz"
chaos_ids = sorted(p.stem for p in chaos_npz.glob("*.npz")) if chaos_npz.exists() else []
if chaos_ids:
    ch = []
    for sid in chaos_ids:
        prob, gt, sp = predict_prob(model, chaos_npz/f"{sid}.npz")
        gt_tkv = tkv_from_mask(gt, sp)
        for t in (0.5,):
            pred = prob > t
            ch.append({"scan_id": sid, "dice": (2*float((pred&gt).sum())+1e-6)/(pred.sum()+gt.sum()+1e-6),
                       "n_comp_pred": int(ndimage.label(pred)[1]), "gt_frac": float(gt_tkv/gt.size)})
    res["chaos_component_audit"] = {
        "n": len(ch),
        "n_comp_pred_median": float(np.median([c["n_comp_pred"] for c in ch])),
        "n_zero_pred": int(sum(c["n_comp_pred"] == 0 for c in ch)),
        "dice_median": float(np.median([c["dice"] for c in ch])),
        "per_scan": ch,
    }

# ---------- 5. export overlay arrays for figure re-render ----------
fig_dir = OUT/"overlay_arrays"; fig_dir.mkdir(exist_ok=True)
ovl_meta = json.loads((ROOT/"runs/unetpp/fig_overlay_nottingham.json").read_text())
for panel in ("A", "B", "C", "D_E_F"):
    sid = ovl_meta["panels"][panel]["scan_id"]
    prob, gt, sp = predict_prob(model, ROOT/"data/npz"/f"{sid}.npz")
    np.savez_compressed(fig_dir/f"{panel}_{sid}.npz", prob=prob.astype(np.float32), gt=gt, spacing=sp)
res["overlay_export"] = {p: ovl_meta["panels"][p]["scan_id"] for p in ("A", "B", "C", "D_E_F")}

(OUT/"revision_r1_stats.json").write_text(json.dumps(res, indent=2))
print(json.dumps({k: res[k] for k in ("fold_reproduction", "chaos_annotation_requirement")}, indent=2))
print("OK ->", OUT/"revision_r1_stats.json")
