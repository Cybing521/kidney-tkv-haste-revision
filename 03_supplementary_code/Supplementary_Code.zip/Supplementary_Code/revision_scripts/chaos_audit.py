#!/usr/bin/env python3
"""CHAOS component/threshold audit + Fig6 overlay export (follow-up)."""
from __future__ import annotations
import json, sys
from pathlib import Path
import numpy as np
from scipy import ndimage
import torch
import torch.nn.functional as F

ROOT = Path("/root/autodl-tmp/ckd_t2mri_morphometry")
sys.path.insert(0, str(ROOT/"scripts"))
from train import _build_model, resize2d

OUT = ROOT/"runs_rev2026"; OUT.mkdir(exist_ok=True)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
m = _build_model("unetpp").to(device)
ck = torch.load(ROOT/"runs/unetpp/best.pt", map_location="cpu", weights_only=False)
m.load_state_dict(ck["model"]); m.eval()

def predict_prob(npz_path):
    with np.load(npz_path) as z:
        img, gt, sp = z["image"], z["mask"] > 0, z["spacing"]
    axis = int(np.argmin(img.shape)); sl = np.moveaxis(img, axis, 0)
    outs = []
    with torch.no_grad():
        for i in range(sl.shape[0]):
            x = torch.from_numpy(resize2d(sl[i], 256)[None, None]).to(device)
            pr = F.interpolate(torch.sigmoid(m(x)[0]), size=sl[i].shape, mode="bilinear", align_corners=False)
            outs.append(pr[0, 0].cpu().numpy())
    return np.moveaxis(np.stack(outs, 0), 0, axis), gt, sp

def clean2(mask):
    lab, n = ndimage.label(mask)
    if n <= 2: return mask
    sizes = ndimage.sum(mask, lab, index=list(range(1, n+1)))
    keep = np.argsort(sizes)[::-1][:2] + 1
    return np.isin(lab, keep)

tkv = lambda mk, sp: float(mk.sum()*np.prod(sp)/1000.0)
npz = ROOT/"data/chaos_npz"
ids = sorted(p.stem for p in npz.glob("*.npz"))
rows = []
for sid in ids:
    prob, gt, sp = predict_prob(npz/f"{sid}.npz")
    pred = prob > 0.5
    lab_p, np_ = ndimage.label(pred)
    gt_tkv, pr_tkv = tkv(gt, sp), tkv(pred, sp)
    rows.append({"scan_id": sid, "dice": (2*float((pred&gt).sum())+1e-6)/(pred.sum()+gt.sum()+1e-6),
                 "n_comp_pred": int(np_), "gt_tkv": gt_tkv, "pred_tkv": pr_tkv,
                 "abs_err": abs(pr_tkv-gt_tkv)})
summary = {
    "n": len(rows),
    "dice_median": float(np.median([r["dice"] for r in rows])),
    "n_comp_pred_median": float(np.median([r["n_comp_pred"] for r in rows])),
    "n_comp_pred_max": int(max(r["n_comp_pred"] for r in rows)),
    "n_zero_or_one_comp": int(sum(r["n_comp_pred"] <= 1 for r in rows)),
    "pred_over_gt_ratio_median": float(np.median([r["pred_tkv"]/(r["gt_tkv"]+1e-6) for r in rows])),
    "tkv_mae": float(np.mean([r["abs_err"] for r in rows])),
    "mean_gt_tkv": float(np.mean([r["gt_tkv"] for r in rows])),
    "rows": rows,
}
(OUT/"chaos_audit.json").write_text(json.dumps(summary, indent=2))

# Fig 6 overlay array: case nearest the 20-exam mean Dice
mean_dice = float(np.mean([r["dice"] for r in rows]))
best = min(rows, key=lambda r: abs(r["dice"]-mean_dice))
prob, gt, sp = predict_prob(npz/f"{best['scan_id']}.npz")
np.savez_compressed(OUT/"overlay_arrays"/f"F_{best['scan_id']}.npz", prob=prob.astype(np.float32), gt=gt, spacing=sp)
summary["fig6_scan"] = best["scan_id"]; summary["fig6_dice"] = best["dice"]
(OUT/"chaos_audit.json").write_text(json.dumps(summary, indent=2))
print(json.dumps({k: v for k, v in summary.items() if k != "rows"}, indent=2))
