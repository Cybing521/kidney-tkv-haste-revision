"""Fig. 2  (A) polar-slice Dice vs scan Dice, (B) CHAOS intensity-matched vs zero-shot.

Data
----
A  protocol_boundary.json :: haste_polar.rows[*].dice / .dice_polar   (n=50, 46 finite)
   protocol_boundary.json :: haste_polar.summary.dice_polar_mean      (0.6021)
B  protocol_boundary.json :: chaos_factors.native.rows[*].dice
                              chaos_factors.hist_match.rows[*].dice    (n=20 paired)
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import _style as S  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402

ROOT = HERE.parents[1]
DATA = ROOT / "00_历史交付/肾病_医工交叉_delivery/数据/处理后/protocol_boundary.json"

S.apply_style()


def line_label(ax, x, y, text, dx_pt=0.0, dy_pt=0.0, ha="left", va="top",
               color=S.GREY, fontsize=S.ANNOT):
    """Rotated label anchored on the identity line at data (x, y).

    The rotation is taken from the real display slope, so a non-square axes
    (panel A: 145 x 1.02 data units) does not tilt the label off the line.
    """
    p0 = ax.transData.transform((x, y))
    p1 = ax.transData.transform((x + 1e-3, y + 1e-3))
    ang = np.degrees(np.arctan2(p1[1] - p0[1], p1[0] - p0[0]))
    ax.annotate(text, xy=(x, y), xytext=(dx_pt, dy_pt), textcoords="offset points",
                rotation=ang, rotation_mode="anchor", ha=ha, va=va,
                fontsize=fontsize, color=color, zorder=6)


def load():
    d = json.loads(DATA.read_text())
    rows = d["haste_polar"]["rows"]
    scan = np.array([r["dice"] for r in rows], float)
    polar = np.array([r["dice_polar"] for r in rows], float)
    fin = np.isfinite(polar)
    polar_mean = float(d["haste_polar"]["summary"]["dice_polar_mean"])

    nat = {r["scan_id"]: r["dice"] for r in d["chaos_factors"]["native"]["rows"]}
    his = {r["scan_id"]: r["dice"] for r in d["chaos_factors"]["hist_match"]["rows"]}
    keys = sorted(set(nat) & set(his))
    assert len(keys) == 20, len(keys)
    x = np.array([nat[k] for k in keys])
    y = np.array([his[k] for k in keys])
    return scan[fin], polar[fin], polar_mean, x, y


def main():
    scan, polar, polar_mean, xz, ym = load()
    fig = plt.figure(figsize=(S.W_DOUBLE, 80 * S.MM))
    gs = fig.add_gridspec(1, 2, left=0.085, right=0.985, bottom=0.155, top=0.915, wspace=0.30)
    axA = fig.add_subplot(gs[0, 0])
    axB = fig.add_subplot(gs[0, 1])

    # ---------------- A ----------------
    axA.plot([0.84, 1.0], [0.84, 1.0], color=S.GREY, lw=0.8, ls=(0, (3.5, 2.2)), zorder=1)
    axA.axhline(polar_mean, color=S.BRICK, lw=0.9, ls=(0, (1.2, 1.8)), zorder=1)
    axA.scatter(scan, polar, s=13, color=S.BLUE, edgecolors="white", linewidths=0.25, zorder=3)
    axA.set_xlim(0.855, 1.0)
    axA.set_ylim(-0.02, 1.0)
    axA.set_xticks([0.86, 0.88, 0.90, 0.92, 0.94, 0.96, 0.98, 1.00])
    axA.set_yticks([0.0, 0.2, 0.4, 0.6, 0.8, 1.0])
    axA.set_xlabel("Scan Dice")
    axA.set_ylabel("Polar-slice Dice")
    line_label(axA, 0.952, 0.940, "identity", dx_pt=-1.0, dy_pt=-1.5)
    axA.text(0.985, 0.045, "n = 46 of 50 scans", transform=axA.transAxes,
             ha="right", va="bottom", fontsize=S.ANNOT, color=S.TEXT)
    axA.text(0.862, polar_mean + 0.045, "mean polar Dice 0.60", fontsize=S.ANNOT,
             color=S.BRICK, ha="left", va="bottom")
    S.panel_letter(axA, "A")

    # ---------------- B ----------------
    hi = float(np.ceil(max(xz.max(), ym.max()) * 10) / 10 + 0.05)
    axB.plot([0, hi], [0, hi], color=S.GREY, lw=0.8, ls=(0, (3.5, 2.2)), zorder=1)
    axB.scatter(xz, ym, s=13, color=S.BRICK, edgecolors="white", linewidths=0.25, zorder=3)
    axB.set_xlim(0, hi)
    axB.set_ylim(0, hi)
    axB.set_xlabel("Zero-shot Dice")
    axB.set_ylabel("Intensity-matched Dice")
    axB.set_aspect("equal", adjustable="box")
    axB.text(0.97, 0.045, "n = 20 exams", transform=axB.transAxes,
             ha="right", va="bottom", fontsize=S.ANNOT, color=S.TEXT)
    axB.text(0.03, 0.955, "median 0.07 vs 0.10", transform=axB.transAxes,
             ha="left", va="top", fontsize=S.ANNOT, color=S.TEXT)
    line_label(axB, 0.46, 0.475, "identity", dx_pt=1.5, dy_pt=-1.0)
    S.panel_letter(axB, "B")

    S.save_figure(fig, HERE / "Fig2_polar_Dice")
    print("ok Fig2", len(scan), "finite polar; mean", round(polar_mean, 4), "| chaos n", len(xz), "hi", hi)


if __name__ == "__main__":
    main()