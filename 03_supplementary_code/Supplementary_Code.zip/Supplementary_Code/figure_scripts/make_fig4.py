"""Fig. 4  HASTE overlays, rebuilt for R1.7 (red/green fill hid the error).

Three columns per panel so that contour agreement and error are separable:
(i) MRI + expert contour (blue solid) + automatic contour (brick dashed), no fill;
(ii) false positives (brick, alpha 0.55) and false negatives (blue, alpha 0.55)
     over a pale MRI for anatomical context;
(iii) P(kidney) grayscale map.

Panels A-C: first-repeat scan nearest each cohort median Dice (HC_28_r1,
CKD_27_r1) and the lowest-Dice test scan (CKD_27_r5), displayed at the slice
with the largest expert area, so both kidneys are visible.
Panels D-F: HC_29_r3 (largest |TKV error|), slices 2 / 5 / 10 from
fig_overlay_nottingham.json (panels.D_E_F.slice_indices, axis=2).

Data: 02_工作/服务器/overlay_arrays/{A,B,C,D_E_F}_*.npz (prob, gt, spacing, image)
      00_历史交付/.../fig_overlay_nottingham.json (panel metrics)
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import _style as S  # noqa: E402
import _overlay as O  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402

ROOT = HERE.parents[1]
NPZ = ROOT / "02_工作/服务器/overlay_arrays"
META = ROOT / "00_历史交付/肾病_医工交叉_delivery/数据/处理后/fig_overlay_nottingham.json"

S.apply_style()

SIZE = 26.6          # mm, square image
GAP_IN = 1.0         # mm between the three columns of one panel
GAP_PANEL = 3.6      # mm between the two panels of a row
LEFT = 4.0
ROW_PITCH_EXTRA = 9.6  # caption block + inter-row gap below each image
HEADER = 5.6
LEGEND = 7.0
FIG_W = 180.0
FIG_H = HEADER + 3 * (SIZE + ROW_PITCH_EXTRA) + LEGEND + 2.4

PANEL_ORDER = [["A", "B"], ["C", "D"], ["E", "F"]]


def panel_specs():
    meta = json.loads(META.read_text())["panels"]
    a = meta["A"]
    b = meta["B"]
    c = meta["C"]
    d = meta["D_E_F"]
    return {
        "A": dict(file="A_HC_28_r1", sid=a["scan_id"], dice=a["dice"], tkv=a["tkv_abs_ml"],
                  z=None, zname="slice with largest expert area"),
        "B": dict(file="B_CKD_27_r1", sid=b["scan_id"], dice=b["dice"], tkv=b["tkv_abs_ml"],
                  z=None, zname="slice with largest expert area"),
        "C": dict(file="C_CKD_27_r5", sid=c["scan_id"], dice=c["dice"], tkv=c["tkv_abs_ml"],
                  z=None, zname="slice with largest expert area"),
        "D": dict(file="D_E_F_HC_29_r3", sid=d["scan_id"], dice=d["dice"], tkv=d["tkv_abs_ml"],
                  z=d["slice_indices"][0], zname="inferior pole"),
        "E": dict(file="D_E_F_HC_29_r3", sid=d["scan_id"], dice=d["dice"], tkv=d["tkv_abs_ml"],
                  z=d["slice_indices"][1], zname="mid-pole"),
        "F": dict(file="D_E_F_HC_29_r3", sid=d["scan_id"], dice=d["dice"], tkv=d["tkv_abs_ml"],
                  z=d["slice_indices"][2], zname="superior pole"),
    }


def main():
    specs = panel_specs()
    fig = plt.figure(figsize=(FIG_W * S.MM, FIG_H * S.MM))
    cached = {}
    im_for_cb = None
    for r, row in enumerate(PANEL_ORDER):
        y_img = FIG_H - HEADER - (r + 1) * (SIZE + ROW_PITCH_EXTRA) + ROW_PITCH_EXTRA
        for c, letter in enumerate(row):
            spec = specs[letter]
            if spec["file"] not in cached:
                cached[spec["file"]] = O.load_npz(NPZ / f"{spec['file']}.npz")
            img, gt, prob, _ = cached[spec["file"]]
            nz = img.shape[2]
            z = spec["z"] if spec["z"] is not None else int(np.argmax(gt.reshape(-1, nz).sum(0)))
            x0 = LEFT + c * (3 * SIZE + 2 * GAP_IN + GAP_PANEL)
            im, _ = O.draw_columns(fig, x0, y_img, SIZE,
                                   img[:, :, z], gt[:, :, z], prob[:, :, z])
            im_for_cb = im

            # caption
            cap_y1 = y_img - 3.9
            cap_y2 = y_img - 6.9
            fig.text((x0 + 4.6) / FIG_W, cap_y1 / FIG_H,
                     f"{spec['sid']} · Dice {spec['dice']:.3f}",
                     fontsize=6.6, color=S.TEXT, ha="left", va="center")
            fig.text((x0 + 4.6) / FIG_W, cap_y2 / FIG_H,
                     f"|ΔTKV| {spec['tkv']:.1f} mL · slice {z}/{nz - 1} ({spec['zname']})",
                     fontsize=6.2, color=S.GREY, ha="left", va="center")
            fig.text((x0 - 0.4) / FIG_W, cap_y1 / FIG_H, letter,
                     fontsize=S.LETTER, fontweight="bold", color=S.TEXT,
                     ha="right", va="center")

    # column headers above the first row, repeated over both three-column blocks
    xs = [LEFT + i * (SIZE + GAP_IN) for i in range(3)]
    O.column_headers(fig, xs, FIG_H - HEADER + 1.0, SIZE)
    xs_right = [x + 3 * SIZE + 2 * GAP_IN + GAP_PANEL for x in xs]
    O.column_headers(fig, xs_right, FIG_H - HEADER + 1.0, SIZE)
    O.add_colorbar(fig, im_for_cb, 175.0, FIG_H - HEADER - SIZE, 2.0, SIZE)
    O.legend_row(fig, LEFT, 2.8)

    S.save_figure(fig, HERE / "Fig4_HASTE_overlay")
    print("wrote Fig4", FIG_W, "x", round(FIG_H, 1), "mm")


if __name__ == "__main__":
    main()