"""Fig. 1  Two-arm vector flow diagram of the study.

Arm A  coronal T2-HASTE (Nottingham, public): 100 scans -> U-Net++ trained on 42,
       checkpoint picked on 8 -> same-session repeat scans (10 participants x 5 = 50)
       -> polar / mid-kidney slice maps -> TKV error across 50 participants (OOF, 21-23 mL).

Arm B  axial T2-SPIR (CHAOS, public): 20 examinations, no target labels used ->
       zero-shot Dice 0.070 / 227 mL -> intensity matching only, Dice 0.098 (p = 0.12)
       -> labelled target scans 0/1/4/16 -> Dice 0.070/0.72/0.83/0.90,
       TKV error 227/120/92/46 mL.

Every number is taken from the files named in FIGURE_NOTES.md; the two thumbnails
are real MRI slices from the overlay exports (coronal HASTE, axial T2-SPIR).
All text is wrapped with a renderer-measured width so nothing can overflow a box
or the page.

Data: 00_历史交付/肾病_医工交叉_delivery/数据/处理后/{protocol_boundary.json,
      chaos_ladder.json, chaos_ladder_resample.json, oof_mae_distribution.json}
      02_工作/服务器/overlay_arrays/{A_HC_28_r1,F_chaos_t2_5}.npz
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import _style as S  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch  # noqa: E402

ROOT = HERE.parents[1]
DATA = ROOT / "00_历史交付/肾病_医工交叉_delivery/数据/处理后"
NPZ = ROOT / "02_工作/服务器/overlay_arrays"

S.apply_style()

W = 180.0
H = 116.0

IMG_X, IMG_SIZE = 4.0, 19.5
COL_A = (28.0, 71.0)   # x0, width
COL_B = (105.0, 71.0)
BOX_H = 13.4
ROW_Y = [94.4, 76.4, 58.4, 40.4, 22.4]


def mm_to_px(fig, mm):
    return mm / 25.4 * fig.dpi


def wrap_mm(fig, text, max_mm, fontsize, weight="normal"):
    """Wrap by measured text width, so a box edge can never be crossed.

    Explicit newlines in *text* are kept as hard breaks.
    """
    if not text:
        return []
    renderer = fig.canvas.get_renderer()
    out = []
    for para in str(text).split("\n"):
        words = para.split(" ")
        lines, cur = [], ""
        for word in words:
            trial = (cur + " " + word).strip()
            t = fig.text(0.0, 0.0, trial, fontsize=fontsize, fontweight=weight)
            wid = t.get_window_extent(renderer=renderer).width / fig.dpi * 25.4
            t.remove()
            if wid > max_mm and cur:
                lines.append(cur)
                cur = word
            else:
                cur = trial
        if cur:
            lines.append(cur)
        out.extend(lines)
    return out


def rounded(ax, x, y, w, h, fc, ec, lw=0.7, z=2):
    ax.add_patch(FancyBboxPatch((x, y), w, h,
                                boxstyle="round,pad=0,rounding_size=1.1",
                                linewidth=lw, edgecolor=ec, facecolor=fc, zorder=z,
                                mutation_aspect=1.0))


def box(fig, ax, x, y, w, h, title, detail="", kind="mid"):
    face = {"src": S.TINT_BLUE, "mid": "white", "out": S.TINT_BRICK}[kind]
    edge = {"src": S.BLUE, "mid": S.GREY, "out": S.BRICK}[kind]
    lw = {"src": 0.75, "mid": 0.6, "out": 0.85}[kind]
    rounded(ax, x, y, w, h, face, edge, lw)
    tx = x + 3.0
    inner = w - 6.0
    lines_t = wrap_mm(fig, title, inner, 6.9)
    lines_d = wrap_mm(fig, detail, inner, 6.1)
    t_t = ax.text(tx, 0.0, "\n".join(lines_t), fontsize=6.9, color=S.TEXT,
                  ha="left", va="bottom", linespacing=1.16, zorder=3)
    t_d = ax.text(tx, 0.0, "\n".join(lines_d), fontsize=6.1, color=S.GREY,
                  ha="left", va="bottom", linespacing=1.15, zorder=3)
    fig.canvas.draw()
    r = fig.canvas.get_renderer()
    ht = t_t.get_window_extent(r).height / fig.dpi * 25.4
    hd = t_d.get_window_extent(r).height / fig.dpi * 25.4
    gap = 1.05
    y0 = y + (h - (ht + gap + hd)) / 2
    t_d.set_position((tx, y0))
    t_t.set_position((tx, y0 + hd + gap))


def arrow(ax, x, y0, y1):
    ax.add_patch(FancyArrowPatch((x, y0), (x, y1), arrowstyle="-|>", mutation_scale=5.2,
                                 linewidth=0.7, color=S.GREY, shrinkA=0, shrinkB=0, zorder=1))


def stack(fig, ax, col, rows, specs):
    x0, w = col
    xc = x0 + w / 2
    for i, (y, spec) in enumerate(zip(rows, specs)):
        box(fig, ax, x0, y, w, BOX_H, spec[0], spec[1], spec[2])
        if i + 1 < len(specs):
            arrow(ax, xc, y - 0.2, rows[i + 1] + BOX_H + 0.2)


def thumb(ax, x, y, size, image, z, vmin, vmax):
    a = ax.inset_axes([x, y, size, size], transform=ax.transData)
    a.imshow(image[:, :, z], cmap="gray", vmin=vmin, vmax=vmax,
             origin="upper", interpolation="bilinear", aspect="equal")
    a.set_xticks([])
    a.set_yticks([])
    for sp in a.spines.values():
        sp.set_visible(True)
        sp.set_color("#B4B4B4")
        sp.set_linewidth(0.45)
    return a


def load_npz(name):
    with np.load(NPZ / name) as z:
        img = z["image"].astype(np.float32)
        gt = z["gt"].astype(bool)
    lo, hi = np.percentile(img, [0.6, 99.6])
    return img, gt, float(lo), float(hi)


def main():
    imgA, gtA, loA, hiA = load_npz("A_HC_28_r1.npz")
    imgB, gtB, loB, hiB = load_npz("F_chaos_t2_5.npz")
    zA = int(np.argmax(gtA.reshape(-1, gtA.shape[2]).sum(0)))
    zB = int(np.argmax(gtB.reshape(-1, gtB.shape[2]).sum(0)))

    # numbers read straight from the result files
    pb = json.loads((DATA / "protocol_boundary.json").read_text())
    lad0 = json.loads((DATA / "chaos_ladder.json").read_text())
    lad1 = json.loads((DATA / "chaos_ladder_resample.json").read_text())
    med0 = float(np.median([r["dice"] for rec in lad0 if rec["budget"] == 0 for r in rec["rows"]]))
    mae0 = float(np.mean([r["tkv_abs_ml"] for rec in lad0 if rec["budget"] == 0 for r in rec["rows"]]))
    ladder = [(0, med0, mae0)]
    for b in (1, 4, 16):
        dice = [r["dice"] for rec in lad1 if rec["budget"] == b for r in rec["rows"]]
        mae = [r["tkv_abs_ml"] for rec in lad1 if rec["budget"] == b for r in rec["rows"]]
        ladder.append((b, float(np.median(dice)), float(np.mean(mae))))
    oof = json.loads((DATA / "oof_mae_distribution.json").read_text())
    oof_means = [oof[m]["mean_ml"] for m in ("unet", "attunet", "unetpp")]
    mae_range = f"{min(oof_means):.0f}\u2013{max(oof_means):.0f}"
    dice_str = " / ".join(f"{v:.2f}" for _, v, _ in ladder)
    mae_str = " / ".join(f"{v:.0f}" for _, _, v in ladder)

    fig = plt.figure(figsize=(W * S.MM, H * S.MM))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, W)
    ax.set_ylim(0, H)
    ax.axis("off")
    fig.canvas.draw()

    # ---------------- headers ----------------
    for letter, x, title in (
        ("A", COL_A[0], "Same-session repeatability on coronal T2-HASTE"),
        ("B", COL_B[0], "Cross-protocol transfer to axial T2-SPIR"),
    ):
        ax.text(x, 110.0, letter, fontsize=S.LETTER, fontweight="bold", color=S.TEXT,
                ha="left", va="center")
        ax.text(x + 4.6, 110.0, title, fontsize=7.9, color=S.TEXT, ha="left", va="center")

    # ---------------- arm A ----------------
    stack(fig, ax, COL_A, ROW_Y, [
        ("100 public coronal T2-HASTE scans",
         "Nottingham archive, 1.5 \u00d7 1.5 \u00d7 5.0\u20135.5 mm voxels, expert whole-kidney masks", "src"),
        ("U-Net++ trained on 42 scans",
         "drawn from the 50 single-scan participants; 8 of them choose the checkpoint. "
         "The 50 repeat scans are test-only", "mid"),
        ("Same-session repeat scans",
         "10 participants \u00d7 5 scans = 50 scans, each traced by an expert", "mid"),
        ("Slice-level maps",
         "polar and mid-kidney views compared with the expert masks", "mid"),
        ("TKV error across 50 participants",
         f"mean absolute error {mae_range} mL (five-fold out-of-fold)", "out"),
    ])

    # ---------------- arm B ----------------
    stack(fig, ax, COL_B, ROW_Y, [
        ("20 axial T2-SPIR examinations",
         "public CHAOS training set, five folds \u00d7 four held out; no target label "
         "used for the zero-shot pass", "src"),
        ("Zero-shot U-Net++",
         "median kidney Dice 0.070; TKV error 227 mL", "mid"),
        ("Intensity matching only",
         "median Dice 0.098 (paired change +0.006, p = 0.12)", "mid"),
        ("Labelled target scans: 0 / 1 / 4 / 16",
         f"median Dice {dice_str}\nTKV error {mae_str} mL", "out"),
    ])

    # ---------------- example images ----------------
    thumb(ax, IMG_X, 89.4, IMG_SIZE, imgA, zA, loA, hiA)
    ax.text(IMG_X + IMG_SIZE / 2, 87.4, "coronal T2-HASTE", fontsize=5.9, color=S.TEXT,
            ha="center", va="center")
    ax.text(IMG_X + IMG_SIZE / 2, 85.0, f"slice {zA + 1}/{imgA.shape[2]}", fontsize=5.4,
            color=S.GREY, ha="center", va="center")

    thumb(ax, IMG_X, 55.0, IMG_SIZE, imgB, zB, loB, hiB)
    ax.text(IMG_X + IMG_SIZE / 2, 53.0, "axial T2-SPIR", fontsize=5.9, color=S.TEXT,
            ha="center", va="center")
    ax.text(IMG_X + IMG_SIZE / 2, 50.6, f"slice {zB + 1}/{imgB.shape[2]}", fontsize=5.4,
            color=S.GREY, ha="center", va="center")

    # ---------------- footnote ----------------
    notes = [
        "Dice, overlap of the whole-kidney mask with the expert mask (1 = perfect). TKV, total kidney volume. "
        "Values are means unless a median is stated.",
        "Out-of-fold: every participant is scored by a network trained without that participant. TKV error is the "
        "absolute difference from the expert volume, in millilitres.",
        "Arm B budgets 1 / 4 / 16 draw the labelled examinations independently in each of five folds; at 16 labels "
        "the checkpoint is chosen on training Dice because no validation split is left.",
    ]
    y = 12.8
    for note in notes:
        for line in wrap_mm(fig, note, 172.0, 6.0):
            ax.text(4.0, y, line, fontsize=6.0, color=S.GREY, ha="left", va="center")
            y -= 3.1

    S.save_figure(fig, HERE / "Fig1_study_flow")
    print(f"Fig1 {W} x {H} mm | zA {zA} zB {zB} | OOF {[round(v, 2) for v in oof_means]} | "
          f"ladder {[(b, round(d, 3), round(m, 1)) for b, d, m in ladder]} | footnote lines {y:.1f}")


if __name__ == "__main__":
    main()