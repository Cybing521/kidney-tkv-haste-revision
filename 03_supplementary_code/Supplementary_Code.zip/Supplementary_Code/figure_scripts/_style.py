"""Shared publication style for the R1 figure re-render (Frontiers, 2026-11).

Hard rules implemented here
---------------------------
* Arial / Helvetica sans-serif only (project rule: no Times / serif).
* Widths: double column 180 mm, single column 90 mm (exact PDF page width).
* Fonts: ticks 7.5 pt, axis titles 9 pt, panel letters 10 pt bold.
* Palette: blue #4A7BA7, brick #B5523C, orange #D08A4E, grey #8C8C8C,
  reference line #D0D0D0, text #3A3A3A.  No saturated rainbow colours.
* Every figure is exported as vector PDF + 600 dpi PNG on white, no frame.
"""
from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import rcParams

MM = 1.0 / 25.4
W_DOUBLE = 180.0 * MM   # 7.087 in
W_SINGLE = 90.0 * MM    # 3.543 in

BLUE = "#4A7BA7"
BRICK = "#B5523C"
ORANGE = "#D08A4E"
GREY = "#8C8C8C"
REF = "#D0D0D0"
TEXT = "#3A3A3A"

# light tints used for fills in the flow diagram (alpha handled separately)
TINT_BLUE = "#E9EFF5"
TINT_BRICK = "#F6E7E3"
TINT_GREY = "#F2F2F2"
TINT_ORANGE = "#F8EFE4"

# 5-step sequential ramp for fold-resolved points (blue family, no rainbow)
FOLD_RAMP = ["#123A5A", "#2E5F84", "#4A7BA7", "#7EA3C2", "#B0C6D8"]
FOLD_MARKERS = ["o", "s", "^", "D", "v"]

TICK = 7.5
LABEL = 9.0
LETTER = 10.0
ANNOT = 7.0
LEGEND = 7.0


def apply_style() -> None:
    rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans"],
            "font.size": TICK,
            "axes.unicode_minus": False,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "axes.labelsize": LABEL,
            "axes.titlesize": LABEL,
            "xtick.labelsize": TICK,
            "ytick.labelsize": TICK,
            "legend.fontsize": LEGEND,
            "axes.linewidth": 0.7,
            "axes.edgecolor": TEXT,
            "axes.labelcolor": TEXT,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "xtick.color": TEXT,
            "ytick.color": TEXT,
            "xtick.major.width": 0.7,
            "ytick.major.width": 0.7,
            "xtick.minor.width": 0.6,
            "ytick.minor.width": 0.6,
            "xtick.major.size": 2.6,
            "ytick.major.size": 2.6,
            "xtick.minor.size": 1.4,
            "ytick.minor.size": 1.4,
            "xtick.direction": "out",
            "ytick.direction": "out",
            "lines.linewidth": 1.0,
            "lines.solid_capstyle": "round",
            "text.color": TEXT,
            "legend.frameon": False,
            "legend.handlelength": 1.4,
            "legend.handletextpad": 0.5,
            "legend.labelspacing": 0.3,
            "legend.borderaxespad": 0.2,
            "figure.facecolor": "white",
            "axes.facecolor": "white",
            "savefig.facecolor": "white",
            "axes.grid": False,
            "mathtext.fontset": "custom",
            "mathtext.rm": "Arial",
            "mathtext.it": "Arial:italic",
            "mathtext.bf": "Arial:bold",
            "mathtext.default": "regular",
        }
    )


def panel_letter(ax, letter: str, x: float = -0.16, y: float = 1.03) -> None:
    """10 pt bold panel letter, anchored in axes coordinates."""
    ax.text(
        x,
        y,
        letter,
        transform=ax.transAxes,
        fontsize=LETTER,
        fontweight="bold",
        ha="left",
        va="bottom",
        color=TEXT,
        clip_on=False,
    )


def save_figure(fig, outbase: Path, png_dpi: int = 600) -> None:
    """Exact-size vector PDF + high-dpi PNG (no tight bbox: width stays 180/90 mm)."""
    outbase = Path(outbase)
    outbase.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(str(outbase) + ".pdf", format="pdf")
    fig.savefig(str(outbase) + ".png", format="png", dpi=png_dpi)
    plt.close(fig)


def style_axes(ax, grid_axis: str | None = None) -> None:
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    if grid_axis:
        ax.grid(True, axis=grid_axis, color=REF, linewidth=0.5, alpha=0.8, zorder=0)
        ax.set_axisbelow(True)
