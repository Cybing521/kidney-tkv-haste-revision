"""Fig. 3  CHAOS annotation-budget ladder, fold-resolved (answers R1.3 subset sensitivity).

Points: every held-out examination of every fold (5 folds x 4 exams = 20 per budget).
Thin lines: the 5 fold medians. Thick line: pooled median.
Budget 0 comes from chaos_ladder.json (zero-shot, tag zero_shot); budgets 1/4/16 from
chaos_ladder_resample.json (independent draws, the main ladder).
At 16 labels the checkpoint was selected on training Dice (no validation split left).

Data: 00_历史交付/.../chaos_ladder.json, chaos_ladder_resample.json
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import _style as S  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.lines import Line2D  # noqa: E402

ROOT = HERE.parents[1]
DATA = ROOT / "00_历史交付/肾病_医工交叉_delivery/数据/处理后"
BUDGETS = [0, 1, 4, 16]
JITTER = 0.155

S.apply_style()


def load():
    zero = json.loads((DATA / "chaos_ladder.json").read_text())
    res = json.loads((DATA / "chaos_ladder_resample.json").read_text())
    per_budget = {b: [] for b in BUDGETS}  # list of (fold, dice, mae)
    for rec in zero:
        if rec["budget"] == 0:
            for r in rec["rows"]:
                per_budget[0].append((rec["fold"], r["dice"], r["tkv_abs_ml"]))
    for rec in res:
        for r in rec["rows"]:
            per_budget[rec["budget"]].append((rec["fold"], r["dice"], r["tkv_abs_ml"]))
    for b in BUDGETS:
        assert len(per_budget[b]) == 20, (b, len(per_budget[b]))
    return per_budget


def strip(ax, per_budget, idx, ylabel, ylim=None):
    rng = np.random.default_rng(7)
    fold_med = {}
    pooled = []
    for i, b in enumerate(BUDGETS):
        rows = per_budget[b]
        y = np.array([r[idx] for r in rows], float)
        folds = np.array([r[0] for r in rows])
        pooled.append(float(np.median(y)))
        for f in range(5):
            fold_med[(b, f)] = float(np.median(y[folds == f]))
        for f in range(5):
            m = folds == f
            x = i + JITTER * 0.65 * rng.uniform(-1, 1, m.sum())
            ax.scatter(x, y[m], s=11, color=S.FOLD_RAMP[f], marker=S.FOLD_MARKERS[f],
                       edgecolors="white", linewidths=0.25, zorder=3)
    for f in range(5):
        ax.plot(range(len(BUDGETS)), [fold_med[(b, f)] for b in BUDGETS],
                color=S.GREY, lw=0.6, alpha=0.55, zorder=2)
    ax.plot(range(len(BUDGETS)), pooled, color=S.BRICK, lw=1.5, zorder=4)
    ax.scatter(range(len(BUDGETS)), pooled, s=26, marker="D", color=S.BRICK,
               edgecolors="white", linewidths=0.5, zorder=5)
    ax.set_xticks(range(len(BUDGETS)), ["0", "1", "4", "16*"])
    ax.set_xlim(-0.45, len(BUDGETS) - 0.55)
    ax.set_xlabel("CHAOS examinations in the labelled training pool")
    ax.set_ylabel(ylabel)
    if ylim:
        ax.set_ylim(*ylim)


def main():
    per_budget = load()
    fig = plt.figure(figsize=(S.W_DOUBLE, 92 * S.MM))
    gs = fig.add_gridspec(1, 2, left=0.078, right=0.988, bottom=0.215, top=0.945, wspace=0.26)
    axA = fig.add_subplot(gs[0, 0])
    axB = fig.add_subplot(gs[0, 1])

    strip(axA, per_budget, 1, "Held-out kidney Dice", ylim=(-0.03, 1.03))
    axA.set_yticks([0.0, 0.2, 0.4, 0.6, 0.8, 1.0])
    axA.text(0.03, 0.955, "n = 20 held-out examinations per budget", transform=axA.transAxes,
             fontsize=S.ANNOT, color=S.TEXT, ha="left", va="top")
    S.panel_letter(axA, "A")

    mae_max = max(r[2] for b in BUDGETS for r in per_budget[b])
    strip(axB, per_budget, 2, "Held-out TKV MAE (mL)", ylim=(0, np.ceil(mae_max / 50) * 50 + 20))
    S.panel_letter(axB, "B")

    handles = [
        Line2D([], [], color=S.BRICK, lw=1.5, marker="D", ms=3.4, mec="white", mew=0.4,
               label="pooled median"),
        Line2D([], [], color=S.GREY, lw=0.7, alpha=0.8, label="per-fold median"),
        Line2D([], [], color=S.FOLD_RAMP[2], lw=0, marker="o", ms=3.2, mec="white", mew=0.3,
               label="held-out examination (5 folds)"),
    ]
    fig.legend(handles=handles, loc="lower left", bbox_to_anchor=(0.072, 0.012),
               ncol=3, frameon=False, fontsize=S.LEGEND, handlelength=1.8, columnspacing=2.0)
    fig.text(0.072, 0.086,
             "* 16-label checkpoints selected on training Dice (no validation split left)",
             fontsize=6.4, color=S.GREY, ha="left", va="center")

    S.save_figure(fig, HERE / "Fig3_CHAOS_label_budget")
    for b in BUDGETS:
        d = [r[1] for r in per_budget[b]]
        m = [r[2] for r in per_budget[b]]
        print(f"budget {b:>2}: pooled median Dice {np.median(d):.4f} | median MAE {np.median(m):.1f} | n {len(d)}")


if __name__ == "__main__":
    main()