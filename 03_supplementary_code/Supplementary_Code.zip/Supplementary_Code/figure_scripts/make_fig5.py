"""Fig. 5  TKV agreement on the 50 same-session repeat scans (R1.4, R1.7).

A  automatic vs expert TKV, identity line, HC blue / CKD brick, n = 50 scans
   (10 participants x 5 repeats; participants are not independent here).
B  Bland-Altman of the same 50 scans: bias +1.8 mL, 1.96 SD = 28.5 mL
   (limits -26.7 to +30.3 mL), HC +10.0 mL, CKD -6.5 mL.  The panel says
   explicitly that this is repeat-scan dispersion, not a 95% interval for
   independent patients.
C  per-participant CoV (10 participants), mean 1.86% with the bootstrap 95% CI
   1.47-2.26% as a band, and the manual-tracing CoV 2.65% as a reference line.

Data: 00_历史交付/.../数据/处理后/unetpp_test_rows.json  (gt.tkv_ml, pr.tkv_ml,
      cohort, subject, repeat)
      02_工作/服务器/revision_r1_stats.json :: cov_ci.unetpp
      (cov_mean, cov_ci95_bootstrap, per_subject_cov, manual_cov_mean)
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import _style as S  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.lines import Line2D  # noqa: E402

ROOT = HERE.parents[1]
DATA = ROOT / "00_历史交付/肾病_医工交叉_delivery/数据/处理后"
STATS = ROOT / "02_工作/服务器/revision_r1_stats.json"

S.apply_style()

W, H = 180.0, 84.0


def wrap_mm(fig, text, max_mm, fontsize):
    renderer = fig.canvas.get_renderer()
    lines, cur = [], ""
    for word in text.split(" "):
        trial = (cur + " " + word).strip()
        t = fig.text(0.0, 0.0, trial, fontsize=fontsize)
        wid = t.get_window_extent(renderer=renderer).width / fig.dpi * 25.4
        t.remove()
        if wid > max_mm and cur:
            lines.append(cur)
            cur = word
        else:
            cur = trial
    if cur:
        lines.append(cur)
    return lines


def ax_at(fig, x, y, w, h):
    return fig.add_axes([x / W, y / H, w / W, h / H])


def load():
    rows = json.loads((DATA / "unetpp_test_rows.json").read_text())
    expert = np.array([r["gt"]["tkv_ml"] for r in rows], float)
    auto = np.array([r["pr"]["tkv_ml"] for r in rows], float)
    cohort = np.array([r["cohort"] for r in rows])
    subject = np.array([r["subject"] for r in rows])
    stats = json.loads(STATS.read_text())["cov_ci"]["unetpp"]
    return expert, auto, cohort, subject, stats


def scatter_cohort(ax, x, y, cohort, size=14, marker_map=None):
    blue = cohort == "hc"
    brick = cohort == "ckd"
    mk = marker_map or {"hc": "o", "ckd": "s"}
    ax.scatter(x[blue], y[blue], s=size, marker=mk["hc"], color=S.BLUE,
               edgecolors="white", linewidths=0.3, zorder=3, label="HC")
    ax.scatter(x[brick], y[brick], s=size, marker=mk["ckd"], color=S.BRICK,
               edgecolors="white", linewidths=0.3, zorder=3, label="CKD")


def main():
    expert, auto, cohort, subject, stats = load()
    diff = auto - expert
    mean_tkv = 0.5 * (auto + expert)

    bias = float(diff.mean())
    sd = float(diff.std(ddof=1))
    loa = 1.96 * sd
    bias_hc = float(diff[cohort == "hc"].mean())
    bias_ckd = float(diff[cohort == "ckd"].mean())
    # guard the manuscript numbers
    assert abs(bias - 1.8) < 0.06, bias
    assert abs(loa - 28.5) < 0.1, loa
    assert abs(bias_hc - 10.0) < 0.06, bias_hc
    assert abs(bias_ckd + 6.5) < 0.06, bias_ckd

    cov_mean = 100 * float(stats["cov_mean"])
    ci_lo, ci_hi = (100 * float(v) for v in stats["cov_ci95_bootstrap"])
    manual_cov = 100 * float(stats["manual_cov_mean"])
    assert abs(cov_mean - 1.86) < 0.01 and abs(ci_lo - 1.47) < 0.02 and abs(ci_hi - 2.26) < 0.02

    fig = plt.figure(figsize=(W * S.MM, H * S.MM))

    # ---------------- A : agreement ----------------
    axA = ax_at(fig, 12.0, 19.0, 54.0, 54.0)
    lo = float(min(expert.min(), auto.min())) - 25
    hi = float(max(expert.max(), auto.max())) + 25
    axA.plot([lo, hi], [lo, hi], color=S.GREY, lw=0.8, ls=(0, (3.6, 2.2)), zorder=1)
    scatter_cohort(axA, expert, auto, cohort)
    axA.set_xlim(lo, hi)
    axA.set_ylim(lo, hi)
    axA.set_aspect("equal", adjustable="box")
    axA.set_xticks([200, 250, 300, 350, 400, 450])
    axA.set_yticks([200, 250, 300, 350, 400, 450])
    axA.set_xlabel("Expert TKV (mL)")
    axA.set_ylabel("Automatic TKV (mL)")
    axA.text(0.035, 0.955, "n = 50 scans\n10 participants \u00d7 5 repeats", transform=axA.transAxes,
             ha="left", va="top", fontsize=S.ANNOT, color=S.TEXT, linespacing=1.25)
    axA.text(398.0, 356.0, "identity", rotation=45.0, rotation_mode="anchor",
             ha="left", va="top", fontsize=S.ANNOT, color=S.GREY, zorder=4)
    axA.legend(loc="lower right", bbox_to_anchor=(0.985, 0.10), fontsize=S.LEGEND,
               handletextpad=0.4, labelspacing=0.35, borderaxespad=0.0, markerscale=1.0)
    fig.text(6.0 / W, 80.4 / H, "A", fontsize=S.LETTER, fontweight="bold", color=S.TEXT, ha="left", va="center")

    # ---------------- B : Bland-Altman ----------------
    axB = ax_at(fig, 77.0, 19.0, 54.0, 54.0)
    axB.axhspan(bias - loa, bias + loa, color=S.GREY, alpha=0.10, lw=0, zorder=0)
    axB.axhline(0.0, color=S.REF, lw=0.7, zorder=1)
    axB.axhline(bias, color=S.BRICK, lw=1.2, zorder=2)
    for y in (bias - loa, bias + loa):
        axB.axhline(y, color=S.GREY, lw=0.8, ls=(0, (3.2, 2.2)), zorder=2)
    scatter_cohort(axB, mean_tkv, diff, cohort)
    axB.set_xlim(lo, hi)
    axB.set_ylim(-46, 46)
    axB.set_xticks([200, 250, 300, 350, 400, 450])
    axB.set_yticks([-40, -20, 0, 20, 40])
    axB.set_xlabel("Mean TKV (mL)")
    axB.set_ylabel("Automatic \u2212 expert (mL)")
    axB.text(0.035, 0.955,
             f"bias +{bias:.1f} mL\n\u00b11.96 SD = \u00b1{loa:.1f} mL",
             transform=axB.transAxes, ha="left", va="top", fontsize=S.ANNOT,
             color=S.TEXT, linespacing=1.3)
    axB.text(0.035, 0.775,
             f"limits {bias - loa:.1f} to +{bias + loa:.1f} mL".replace("-", "\u2212"),
             transform=axB.transAxes, ha="left", va="top", fontsize=6.4, color=S.GREY)
    axB.text(0.985, 0.045,
             f"HC +{bias_hc:.1f} mL\nCKD \u2212{abs(bias_ckd):.1f} mL",
             transform=axB.transAxes, ha="right", va="bottom", fontsize=S.ANNOT,
             color=S.TEXT, linespacing=1.3)
    fig.text(71.0 / W, 80.4 / H, "B", fontsize=S.LETTER, fontweight="bold", color=S.TEXT, ha="left", va="center")

    # ---------------- C : per-participant CoV ----------------
    axC = ax_at(fig, 144.0, 19.0, 33.5, 54.0)
    subs = sorted(stats["per_subject_cov"])
    hc = [s for s in subs if s.startswith("HC")]
    ckd = [s for s in subs if s.startswith("CKD")]
    xs, ys, cs = [], [], []
    for i, s in enumerate(hc):
        xs.append(0.6 + i * 0.95)
        ys.append(100 * stats["per_subject_cov"][s])
        cs.append("hc")
    for i, s in enumerate(ckd):
        xs.append(5.85 + i * 0.95)
        ys.append(100 * stats["per_subject_cov"][s])
        cs.append("ckd")
    xs = np.array(xs)
    ys = np.array(ys)
    cs = np.array(cs)

    axC.axhspan(ci_lo, ci_hi, color=S.BRICK, alpha=0.16, lw=0, zorder=0)
    axC.axhline(cov_mean, color=S.BRICK, lw=1.3, zorder=2)
    axC.axhline(manual_cov, color=S.GREY, lw=0.9, ls=(0, (3.0, 2.0)), zorder=2)
    for grp, col, mk in (("hc", S.BLUE, "o"), ("ckd", S.BRICK, "s")):
        m = cs == grp
        axC.scatter(xs[m], ys[m], s=17, marker=mk, color=col, edgecolors="white",
                    linewidths=0.35, zorder=3)
    axC.set_xlim(0.1, 10.4)
    axC.set_ylim(0.3, 3.85)
    axC.set_yticks([0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5])
    axC.set_xticks([2.5, 7.75])
    axC.set_xticklabels(["HC (5)", "CKD (5)"])
    axC.set_ylabel("Within-participant CoV (%)")
    axC.tick_params(axis="x", length=0, pad=1.5)
    axC.text(0.06, 0.965,
             f"mean {cov_mean:.2f}%\n95% CI {ci_lo:.2f}\u2013{ci_hi:.2f}%",
             transform=axC.transAxes, ha="left", va="top", fontsize=S.ANNOT,
             color=S.TEXT, linespacing=1.3)
    axC.annotate(f"manual {manual_cov:.2f}%",
                 xy=(10.3, manual_cov), xytext=(9.9, manual_cov + 0.22),
                 fontsize=6.3, color=S.GREY, ha="right", va="bottom")
    fig.text(139.0 / W, 80.4 / H, "C", fontsize=S.LETTER, fontweight="bold", color=S.TEXT, ha="left", va="center")

    # ---------------- footnote ----------------
    note = ("Panel B shows the spread between two measurements of the same kidney on the same day, so its limits "
            "describe repeat-scan dispersion; they are not a 95% interval for independent patients. "
            "The 50 scans come from 10 participants, so the 50 points are not 50 independent kidneys.")
    y = 8.4
    for line in wrap_mm(fig, note, 164.0, 6.0):
        fig.text(8.0 / W, y / H, line, fontsize=6.0, color=S.GREY, ha="left", va="center")
        y -= 3.2

    S.save_figure(fig, HERE / "Fig5_TKV_agreement")
    print(f"Fig5 {W} x {H} mm | bias {bias:.2f} SD {sd:.2f} 1.96SD {loa:.2f} "
          f"limits {bias - loa:.1f}..{loa + bias:.1f} | HC {bias_hc:.2f} CKD {bias_ckd:.2f} | "
          f"CoV {cov_mean:.2f}% CI {ci_lo:.2f}-{ci_hi:.2f} manual {manual_cov:.2f}")


if __name__ == "__main__":
    main()