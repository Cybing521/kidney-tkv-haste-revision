"""Fig. S1  First-scan TKV of the ten repeat participants (single column, 90 mm).

Hollow squares = expert tracing, filled circles = U-Net++; thin grey connectors join
the two measurements of the same participant.  Horizontal bars are the group means
(358.5 / 297.6 mL manual, 366.9 / 296.2 mL automatic); the numbers and the Dice
values are printed under the axes.

Data: 00_历史交付/肾病_医工交叉_delivery/数据/处理后/unetpp_test_rows.json
      rows with repeat == 1 (five HC, five CKD);
      morphometry_tables.json :: unetpp (cross-check only)
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import _style as S  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.lines import Line2D  # noqa: E402

ROOT = HERE.parents[1]
DATA = ROOT / "00_历史交付/肾病_医工交叉_delivery/数据/处理后"

S.apply_style()

W, H = 90.0, 88.0


def wrap_mm(fig, text, max_mm, fontsize):
    renderer = fig.canvas.get_renderer()
    lines, cur = [], ""
    for word in text.split(" "):
        trial = (cur + " " + word).strip()
        t = fig.text(0.0, 0.0, trial, fontsize=fontsize)
        wid = t.get_window_extent(renderer=renderer).width / fig.dpi * 25.4
        t.remove()
        if wid > max_mm and cur:
            lines.append(cur)
            cur = word
        else:
            cur = trial
    if cur:
        lines.append(cur)
    return lines


def load():
    rows = [r for r in json.loads((DATA / "unetpp_test_rows.json").read_text()) if r["repeat"] == 1]
    assert len(rows) == 10
    out = {"hc": [], "ckd": []}
    for r in rows:
        out[r["cohort"]].append((r["subject"], r["gt"]["tkv_ml"], r["pr"]["tkv_ml"], r["dice"]))
    for c in ("hc", "ckd"):
        out[c].sort(key=lambda t: t[0])
        assert len(out[c]) == 5
    return out


def main():
    d = load()
    hc, ckd = d["hc"], d["ckd"]

    def stats(grp):
        man = np.array([t[1] for t in grp])
        aut = np.array([t[2] for t in grp])
        return man, aut, float(man.mean()), float(man.std(ddof=1)), float(aut.mean()), float(aut.std(ddof=1))

    mh, ah, mh_m, mh_s, ah_m, ah_s = stats(hc)
    mc, ac, mc_m, mc_s, ac_m, ac_s = stats(ckd)
    dice_hc = float(np.mean([t[3] for t in hc]))
    dice_ckd = float(np.mean([t[3] for t in ckd]))
    assert abs(mh_m - 358.5) < 0.1 and abs(mc_m - 297.6) < 0.1
    assert abs(ah_m - 366.9) < 0.1 and abs(ac_m - 296.2) < 0.1
    assert abs(dice_hc - 0.944) < 0.001 and abs(dice_ckd - 0.924) < 0.001

    fig = plt.figure(figsize=(W * S.MM, H * S.MM))
    ax = fig.add_axes([16.0 / W, 26.0 / H, 68.0 / W, 50.0 / H])

    xs = {}
    for i, (sid, man, aut, _) in enumerate(hc):
        xs[sid] = 1.0 + i
    for i, (sid, man, aut, _) in enumerate(ckd):
        xs[sid] = 7.0 + i

    for grp, col in ((hc, S.BLUE), (ckd, S.BRICK)):
        for sid, man, aut, _ in grp:
            x = xs[sid]
            ax.plot([x, x], [man, aut], color=S.GREY, lw=0.6, alpha=0.65, zorder=1)
            ax.scatter(x, man, s=26, marker="s", facecolor="white", edgecolor=col,
                       linewidths=0.95, zorder=3)
            ax.scatter(x, aut, s=24, marker="o", facecolor=col, edgecolor="white",
                       linewidths=0.35, zorder=4)

    # group means as horizontal bars
    for grp, col, man_mean, aut_mean, x0, x1 in (
        (hc, S.BLUE, mh_m, ah_m, 0.55, 5.45),
        (ckd, S.BRICK, mc_m, ac_m, 6.55, 11.45),
    ):
        ax.plot([x0, x1], [man_mean, man_mean], color=S.TEXT, lw=0.85, ls=(0, (3.0, 2.0)),
                alpha=0.9, solid_capstyle="butt", zorder=2)
        ax.plot([x0, x1], [aut_mean, aut_mean], color=S.TEXT, lw=1.35, alpha=0.9,
                solid_capstyle="butt", zorder=2)

    ax.set_xlim(0.35, 11.65)
    ax.set_ylim(185, 455)
    ax.set_xticks([3.0, 9.0])
    ax.set_xticklabels(["HC (n = 5)", "CKD (n = 5)"])
    ax.set_yticks([200, 250, 300, 350, 400, 450])
    ax.set_ylabel("First-scan TKV (mL)")
    ax.tick_params(axis="x", length=0, pad=3)

    handles = [
        Line2D([], [], marker="s", ls="none", mfc="white", mec=TEXT_EDGE, mew=0.95,
               ms=4.0, label="expert tracing"),
        Line2D([], [], marker="o", ls="none", mfc=TEXT_EDGE, mec="white", mew=0.35,
               ms=4.0, label="U-Net++"),
        Line2D([], [], color=TEXT_EDGE, lw=0.85, ls=(0, (3.0, 2.0)), label="mean, expert"),
        Line2D([], [], color=TEXT_EDGE, lw=1.35, label="mean, U-Net++"),
    ]
    ax.legend(handles=handles, loc="lower center", bbox_to_anchor=(0.5, 1.015),
              ncol=2, frameon=False, fontsize=6.0, handlelength=1.6,
              columnspacing=1.4, handletextpad=0.45, borderaxespad=0.0,
              labelspacing=0.38)

    notes = [
        f"HC: expert {mh_m:.1f} \u00b1 {mh_s:.1f}, U-Net++ {ah_m:.1f} \u00b1 {ah_s:.1f} mL "
        f"(Dice {dice_hc:.3f})",
        f"CKD: expert {mc_m:.1f} \u00b1 {mc_s:.1f}, U-Net++ {ac_m:.1f} \u00b1 {ac_s:.1f} mL "
        f"(Dice {dice_ckd:.3f})",
        "Each pair of markers is one participant; values are mean \u00b1 SD across 5 participants.",
    ]
    y = 18.6
    for note in notes:
        for line in wrap_mm(fig, note, 80.0, 5.9):
            fig.text(5.0 / W, y / H, line, fontsize=5.9, color=S.GREY, ha="left", va="center")
            y -= 3.15

    S.save_figure(fig, HERE / "FigS1_first_scan_TKV")
    print(f"FigS1 {W} x {H} mm | HC expert {mh_m:.1f}+/-{mh_s:.1f} auto {ah_m:.1f}+/-{ah_s:.1f} "
          f"Dice {dice_hc:.4f} | CKD expert {mc_m:.1f}+/-{mc_s:.1f} auto {ac_m:.1f}+/-{ac_s:.1f} "
          f"Dice {dice_ckd:.4f} | notes end y {y:.1f}")


TEXT_EDGE = S.TEXT

if __name__ == "__main__":
    main()