"""Fig. 6  CHAOS T2-SPIR zero-shot overlay for the worst-performing protocol.

Same three-column structure as Fig. 4 (contours / error map / probability) so the
failure mode is visible instead of hidden under a red-green fill.

Case: chaos_t2_5, displayed at the slice with the largest expert area (z = 15/29).
Data: overlay_arrays/F_chaos_t2_5.npz (image, prob, gt, spacing)
      unetpp_chaos_rows.json :: row with scan_id == chaos_t2_5 (Dice, |ΔTKV|)
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import _style as S  # noqa: E402
import _overlay as O  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402

ROOT = HERE.parents[1]
NPZ = ROOT / "02_工作/服务器/overlay_arrays/F_chaos_t2_5.npz"
ROWS = ROOT / "00_历史交付/肾病_医工交叉_delivery/数据/处理后/unetpp_chaos_rows.json"

SIZE = 52.0
GAP = 2.2
LEFT = 11.0
FIG_W = 180.0
FIG_H = 75.0

S.apply_style()


def main():
    img, gt, prob, spacing = O.load_npz(NPZ)
    nz = img.shape[2]
    z = int(np.argmax(gt.reshape(-1, nz).sum(0)))

    row = [r for r in json.loads(ROWS.read_text()) if r["scan_id"] == "chaos_t2_5"][0]
    dice = row["dice"]
    tkv = row["tkv_abs_ml"]

    fig = plt.figure(figsize=(FIG_W * S.MM, FIG_H * S.MM))
    y_img = 12.0
    im, _ = O.draw_columns(fig, LEFT, y_img, SIZE, img[:, :, z], gt[:, :, z], prob[:, :, z], gap=GAP)

    xs = [LEFT + i * (SIZE + GAP) for i in range(3)]
    O.column_headers(fig, xs, y_img + SIZE + 1.4, SIZE)
    O.add_colorbar(fig, im, LEFT + 3 * SIZE + 2 * GAP + 2.0, y_img, 2.2, SIZE)

    fig.text(LEFT / FIG_W, (FIG_H - 2.6) / FIG_H,
             "CHAOS T2-SPIR, zero-shot U-Net++",
             fontsize=8.0, color=S.TEXT, ha="left", va="center")
    fig.text((LEFT + 3 * SIZE + 2 * GAP) / FIG_W, (FIG_H - 2.6) / FIG_H,
             f"chaos_t2_5 · Dice {dice:.3f} · |ΔTKV| {tkv:.1f} mL",
             fontsize=7.2, color=S.TEXT, ha="right", va="center")
    fig.text(LEFT / FIG_W, (y_img - 3.4) / FIG_H,
             f"slice {z}/{nz - 1} (largest expert area) · {spacing[0]:.2f} × {spacing[1]:.2f} × {spacing[2]:.1f} mm voxels",
             fontsize=6.2, color=S.GREY, ha="left", va="center")
    O.legend_row(fig, LEFT, 2.6)

    S.save_figure(fig, HERE / "Fig6_CHAOS_overlay")
    print("wrote Fig6", FIG_W, "x", FIG_H, "| z", z, "| dice", round(dice, 5), "| tkv", round(tkv, 2))


if __name__ == "__main__":
    main()
