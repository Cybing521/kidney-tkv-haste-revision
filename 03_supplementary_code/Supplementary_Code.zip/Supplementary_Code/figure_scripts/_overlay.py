"""Shared helpers for the three-column MRI overlay panels (Figs 4 and 6).

Column structure
----------------
(i)  grayscale MRI + expert contour (blue, solid, 0.9 pt) + automatic contour
     (brick red, dashed, 0.9 pt), no fill, so the error is not hidden;
(ii) error map: false positive (brick, alpha 0.55) and false negative
     (blue, alpha 0.55) over a very pale MRI (alpha 0.22) for anatomy;
(iii) probability map P(kidney) in grayscale with a shared 0-1 colour bar.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
from matplotlib import colors
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

import _style as S

FP_RGBA = colors.to_rgba(S.BRICK, 0.55)
FN_RGBA = colors.to_rgba(S.BLUE, 0.55)


def axes_at(fig, x_mm, y_mm, w_mm, h_mm):
    """Absolute axes placement in mm, origin at the lower-left of the figure."""
    w_in, h_in = fig.get_size_inches() * 25.4
    return fig.add_axes([x_mm / w_in, y_mm / h_in, w_mm / w_in, h_mm / h_in])


def error_rgba(pred: np.ndarray, gt: np.ndarray) -> np.ndarray:
    fp = pred & ~gt
    fn = gt & ~pred
    out = np.zeros((*gt.shape, 4), np.float32)
    out[fp] = FP_RGBA
    out[fn] = FN_RGBA
    return out


def draw_columns(fig, x_mm, y_mm, size_mm, image, gt, prob, thr=0.5, gap=1.0):
    """Draw the three columns starting at (x_mm, y_mm); return the probability AxesImage."""
    pred = prob > thr

    # --- column 1: contours on MRI -------------------------------------
    ax1 = axes_at(fig, x_mm, y_mm, size_mm, size_mm)
    ax1.imshow(image, cmap="gray", vmin=0.0, vmax=1.0, origin="upper",
               interpolation="nearest", aspect="equal")
    if gt.any():
        ax1.contour(gt.astype(float), levels=[0.5], colors=[S.BLUE], linewidths=0.9,
                    antialiased=True, origin="upper")
    if pred.any():
        cs = ax1.contour(pred.astype(float), levels=[0.5], colors=[S.BRICK], linewidths=0.95,
                         linestyles="dashed", antialiased=True, origin="upper")
        try:  # slightly longer dashes than the default so they read at 27 mm
            cs.set_linestyle((0, (3.4, 1.7)))
        except Exception:
            pass
    ax1.set_xticks([])
    ax1.set_yticks([])
    for sp in ax1.spines.values():
        sp.set_visible(True)
        sp.set_color("#B4B4B4")
        sp.set_linewidth(0.5)

    # --- column 2: error map -------------------------------------------
    ax2 = axes_at(fig, x_mm + size_mm + gap, y_mm, size_mm, size_mm)
    # dark anatomy backdrop so both encodings read against it; a pale backdrop
    # washed the alphas out, which is what R1.7 complained about
    ax2.set_facecolor("#0E0E0E")
    ax2.imshow(image, cmap="gray", vmin=0.0, vmax=1.0, origin="upper",
               interpolation="nearest", aspect="equal", alpha=0.45)
    ax2.imshow(error_rgba(pred, gt), origin="upper", interpolation="nearest", aspect="equal")
    ax2.set_xticks([])
    ax2.set_yticks([])
    for sp in ax2.spines.values():
        sp.set_visible(True)
        sp.set_color("#B4B4B4")
        sp.set_linewidth(0.5)

    # --- column 3: probability -----------------------------------------
    ax3 = axes_at(fig, x_mm + 2 * (size_mm + gap), y_mm, size_mm, size_mm)
    im = ax3.imshow(prob, cmap="gray", vmin=0.0, vmax=1.0, origin="upper",
                    interpolation="nearest", aspect="equal")
    ax3.set_xticks([])
    ax3.set_yticks([])
    for sp in ax3.spines.values():
        sp.set_visible(True)
        sp.set_color("#B4B4B4")
        sp.set_linewidth(0.5)
    return im, ax1


def column_headers(fig, xs_mm, y_mm, size_mm):
    labels = ["Contours", "Error map", "P(kidney)"]
    for i, lab in enumerate(labels):
        fig.text((xs_mm[i] + size_mm / 2) / (fig.get_size_inches()[0] * 25.4),
                 y_mm / (fig.get_size_inches()[1] * 25.4),
                 lab, ha="center", va="bottom", fontsize=S.ANNOT, color=S.TEXT)


def legend_row(fig, x_mm, y_mm):
    """One shared legend explaining the encodings."""
    handles = [
        Line2D([], [], color=S.BLUE, lw=0.9, label="expert contour"),
        Line2D([], [], color=S.BRICK, lw=0.9, ls="--", label="automatic contour"),
        Patch(facecolor=colors.to_rgba(S.BRICK, 0.55), edgecolor="none", label="false positive"),
        Patch(facecolor=colors.to_rgba(S.BLUE, 0.55), edgecolor="none", label="false negative"),
    ]
    W = fig.get_size_inches()[0] * 25.4
    H = fig.get_size_inches()[1] * 25.4
    leg = fig.legend(handles=handles, loc="lower left", bbox_to_anchor=(x_mm / W, y_mm / H),
                     ncol=4, frameon=False, fontsize=S.ANNOT, handlelength=1.6,
                     columnspacing=1.6, handletextpad=0.5, borderaxespad=0.0)
    return leg


def add_colorbar(fig, im, x_mm, y_mm, w_mm, h_mm):
    W = fig.get_size_inches()[0] * 25.4
    H = fig.get_size_inches()[1] * 25.4
    cax = fig.add_axes([x_mm / W, y_mm / H, w_mm / W, h_mm / H])
    cb = fig.colorbar(im, cax=cax, ticks=[0.0, 0.5, 1.0])
    cb.ax.set_yticklabels(["0", "0.5", "1"])
    cb.ax.tick_params(labelsize=6.0, length=1.6, width=0.5, pad=1.2)
    cb.outline.set_linewidth(0.4)
    cb.outline.set_edgecolor("#B4B4B4")
    cb.set_label("P", fontsize=6.5, labelpad=2)
    return cb


def load_npz(path: Path):
    with np.load(path) as z:
        return (z["image"].astype(np.float32), z["gt"].astype(bool),
                z["prob"].astype(np.float32), z["spacing"])
