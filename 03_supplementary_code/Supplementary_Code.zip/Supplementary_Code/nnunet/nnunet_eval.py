#!/usr/bin/env python3
"""Score nnU-Net 2d predictions with exactly the metrics used for U-Net / AttU-Net / U-Net++.

Metrics (identical to scripts/train.py)
  dice      (2|P^G| + 1e-6) / (|P| + |G| + 1e-6) on the binary kidney-union mask, no cleanup
  TKV (mL)  sum of the two largest 3D connected components x native voxel volume
            -> scripts/train.py:laterality() imported directly (same function object)
  spacing   nii header zooms, in the array axis order (240,240,13) -> (1.458,1.458,5.5)

Statistics
  5-fold OOF : 50 subjects x 1 scan -> mean / SD(ddof=0) / median / IQR / bootstrap 95% CI
               (10000 resamples, seed 42, percentile method)
  CoV split  : 10 subjects x 5 repeats -> per-subject SD(ddof=1)/mean -> mean / SD / CI
  SD uses ddof=0 for the Dice/TKV distributions so the numbers are directly comparable with
  scripts/train.py:summarize(); the subject-level CoV SD uses ddof=1 (sample SD across subjects).

Self-checks (printed and stored under "checks")
  * GT TKV recomputed from the nii files must equal runs_cv5 / runs test_rows.json "gt.tkv_ml"
  * baseline Dice / TKV-MAE / CoV recomputed from the existing test_rows.json must equal the
    published summary.json numbers -> proves the metric code reproduces the manuscript baseline

Outputs
  runs_rev2026/nnunet/nnunet_results.json
  runs_rev2026/nnunet/nnunet_summary.md
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from collections import defaultdict
from pathlib import Path

import nibabel as nib
import numpy as np

ROOT = Path("/root/autodl-tmp/ckd_t2mri_morphometry")
sys.path.insert(0, str(ROOT / "scripts"))
from train import laterality  # noqa: E402  (same function object the baselines used)

N_BOOT = 10000
BOOT_SEED = 42
MODELS = ["unet", "attunet", "unetpp"]


# ----------------------------------------------------------------------------- metrics
def load_binary(path: Path) -> np.ndarray:
    return np.asanyarray(nib.load(str(path)).dataobj) > 0


def zooms(path: Path) -> np.ndarray:
    return np.asarray(nib.load(str(path)).header.get_zooms()[:3], dtype=np.float64)


def dice_binary(pred: np.ndarray, gt: np.ndarray) -> float:
    inter = float(np.count_nonzero(pred & gt))
    return (2.0 * inter + 1e-6) / (float(pred.sum()) + float(gt.sum()) + 1e-6)


def boot_ci(vals, n_boot: int = N_BOOT, seed: int = BOOT_SEED):
    v = np.asarray(vals, dtype=np.float64)
    rng = np.random.RandomState(seed)
    idx = rng.randint(0, v.size, size=(n_boot, v.size))
    means = v[idx].mean(axis=1)
    return float(np.percentile(means, 2.5)), float(np.percentile(means, 97.5))


def desc(vals) -> dict:
    v = np.asarray(vals, dtype=np.float64)
    lo, hi = boot_ci(v)
    return {
        "n": int(v.size),
        "mean": float(v.mean()),
        "sd": float(v.std()),
        "median": float(np.median(v)),
        "q1": float(np.percentile(v, 25)),
        "q3": float(np.percentile(v, 75)),
        "iqr": float(np.percentile(v, 75) - np.percentile(v, 25)),
        "ci95_low": lo,
        "ci95_high": hi,
        "ci95": [lo, hi],
    }


def cov_block(rows: list, tkv_key: str = "pr_tkv_ml") -> dict:
    by = defaultdict(list)
    for r in rows:
        val = r[tkv_key] if tkv_key in r else r["pr"]["tkv_ml"]
        by[r["subject"]].append(float(val))
    per = []
    for subj in sorted(by):
        vals = np.asarray(by[subj], dtype=np.float64)
        if vals.size >= 3 and vals.mean() > 0:
            per.append(
                {
                    "subject": subj,
                    "n_repeat": int(vals.size),
                    "tkv_mean_ml": float(vals.mean()),
                    "tkv_sd_ml": float(vals.std(ddof=1)),
                    "cov": float(vals.std(ddof=1) / vals.mean()),
                }
            )
    covs = [p["cov"] for p in per]
    lo, hi = boot_ci(covs)
    return {
        "n_subjects": len(per),
        "cov_mean": float(np.mean(covs)) if covs else None,
        "cov_sd": float(np.std(covs, ddof=1)) if len(covs) > 1 else None,
        "cov_median": float(np.median(covs)) if covs else None,
        "cov_ci95": [lo, hi],
        "per_subject": per,
    }


# ----------------------------------------------------------------------------- baselines
def baseline_cv5(root: Path, model: str):
    rows, folds = [], []
    for k in range(5):
        r = json.loads((root / "runs_cv5" / ("fold%d" % k) / model / "test_rows.json").read_text())
        rows += r
        folds.append({"fold": k, "n": len(r), "dice_mean": float(np.mean([x["dice"] for x in r]))})
    return rows, folds


def baseline_cov(root: Path, model: str):
    return json.loads((root / "runs" / model / "test_rows.json").read_text())


def oof_stats(rows: list) -> dict:
    d = [float(r["dice"]) for r in rows]
    e = [float(r["tkv_abs_ml"]) for r in rows]
    gt = np.asarray([r["gt"]["tkv_ml"] for r in rows], dtype=np.float64)
    pr = np.asarray([r["pr"]["tkv_ml"] for r in rows], dtype=np.float64)
    corr = float(np.corrcoef(gt, pr)[0, 1]) if gt.std() > 1e-9 and pr.std() > 1e-9 else None
    return {"dice": desc(d), "tkv_mae_ml": desc(e), "tkv_corr": corr}


# ----------------------------------------------------------------------------- training logs
def parse_training_log(path: Path) -> dict:
    txt = path.read_text(errors="replace")
    tl, vl, dice, epochs = [], [], [], []
    for line in txt.splitlines():
        m = re.search(r"train_loss\s+(-?[\d.eE+-]+)", line)
        if m:
            tl.append(float(m.group(1)))
        m = re.search(r"val_loss\s+(-?[\d.eE+-]+)", line)
        if m:
            vl.append(float(m.group(1)))
        m = re.search(r"pseudo Dice:\s*([\d.]+)", line)
        if m:
            dice.append(float(m.group(1)))
        m = re.search(r":\s*Epoch\s+(\d+)\s*$", line)
        if m:
            epochs.append(int(m.group(1)))
    return {
        "log_file": str(path),
        "n_epoch_lines": len(epochs),
        "last_epoch": epochs[-1] if epochs else None,
        "train_loss_first": tl[0] if tl else None,
        "train_loss_last": tl[-1] if tl else None,
        "train_loss_tail20_mean": float(np.mean(tl[-20:])) if len(tl) >= 5 else None,
        "val_loss_first": vl[0] if vl else None,
        "val_loss_last": vl[-1] if vl else None,
        "val_loss_tail20_mean": float(np.mean(vl[-20:])) if len(vl) >= 5 else None,
        "best_ema_pseudo_dice": max(dice) if dice else None,
        "final_ema_pseudo_dice": dice[-1] if dice else None,
        "n_pseudo_dice_improvements": len(dice),
        "train_loss_series": tl,
        "val_loss_series": vl,
        "tail20_lines": txt.splitlines()[-20:],
    }


# ----------------------------------------------------------------------------- main
def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=Path, default=ROOT)
    ap.add_argument("--outdir", type=Path, default=None)
    ap.add_argument("--trainer", default="nnUNetTrainer_100epochs")
    ap.add_argument("--plans", default="nnUNetPlans")
    ap.add_argument("--config", default="2d")
    ap.add_argument("--dataset", default="Dataset501_KidneyHASTE")
    args = ap.parse_args()
    root = args.root
    outdir = args.outdir or (root / "runs_rev2026" / "nnunet")
    pred_root = outdir / "predictions"
    results_root = outdir / "results" / args.dataset / ("%s__%s__%s" % (args.trainer, args.plans, args.config))

    id_map = json.loads((outdir / "id_map.json").read_text())
    case2scan = id_map["case_to_scan_id"]
    scan_info = {c["scan_id"]: c for c in id_map["cases"]}
    fold_meta = json.loads((outdir / "fold_meta.json").read_text())["folds"]
    checks = []

    folds_out = []
    for fm in fold_meta:
        k = fm["fold"]
        rows = []
        for case_id in fm["test_cases"]:
            scan_id = case2scan[case_id]
            info = scan_info[scan_id]
            pred_path = pred_root / ("fold%d" % k) / (case_id + ".nii.gz")
            if not pred_path.exists():
                raise SystemExit("missing prediction %s" % pred_path)
            gt_path = root / info["mask_src"]
            pred, gt = load_binary(pred_path), load_binary(gt_path)
            if pred.shape != gt.shape:
                raise SystemExit("%s: pred shape %s != gt shape %s" % (scan_id, pred.shape, gt.shape))
            # float32, exactly like the npz "spacing" array the baselines consumed -> bit-identical TKV path
            sp = np.asarray(zooms(gt_path), dtype=np.float32)
            gm, pm = laterality(gt, sp), laterality(pred, sp)
            rows.append(
                {
                    "case_id": case_id,
                    "scan_id": scan_id,
                    "subject": info["subject"],
                    "cohort": info["cohort"],
                    "repeat": info["repeat"],
                    "dice": dice_binary(pred, gt),
                    "gt": gm,
                    "pr": pm,
                    "pr_tkv_ml": pm["tkv_ml"],
                    "gt_tkv_ml": gm["tkv_ml"],
                    "tkv_abs_ml": abs(pm["tkv_ml"] - gm["tkv_ml"]),
                    "pred_vox": int(pred.sum()),
                    "gt_vox": int(gt.sum()),
                    "spacing": [float(x) for x in sp],
                }
            )
        st = oof_stats(rows)
        covf = cov_block(rows)
        log_files = sorted(results_root.glob("fold_%d/training_log_*.txt" % k))
        training = parse_training_log(log_files[-1]) if log_files else None
        folds_out.append(
            {
                "fold": k,
                "protocol": fm.get("protocol", "5-fold subject CV"),
                "n_train_cases": len(fm["train_cases"]),
                "n_val_cases": len(fm["val_cases"]),
                "n_test_scans": len(fm["test_cases"]),
                "test_subjects": sorted({case2scan[c].rsplit("_r", 1)[0] for c in fm["test_cases"]}),
                "stats": st,
                "repeat_cov": covf if covf["n_subjects"] else None,
                "training": training,
                "rows": rows,
            }
        )
        print(
            "fold %d: n=%d dice=%.4f+-%.4f mae=%.2f mL"
            % (k, len(rows), st["dice"]["mean"], st["dice"]["sd"], st["tkv_mae_ml"]["mean"]),
            flush=True,
        )

    oof_rows = [r for f in folds_out if f["fold"] < 5 for r in f["rows"]]
    if len(oof_rows) != 50 or len({r["subject"] for r in oof_rows}) != 50:
        raise SystemExit("OOF is not 50 distinct subjects: n=%d" % len(oof_rows))
    oof = {"n": len(oof_rows), **oof_stats(oof_rows), "rows": oof_rows}

    cov_rows = [r for f in folds_out if f["fold"] == 5 for r in f["rows"]]
    if len(cov_rows) != 50:
        raise SystemExit("CoV test is not 50 scans: n=%d" % len(cov_rows))
    cov_st = oof_stats(cov_rows)
    cov = {
        "n_scans": len(cov_rows),
        "n_subjects": len({r["subject"] for r in cov_rows}),
        "dice": cov_st["dice"],
        "tkv_mae_ml": cov_st["tkv_mae_ml"],
        "tkv_corr": cov_st["tkv_corr"],
        "repeat_cov": cov_block(cov_rows),
        "rows": cov_rows,
    }

    # self-check A: GT TKV from nii == existing rows' gt.tkv_ml
    ref_gt = {}
    for k in range(5):
        for r in json.loads((root / "runs_cv5" / ("fold%d" % k) / "unet" / "test_rows.json").read_text()):
            ref_gt[r["scan_id"]] = r["gt"]["tkv_ml"]
    for r in json.loads((root / "runs" / "unet" / "test_rows.json").read_text()):
        ref_gt[r["scan_id"]] = r["gt"]["tkv_ml"]
    diffs = [abs(r["gt_tkv_ml"] - ref_gt[r["scan_id"]]) for r in oof_rows + cov_rows if r["scan_id"] in ref_gt]
    max_gt_diff = float(max(diffs)) if diffs else None
    checks.append(
        "GT TKV recomputed from nii vs existing test_rows.json gt.tkv_ml: n=%d max|diff|=%.3e mL -> %s"
        % (len(diffs), max_gt_diff or 0.0, "PASS" if max_gt_diff is not None and max_gt_diff < 1e-6 else "FAIL")
    )

    # self-check B: baseline reproduction
    base = {"cv5": {}, "cov": {}}
    repro = []
    for m in MODELS:
        rows, per_fold = baseline_cv5(root, m)
        st = oof_stats(rows)
        base["cv5"][m] = {"n": len(rows), **st, "per_fold_dice_mean": per_fold}
        for k in range(5):
            pub = json.loads((root / "runs_cv5" / ("fold%d" % k) / m / "summary.json").read_text())["test"]
            repro.append(abs(pub["dice_mean"] - per_fold[k]["dice_mean"]))
        prows = baseline_cov(root, m)
        pst = oof_stats(prows)
        pcov = cov_block(prows)
        base["cov"][m] = {"n": len(prows), **pst, "repeat_cov": pcov}
        pub = json.loads((root / "runs" / m / "summary.json").read_text())["test"]
        repro.append(abs(pub["dice_mean"] - pst["dice"]["mean"]))
        repro.append(abs(pub["tkv_mae_ml"] - pst["tkv_mae_ml"]["mean"]))
        if pub.get("repeat_cov_mean") is not None and pcov["cov_mean"] is not None:
            repro.append(abs(pub["repeat_cov_mean"] - pcov["cov_mean"]))
    checks.append(
        "baseline recomputation vs published summary.json (dice mean / TKV MAE / CoV mean): n=%d max|diff|=%.3e -> %s"
        % (len(repro), max(repro), "PASS" if max(repro) < 1e-9 else "FAIL")
    )

    table = []
    for m in MODELS:
        table.append(
            {
                "model": m,
                "oof_dice_mean": base["cv5"][m]["dice"]["mean"],
                "oof_dice_sd": base["cv5"][m]["dice"]["sd"],
                "oof_dice_ci95": base["cv5"][m]["dice"]["ci95"],
                "oof_tkv_mae": base["cv5"][m]["tkv_mae_ml"]["mean"],
                "oof_tkv_mae_ci95": base["cv5"][m]["tkv_mae_ml"]["ci95"],
                "cov_dice_mean": base["cov"][m]["dice"]["mean"],
                "cov_dice_sd": base["cov"][m]["dice"]["sd"],
                "cov_tkv_mae": base["cov"][m]["tkv_mae_ml"]["mean"],
                "cov_repeat_cov_mean": base["cov"][m]["repeat_cov"]["cov_mean"],
                "cov_repeat_cov_ci95": base["cov"][m]["repeat_cov"]["cov_ci95"],
            }
        )
    table.append(
        {
            "model": "nnunet_2d_100ep",
            "oof_dice_mean": oof["dice"]["mean"],
            "oof_dice_sd": oof["dice"]["sd"],
            "oof_dice_ci95": oof["dice"]["ci95"],
            "oof_tkv_mae": oof["tkv_mae_ml"]["mean"],
            "oof_tkv_mae_ci95": oof["tkv_mae_ml"]["ci95"],
            "cov_dice_mean": cov["dice"]["mean"],
            "cov_dice_sd": cov["dice"]["sd"],
            "cov_tkv_mae": cov["tkv_mae_ml"]["mean"],
            "cov_repeat_cov_mean": cov["repeat_cov"]["cov_mean"],
            "cov_repeat_cov_ci95": cov["repeat_cov"]["cov_ci95"],
        }
    )

    out = {
        "meta": {
            "dataset": args.dataset,
            "trainer": args.trainer,
            "plans": args.plans,
            "configuration": args.config,
            "n_cases": id_map["n_cases"],
            "dice_definition": "(2|P&G| + 1e-6)/(|P|+|G|+1e-6), binary kidney-union mask, no cleanup",
            "tkv_definition": "sum of two largest 3D connected components x native voxel volume, scripts/train.py:laterality",
            "bootstrap": {"n": N_BOOT, "seed": BOOT_SEED, "method": "percentile"},
            "sd_ddof": 0,
            "cov_sd_ddof": 1,
        },
        "checks": checks,
        "folds": folds_out,
        "oof5": oof,
        "cov": cov,
        "baselines": base,
        "comparison_table": table,
    }
    (outdir / "nnunet_results.json").write_text(json.dumps(out, indent=2) + "\n")
    (outdir / "nnunet_summary.md").write_text(render_md(out))
    print("\n".join(checks), flush=True)
    print("wrote", outdir / "nnunet_results.json", flush=True)
    print("wrote", outdir / "nnunet_summary.md", flush=True)


def render_md(out: dict) -> str:
    L = []
    A = L.append
    A("# nnU-Net v2 2D 同划分基线结果")
    A("")
    A("- dataset: " + out["meta"]["dataset"] + " (%d scans)" % out["meta"]["n_cases"])
    A("- trainer: " + out["meta"]["trainer"] + ", plans " + out["meta"]["plans"] + ", config " + out["meta"]["configuration"])
    A("- Dice: " + out["meta"]["dice_definition"])
    A("- TKV: " + out["meta"]["tkv_definition"])
    A("- bootstrap: %d resamples, seed %d" % (out["meta"]["bootstrap"]["n"], out["meta"]["bootstrap"]["seed"]))
    A("")
    A("## 自检")
    A("")
    for c in out["checks"]:
        A("- " + c)
    A("")
    A("## 逐折结果（5 折 CV，各 10 个 test 扫描）")
    A("")
    A("| fold | n_test | Dice mean | Dice SD | TKV MAE (mL) | best EMA pseudo Dice | last epoch | train_loss(last) | val_loss(last) |")
    A("|---|---|---|---|---|---|---|---|---|")
    for f in out["folds"]:
        s = f["stats"]
        t = f["training"] or {}
        A(
            "| %d | %d | %.4f | %.4f | %.2f | %s | %s | %s | %s |"
            % (
                f["fold"],
                f["n_test_scans"],
                s["dice"]["mean"],
                s["dice"]["sd"],
                s["tkv_mae_ml"]["mean"],
                fmt(t.get("best_ema_pseudo_dice")),
                fmt(t.get("last_epoch"), 0),
                fmt(t.get("train_loss_last")),
                fmt(t.get("val_loss_last")),
            )
        )
    A("")
    A("## 5 折 OOF（50 受试者 x 1 扫描）")
    A("")
    A("| model | Dice mean | SD | median | IQR | 95% CI | TKV MAE (mL) | MAE 95% CI | TKV r |")
    A("|---|---|---|---|---|---|---|---|---|")
    rows = [("nnU-Net 2D (100 ep)", out["oof5"]["dice"], out["oof5"]["tkv_mae_ml"], out["oof5"]["tkv_corr"])]
    for m in MODELS:
        b = out["baselines"]["cv5"][m]
        rows.append((m, b["dice"], b["tkv_mae_ml"], b["tkv_corr"]))
    for name, d, e, r in rows:
        A(
            "| %s | %.4f | %.4f | %.4f | %.4f | [%.4f, %.4f] | %.2f | [%.2f, %.2f] | %s |"
            % (
                name,
                d["mean"],
                d["sd"],
                d["median"],
                d["iqr"],
                d["ci95_low"],
                d["ci95_high"],
                e["mean"],
                e["ci95_low"],
                e["ci95_high"],
                "n/a" if r is None else "%.4f" % r,
            )
        )
    A("")
    A("## CoV split（10 受试者 x 5 次重复，50 扫描）")
    A("")
    A("| model | Dice mean | SD | 95% CI | TKV MAE (mL) | CoV mean | CoV SD | CoV 95% CI |")
    A("|---|---|---|---|---|---|---|---|")
    crows = [("nnU-Net 2D (100 ep)", {"dice": out["cov"]["dice"], "tkv_mae_ml": out["cov"]["tkv_mae_ml"], "repeat_cov": out["cov"]["repeat_cov"]})]
    for m in MODELS:
        b = out["baselines"]["cov"][m]
        crows.append((m, {"dice": b["dice"], "tkv_mae_ml": b["tkv_mae_ml"], "repeat_cov": b["repeat_cov"]}))
    for name, c in crows:
        d, e, cv = c["dice"], c["tkv_mae_ml"], c["repeat_cov"]
        A(
            "| %s | %.4f | %.4f | [%.4f, %.4f] | %.2f | %.4f | %s | [%.4f, %.4f] |"
            % (
                name,
                d["mean"],
                d["sd"],
                d["ci95_low"],
                d["ci95_high"],
                e["mean"],
                cv["cov_mean"],
                fmt(cv["cov_sd"]),
                cv["cov_ci95"][0],
                cv["cov_ci95"][1],
            )
        )
    A("")
    A("## 逐受试者 CoV（nnU-Net）")
    A("")
    A("| subject | n | TKV mean (mL) | TKV SD (mL) | CoV |")
    A("|---|---|---|---|---|")
    for p in out["cov"]["repeat_cov"]["per_subject"]:
        A("| %s | %d | %.2f | %.2f | %.4f |" % (p["subject"], p["n_repeat"], p["tkv_mean_ml"], p["tkv_sd_ml"], p["cov"]))
    A("")
    A("## 训练收敛证据")
    A("")
    A("| fold | train_loss first | train_loss tail20 mean | val_loss first | val_loss tail20 mean | best EMA pseudo Dice |")
    A("|---|---|---|---|---|---|")
    for f in out["folds"]:
        t = f["training"] or {}
        A(
            "| %d | %s | %s | %s | %s | %s |"
            % (
                f["fold"],
                fmt(t.get("train_loss_first")),
                fmt(t.get("train_loss_tail20_mean")),
                fmt(t.get("val_loss_first")),
                fmt(t.get("val_loss_tail20_mean")),
                fmt(t.get("best_ema_pseudo_dice")),
            )
        )
    return "\n".join(L) + "\n"


def fmt(x, nd=4):
    if x is None:
        return "n/a"
    try:
        return ("%." + str(nd) + "f") % float(x)
    except (TypeError, ValueError):
        return str(x)


if __name__ == "__main__":
    main()
