#!/usr/bin/env python3
"""Build nnU-Net v2 raw dataset Dataset501_KidneyHASTE from the unpacked HASTE T2W scans.

100 scans = 40 single-scan subjects (HC_01..25, CKD_01..25, one scan each) +
10 repeat subjects (HC_26..30, CKD_26..30) x 5 repeats.

Writes
  $ROOT/data/nnunet_raw/Dataset501_KidneyHASTE/{imagesTr,labelsTr,dataset.json}
  $ROOT/runs_rev2026/nnunet/id_map.json         case_id <-> scan_id <-> source file
  $ROOT/runs_rev2026/nnunet/splits_final.json   folds 0-4 = 5-fold CV, fold 5 = CoV split

Hard checks (abort, never warn-and-continue):
  * each scan_id maps to exactly one image/mask pair
  * mask voxel count == scans.json tkv_vox for all 100 scans (proves the pairing)
  * image/mask shape agree
  * fold test scan ids reproduce runs_cv5/fold{k}/unet/test_rows.json exactly
  * CoV split reproduces data/split.json exactly
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
from collections import defaultdict
from pathlib import Path

import nibabel as nib
import numpy as np

COHORT_DIR = {"hc": "Healthy_Control", "ckd": "CKD"}


def find_pair(unpacked: Path, subject: str, repeat: int) -> tuple[Path, Path]:
    d = unpacked / COHORT_DIR["hc" if subject.startswith("HC") else "ckd"]
    cands = [p for p in sorted(d.glob(f"{subject}_T2W*.nii.gz")) if not p.name.endswith("_mask.nii.gz")]
    if len(cands) == 1:
        img = cands[0]
    else:
        hits = [p for p in cands if p.name == f"{subject}_T2W_{repeat}.nii.gz"]
        if len(hits) != 1:
            raise SystemExit(f"{subject} r{repeat}: cannot disambiguate among {[c.name for c in cands]}")
        img = hits[0]
    mask = img.with_name(img.name.replace(".nii.gz", "_mask.nii.gz"))
    if not mask.exists():
        raise SystemExit(f"missing mask for {img}")
    return img, mask


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=Path, default=Path("/root/autodl-tmp/ckd_t2mri_morphometry"))
    ap.add_argument("--dataset-id", type=int, default=501)
    ap.add_argument("--dataset-name", default="KidneyHASTE")
    args = ap.parse_args()
    root = args.root
    ds = f"Dataset{args.dataset_id}_{args.dataset_name}"
    raw = root / "data" / "nnunet_raw" / ds
    outdir = root / "runs_rev2026" / "nnunet"
    unpacked = root / "data" / "unpacked"

    records = json.loads((root / "data" / "scans.json").read_text())
    if len(records) != 100:
        raise SystemExit(f"expected 100 scans in scans.json, got {len(records)}")

    # ---- map every scan_id to its image/mask pair and verify against tkv_vox ----
    cases = []
    for rec in sorted(records, key=lambda r: (r["subject"], r["repeat"])):
        img, mask = find_pair(unpacked, rec["subject"], rec["repeat"])
        m = nib.load(str(mask))
        marr = np.asanyarray(m.dataobj)
        nvox = int((marr > 0).sum())
        if nvox != int(rec["tkv_vox"]):
            raise SystemExit(
                f"{rec['scan_id']}: mask voxels {nvox} != scans.json tkv_vox {rec['tkv_vox']} ({img.name})"
            )
        im = nib.load(str(img))
        if tuple(im.shape) != tuple(m.shape):
            raise SystemExit(f"{rec['scan_id']}: image shape {im.shape} != mask shape {m.shape}")
        if int(np.unique(marr).max()) > 1:
            raise SystemExit(f"{rec['scan_id']}: mask labels {np.unique(marr)} not binary 0/1")
        cases.append(
            {
                "scan_id": rec["scan_id"],
                "subject": rec["subject"],
                "cohort": rec["cohort"],
                "repeat": rec["repeat"],
                "image_src": str(img.relative_to(root)),
                "mask_src": str(mask.relative_to(root)),
                "shape": list(map(int, im.shape)),
                "spacing": [float(x) for x in im.header.get_zooms()],
                "tkv_vox": nvox,
            }
        )
    if len({c["scan_id"] for c in cases}) != 100:
        raise SystemExit("scan_id collision")

    # ---- stable numbering: sorted by (subject, repeat) ----
    for i, c in enumerate(cases, start=1):
        c["case_id"] = f"{i:04d}"

    # ---- raw dataset ----
    if raw.exists():
        shutil.rmtree(raw)
    (raw / "imagesTr").mkdir(parents=True)
    (raw / "labelsTr").mkdir(parents=True)
    for c in cases:
        dst_img = raw / "imagesTr" / f"{c['case_id']}_0000.nii.gz"
        dst_lab = raw / "labelsTr" / f"{c['case_id']}.nii.gz"
        for src, dst in ((root / c["image_src"], dst_img), (root / c["mask_src"], dst_lab)):
            try:
                os.link(src, dst)  # same filesystem: hardlink, zero extra bytes
            except OSError:
                shutil.copy2(src, dst)
    dataset_json = {
        "channel_names": {"0": "T2"},
        "labels": {"background": 0, "kidney": 1},
        "numTraining": len(cases),
        "file_ending": ".nii.gz",
        "name": ds,
        "description": "HASTE T2W kidney segmentation, 100 scans (50 HC + 50 CKD), 2D nnU-Net baseline",
    }
    (raw / "dataset.json").write_text(json.dumps(dataset_json, indent=2) + "\n")

    # ---- splits ----
    folds_dir = root / "data" / "folds"
    if not (folds_dir / "fold0.json").exists():
        raise SystemExit(f"{folds_dir}/fold0.json missing - run scripts/make_cv_splits.py first")
    scan2case = {c["scan_id"]: c["case_id"] for c in cases}
    splits = []
    fold_meta = []
    for k in range(5):
        fj = json.loads((folds_dir / f"fold{k}.json").read_text())
        tr = [scan2case[s] for s in fj["scans"]["train"]]
        va = [scan2case[s] for s in fj["scans"]["val"]]
        te = [scan2case[s] for s in fj["scans"]["test"]]
        splits.append({"train": tr, "val": va})
        fold_meta.append(
            {
                "fold": k,
                "train_cases": tr,
                "val_cases": va,
                "test_cases": te,
                "train_scans": fj["scans"]["train"],
                "val_scans": fj["scans"]["val"],
                "test_scans": fj["scans"]["test"],
                "test_subjects": fj["test_subjects"],
            }
        )
    # fold 5 = CoV split (train 42 / val 8), test 50 not in splits
    cov = json.loads((root / "data" / "split.json").read_text())
    cov_tr = [scan2case[s] for s in cov["scans"]["train"]]
    cov_va = [scan2case[s] for s in cov["scans"]["val"]]
    cov_te = [scan2case[s] for s in cov["scans"]["test"]]
    splits.append({"train": cov_tr, "val": cov_va})
    fold_meta.append(
        {
            "fold": 5,
            "protocol": "CoV holdout (repeat-scan test)",
            "train_cases": cov_tr,
            "val_cases": cov_va,
            "test_cases": cov_te,
            "train_scans": cov["scans"]["train"],
            "val_scans": cov["scans"]["val"],
            "test_scans": cov["scans"]["test"],
        }
    )

    # ---- verification against the existing splits ----
    checks = []
    for k in range(5):
        p = root / "runs_cv5" / f"fold{k}" / "unet" / "test_rows.json"
        existing = sorted(r["scan_id"] for r in json.loads(p.read_text()))
        mine = sorted(fold_meta[k]["test_scans"])
        if existing != mine:
            raise SystemExit(f"fold{k} test scans differ from existing runs_cv5: {mine} vs {existing}")
        checks.append(f"fold{k}: 10 test scans == runs_cv5/fold{k}/unet/test_rows.json")
    if len(cov_tr) != 42 or len(cov_va) != 8 or len(cov_te) != 50:
        raise SystemExit(f"CoV split sizes wrong: {len(cov_tr)}/{len(cov_va)}/{len(cov_te)}")
    # OOF coverage: each of the 50 single-scan subjects exactly once
    oof = [s for k in range(5) for s in fold_meta[k]["test_scans"]]
    if len(oof) != 50 or len({s.rsplit("_r", 1)[0] for s in oof}) != 50:
        raise SystemExit(f"5-fold OOF does not cover 50 distinct subjects exactly once (n={len(oof)})")
    checks.append("5-fold OOF covers 50 distinct subjects exactly once")
    checks.append("CoV split: 42 train / 8 val / 50 test scans == data/split.json")

    outdir.mkdir(parents=True, exist_ok=True)
    id_map = {
        "dataset": ds,
        "n_cases": len(cases),
        "channel_names": dataset_json["channel_names"],
        "labels": dataset_json["labels"],
        "cases": cases,
        "scan_id_to_case": scan2case,
        "case_to_scan_id": {c["case_id"]: c["scan_id"] for c in cases},
    }
    (outdir / "id_map.json").write_text(json.dumps(id_map, indent=2) + "\n")
    (outdir / "splits_final.json").write_text(json.dumps(splits, indent=2) + "\n")
    (outdir / "fold_meta.json").write_text(json.dumps({"folds": fold_meta, "checks": checks}, indent=2) + "\n")

    print(json.dumps({"dataset_dir": str(raw), "n_cases": len(cases), "checks": checks}, indent=2))
    print("splits_final.json ->", outdir / "splits_final.json")
    print("fold sizes:", [(len(s["train"]), len(s["val"])) for s in splits])


if __name__ == "__main__":
    main()
