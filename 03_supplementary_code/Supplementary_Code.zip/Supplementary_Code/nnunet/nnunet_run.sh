#!/bin/bash
# nnunet_run.sh - nnU-Net v2 2D baseline on the existing 5-fold CV + CoV splits.
#   usage: nnunet_run.sh [build|plan|train|predict|eval|all]
# Env vars are set here so every nnU-Net CLI sees the same paths.
set -uo pipefail

ROOT=/root/autodl-tmp/ckd_t2mri_morphometry
VENV=/root/autodl-tmp/envs/nnunetv2b
OUT=$ROOT/runs_rev2026/nnunet
export nnUNet_raw=$ROOT/data/nnunet_raw
export nnUNet_preprocessed=$ROOT/data/nnunet_preprocessed
export nnUNet_results=$OUT/results
export nnUNet_n_proc_DA=8
export OMP_NUM_THREADS=8
export MKL_NUM_THREADS=8
export PYTHONUNBUFFERED=1
PY=$VENV/bin/python
TRAINER=nnUNetTrainer_100epochs
DS=501
CFG=2d
DSE=Dataset501_KidneyHASTE
MODELDIR=$nnUNet_results/$DSE/"$TRAINER"__nnUNetPlans__$CFG

stage=all
if [ $# -gt 0 ]; then stage=$1; fi

say() { echo "=== $(date +%F_%T) $* ==="; }

do_build() {
  say "make_cv_splits (seed 42)"
  mkdir -p $OUT
  $PY $ROOT/scripts/make_cv_splits.py --data $ROOT/data --out $ROOT/data/folds --seed 42 || exit 1
  say "build raw Dataset501"
  $PY $ROOT/scripts/nnunet_build_dataset.py --root $ROOT || exit 1
}

do_plan() {
  say "plan_and_preprocess -d $DS --verify_dataset_integrity -c $CFG"
  $VENV/bin/nnUNetv2_plan_and_preprocess -d $DS --verify_dataset_integrity -c $CFG || exit 1
  say "inject our splits_final.json (folds 0-4 = CV, fold 5 = CoV)"
  cp -f $OUT/splits_final.json $nnUNet_preprocessed/$DSE/splits_final.json || exit 1
  $PY -c "
import json
p='$nnUNet_preprocessed/$DSE/splits_final.json'
s=json.load(open(p))
print('injected splits:', [(len(x['train']),len(x['val'])) for x in s])
assert len(s)==6, len(s)
" || exit 1
}

do_train() {
  for f in 0 1 2 3 4 5; do
    if [ -f $MODELDIR/fold_$f/checkpoint_final.pth ]; then
      say "fold $f already finished - skip"
      continue
    fi
    say "train fold $f ($TRAINER, $CFG)"
    $VENV/bin/nnUNetv2_train $DS $CFG $f -tr $TRAINER || exit 1
  done
}

do_predict() {
  for f in 0 1 2 3 4 5; do
    IN=$OUT/predict_input/fold$f
    OUTF=$OUT/predictions/fold$f
    rm -rf $IN $OUTF
    mkdir -p $IN $OUTF
    $PY -c "
import json
from pathlib import Path
out=Path('$OUT'); f=$f
fm=json.load(open(out/'fold_meta.json'))['folds']
meta=[x for x in fm if x['fold']==f][0]
inp=out/('predict_input/fold%d'%f)
for c in meta['test_cases']:
    src=Path('$nnUNet_raw')/'Dataset501_KidneyHASTE'/'imagesTr'/(c+'_0000.nii.gz')
    (inp/(c+'_0000.nii.gz')).symlink_to(src)
print('fold %d predict input: %d cases'%(f,len(meta['test_cases'])))
" || exit 1
    say "predict fold $f"
    $VENV/bin/nnUNetv2_predict -d $DS -c $CFG -tr $TRAINER -f $f -i $IN -o $OUTF -chk checkpoint_best.pth || exit 1
  done
}

do_eval() {
  say "evaluate"
  $PY $ROOT/scripts/nnunet_eval.py --root $ROOT --outdir $OUT --trainer $TRAINER || exit 1
  say "collect training_log tails"
  mkdir -p $OUT/training_logs
  for f in 0 1 2 3 4 5; do
    L=$(ls $MODELDIR/fold_$f/training_log_*.txt 2>/dev/null | tail -1)
    if [ -n "$L" ]; then cp -f "$L" $OUT/training_logs/fold$f.txt; fi
  done
  ls -la $OUT/training_logs
}

say "stage=$stage"
case $stage in
  build) do_build ;;
  plan) do_plan ;;
  train) do_train ;;
  predict) do_predict ;;
  eval) do_eval ;;
  all) do_build; do_plan; do_train; do_predict; do_eval ;;
  *) echo "unknown stage $stage"; exit 2 ;;
esac
say "stage $stage done"