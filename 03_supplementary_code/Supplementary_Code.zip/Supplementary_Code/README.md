# Supplementary Code — Protocol-specific total kidney volume from coronal T2-HASTE MRI

This package reproduces every number, table and figure in the revised manuscript whose data source is the
public Nottingham T2-weighted kidney MRI archive (Zenodo 10.5281/zenodo.5153568) and the CHAOS MRI
T2-SPIR training set (Zenodo 10.5281/zenodo.3362844). No raw patient data are redistributed; both datasets
are public and are downloaded from Zenodo by the user.

## Contents

| Directory | Contents |
|---|---|
| `scripts/` | Core pipeline: data preparation, 2D training (U-Net / Attention U-Net / U-Net++ / ablations), morphometry, 5-fold split generation, CHAOS evaluation, CHAOS label-budget fine-tuning, cross-protocol analyses, overlay rendering, scan-level volume trainer. |
| `revision_scripts/` | Analyses added in the revision: participant-level CoV/MAE bootstrap intervals, CHAOS label accounting and fold-resolved sensitivity, threshold sensitivity, connected-component audit, overlay array export, CHAOS audit. |
| `figure_scripts/` | Matplotlib scripts that render Figures 1-6 and Figure S1 at 600 dpi (vector PDF also produced). |
| `splits/` | `scans.json` (100 scans with subject, repeat, cohort, spacing), `split.json` (repeat hold-out: 42 train / 8 val / 50 repeat test), `fold0.json`-`fold4.json` and `folds.json` (5-fold subject-level OOF on the 50 single-scan participants, seed 42). |
| `nnunet/` | `splits_final.json` (folds 0-4 = the same OOF folds, fold 5 = the CoV split), `fold_meta.json` (case ids per fold), `id_map.json` (nnU-Net case id to scan id and source file). |

## Environment

Python 3.10+ with PyTorch 2.5.1 (CUDA 12.4), nibabel, numpy, scipy, scikit-image, matplotlib, pandas,
SimpleITK. nnU-Net v2 (2.8.x) is required only for the nnU-Net baseline; install it in a separate
environment (the 2D plan and short trainer are documented in `nnunet/`). The exact run order and seeds
are listed below; all random seeds are 42.

## Run order (HASTE arm)

```bash
# 1. unpack the public archive and write one npz per scan (image windowed to [0,1], binary mask, spacing)
python scripts/prepare.py --raw /path/to/raw --out data

# 2. repeat hold-out (42 train / 8 val / 50 repeat scans) is written by prepare.py; train the three networks
python scripts/train.py --data data --runs runs --models unet,attunet,unetpp --epochs 80 --batch 12
python scripts/train.py --data data --runs runs_ablation --models unet_ds,unetpp_nods --epochs 80 --batch 12

# 3. five-fold OOF on the 50 single-scan participants
python scripts/make_cv_splits.py --data data --out data/folds --seed 42
#    train.py accepts --split data/folds/fold{k}.json and writes runs_cv5/fold{k}/{model}/test_rows.json
python scripts/summarize_cv.py --runs runs_cv5 --out runs_cv5/cv_summary.json
python scripts/morphometry_tables.py --runs runs_cv5 --out runs_cv5/morphometry_tables.json

# 4. volume-level variant (Table S7)
python scripts/train_volume.py --data data --runs runs_vol --split data/folds/fold{k}.json   # repeat per fold
python scripts/summarize_volume_oof.py --runs runs_vol --out runs_vol/volume_oof_summary.json

# 5. polar/mid-kidney decomposition and the CoV/MAE intervals (revision)
python scripts/protocol_boundary_analyses.py --runs runs --out runs/novelty/protocol_boundary.json
python revision_scripts/revision_r1_stats.py       # reads runs/, writes runs_rev2026/revision_r1_stats.json

# 6. CHAOS transfer and label ladder
python scripts/eval_chaos.py --chaos-root /path/to/CHAOS --npz data/chaos_npz --ckpt runs/unetpp/best.pt --out runs/unetpp/chaos_summary.json
python scripts/finetune_chaos_ladder.py --data data --ckpt runs/unetpp/best.pt --out runs/novelty/chaos_ladder.json --sample independent
python scripts/finetune_chaos_ladder.py --data data --out runs/novelty/chaos_ladder_scratch.json --init scratch
python revision_scripts/chaos_audit.py             # component audit, Table S11
python revision_scripts/export_fig_arrays.py       # MRI + probability arrays for Figs. 4 and 6

# 7. figures
python figure_scripts/make_fig1.py ...             # each script writes PDF + 600 dpi PNG
```

## nnU-Net same-split baseline

1. Build the nnU-Net raw dataset from the unpacked NIfTI files with `revision_scripts/nnunet_build_dataset.py`
   (writes `Dataset501_KidneyHASTE/imagesTr`, `labelsTr`, `dataset.json` and verifies each mask against
   `scans.json` and each fold against the stored test rows).
2. `nnUNetv2_plan_and_preprocess -d 501 -c 2d --verify_dataset_integrity`, then copy
   `nnunet/splits_final.json` into the preprocessed dataset folder.
3. Train the five OOF folds and the repeat split with the short 100-epoch 2D trainer:
   `nnUNetv2_train 501 2d {fold} -tr nnUNetTrainer_100epochs` for fold 0-5.
4. Predict the held-out cases and score them with `revision_scripts/nnunet_eval.py`, which imports
   `train.py:laterality()` so Dice, two-component TKV and CoV use exactly the metrics of the other networks.

## Statistical definitions that are easy to mix up

- The independent-draw CHAOS ladder (Table 3) pools all 20 held-out examinations per budget; the fold-resolved
  table (Table S8) reports the median of the five fold-level medians and its range, which is not the same number.
- The from-scratch control was run on the single-permutation prefix subsets, so it is compared with the
  HASTE-initialised prefix draw (Tables S5 and S6), not with the independent-draw ladder.

## Notes and limits

- The public archive contains 100 scans from 60 participants; ten participants were scanned five times
  in one session. No private or re-identifiable data are included in this package.
- Every table in the manuscript names the JSON key it comes from in the revision analyses; the response
  letter lists the analysis file behind each added number.
- The repetition of the pipeline on a different GPU or PyTorch version can move Dice in the third decimal
  through cuDNN nondeterminism; the fold definitions and seeds are therefore shipped with the code.