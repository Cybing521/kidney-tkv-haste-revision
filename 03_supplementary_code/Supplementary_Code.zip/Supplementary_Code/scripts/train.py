#!/usr/bin/env python3
"""Train U-Net / AttUNet / U-Net++ (deep supervision + Focal Dice) and score morphometry."""
from __future__ import annotations

import argparse
import json
import random
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from scipy import ndimage
from torch.utils.data import DataLoader, Dataset


def set_seed(seed: int = 42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


class SliceSet(Dataset):
    def __init__(self, npz_dir: Path, scan_ids: list[str], augment: bool = False):
        self.augment = augment
        self.items = []
        for sid in scan_ids:
            with np.load(npz_dir / f"{sid}.npz") as z:
                img, mask, sp = z["image"].copy(), z["mask"].copy(), z["spacing"].copy()
            axis = int(np.argmin(img.shape))
            img = np.moveaxis(img, axis, 0)
            mask = np.moveaxis(mask, axis, 0)
            for i in range(img.shape[0]):
                self.items.append((img[i].copy(), mask[i].copy(), sid, i, sp, axis, img.shape[0]))

    def __len__(self):
        return len(self.items)

    def __getitem__(self, idx):
        sl, mk, sid, i, sp, axis, nsl = self.items[idx]
        sl = sl.astype(np.float32)
        mk = mk.astype(np.float32)
        if self.augment:
            if random.random() < 0.5:
                sl, mk = np.fliplr(sl).copy(), np.fliplr(mk).copy()
            if random.random() < 0.3:
                sl = np.clip(sl * random.uniform(0.85, 1.15) + random.uniform(-0.05, 0.05), 0, 1)
        sl = torch.from_numpy(resize2d(sl, 256)[None])
        mk = torch.from_numpy(resize2d(mk, 256, mask=True)[None])
        return sl, mk, sid, i, axis, nsl, torch.from_numpy(sp.astype(np.float32))


def resize2d(arr: np.ndarray, size: int, mask: bool = False) -> np.ndarray:
    t = torch.from_numpy(arr[None, None].astype(np.float32))
    kw = {"size": (size, size), "mode": "nearest" if mask else "bilinear"}
    if kw["mode"] == "bilinear":
        kw["align_corners"] = False
    out = F.interpolate(t, **kw)[0, 0].numpy()
    return (out > 0.5).astype(np.float32) if mask else out


class DoubleConv(nn.Module):
    def __init__(self, in_ch, out_ch):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_ch, out_ch, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        return self.net(x)


class UNet(nn.Module):
    def __init__(self, base=32, deep_sup=False):
        super().__init__()
        self.deep_sup = deep_sup
        self.down1 = DoubleConv(1, base)
        self.down2 = DoubleConv(base, base * 2)
        self.down3 = DoubleConv(base * 2, base * 4)
        self.down4 = DoubleConv(base * 4, base * 8)
        self.pool = nn.MaxPool2d(2)
        self.bottleneck = DoubleConv(base * 8, base * 16)
        self.up4 = nn.ConvTranspose2d(base * 16, base * 8, 2, stride=2)
        self.conv4 = DoubleConv(base * 16, base * 8)
        self.up3 = nn.ConvTranspose2d(base * 8, base * 4, 2, stride=2)
        self.conv3 = DoubleConv(base * 8, base * 4)
        self.up2 = nn.ConvTranspose2d(base * 4, base * 2, 2, stride=2)
        self.conv2 = DoubleConv(base * 4, base * 2)
        self.up1 = nn.ConvTranspose2d(base * 2, base, 2, stride=2)
        self.conv1 = DoubleConv(base * 2, base)
        self.out = nn.Conv2d(base, 1, 1)
        if deep_sup:
            self.head2 = nn.Conv2d(base * 2, 1, 1)
            self.head3 = nn.Conv2d(base * 4, 1, 1)
            self.head4 = nn.Conv2d(base * 8, 1, 1)

    def forward(self, x):
        d1 = self.down1(x)
        d2 = self.down2(self.pool(d1))
        d3 = self.down3(self.pool(d2))
        d4 = self.down4(self.pool(d3))
        b = self.bottleneck(self.pool(d4))
        x4 = self.conv4(torch.cat([self.up4(b), d4], 1))
        x3 = self.conv3(torch.cat([self.up3(x4), d3], 1))
        x2 = self.conv2(torch.cat([self.up2(x3), d2], 1))
        x1 = self.conv1(torch.cat([self.up1(x2), d1], 1))
        full = self.out(x1)
        if not self.deep_sup:
            return [full]
        size = x1.shape[-2:]
        h2 = self.head2(F.interpolate(x2, size=size, mode="bilinear", align_corners=False))
        h3 = self.head3(F.interpolate(x3, size=size, mode="bilinear", align_corners=False))
        h4 = self.head4(F.interpolate(x4, size=size, mode="bilinear", align_corners=False))
        return [full, h2, h3, h4]


class AttentionGate(nn.Module):
    def __init__(self, f_g, f_l, f_int):
        super().__init__()
        self.w_g = nn.Sequential(nn.Conv2d(f_g, f_int, 1), nn.BatchNorm2d(f_int))
        self.w_x = nn.Sequential(nn.Conv2d(f_l, f_int, 1), nn.BatchNorm2d(f_int))
        self.psi = nn.Sequential(nn.Conv2d(f_int, 1, 1), nn.BatchNorm2d(1), nn.Sigmoid())
        self.relu = nn.ReLU(inplace=True)

    def forward(self, g, x):
        return x * self.psi(self.relu(self.w_g(g) + self.w_x(x)))


class AttUNet(nn.Module):
    def __init__(self, base=32):
        super().__init__()
        self.down1 = DoubleConv(1, base)
        self.down2 = DoubleConv(base, base * 2)
        self.down3 = DoubleConv(base * 2, base * 4)
        self.down4 = DoubleConv(base * 4, base * 8)
        self.pool = nn.MaxPool2d(2)
        self.bottleneck = DoubleConv(base * 8, base * 16)
        self.up4 = nn.ConvTranspose2d(base * 16, base * 8, 2, stride=2)
        self.att4 = AttentionGate(base * 8, base * 8, base * 4)
        self.conv4 = DoubleConv(base * 16, base * 8)
        self.up3 = nn.ConvTranspose2d(base * 8, base * 4, 2, stride=2)
        self.att3 = AttentionGate(base * 4, base * 4, base * 2)
        self.conv3 = DoubleConv(base * 8, base * 4)
        self.up2 = nn.ConvTranspose2d(base * 4, base * 2, 2, stride=2)
        self.att2 = AttentionGate(base * 2, base * 2, base)
        self.conv2 = DoubleConv(base * 4, base * 2)
        self.up1 = nn.ConvTranspose2d(base * 2, base, 2, stride=2)
        self.att1 = AttentionGate(base, base, base // 2)
        self.conv1 = DoubleConv(base * 2, base)
        self.out = nn.Conv2d(base, 1, 1)

    def forward(self, x):
        d1 = self.down1(x)
        d2 = self.down2(self.pool(d1))
        d3 = self.down3(self.pool(d2))
        d4 = self.down4(self.pool(d3))
        b = self.bottleneck(self.pool(d4))
        g4 = self.up4(b)
        x = self.conv4(torch.cat([g4, self.att4(g4, d4)], 1))
        g3 = self.up3(x)
        x = self.conv3(torch.cat([g3, self.att3(g3, d3)], 1))
        g2 = self.up2(x)
        x = self.conv2(torch.cat([g2, self.att2(g2, d2)], 1))
        g1 = self.up1(x)
        x = self.conv1(torch.cat([g1, self.att1(g1, d1)], 1))
        return [self.out(x)]


class UNetPP(nn.Module):
    def __init__(self, base=32, deep_sup=True):
        super().__init__()
        self.deep_sup = deep_sup
        nb = [base, base * 2, base * 4, base * 8, base * 16]
        self.pool = nn.MaxPool2d(2)
        self.up = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=True)
        self.conv0_0 = DoubleConv(1, nb[0])
        self.conv1_0 = DoubleConv(nb[0], nb[1])
        self.conv2_0 = DoubleConv(nb[1], nb[2])
        self.conv3_0 = DoubleConv(nb[2], nb[3])
        self.conv4_0 = DoubleConv(nb[3], nb[4])
        self.conv0_1 = DoubleConv(nb[0] + nb[1], nb[0])
        self.conv1_1 = DoubleConv(nb[1] + nb[2], nb[1])
        self.conv2_1 = DoubleConv(nb[2] + nb[3], nb[2])
        self.conv3_1 = DoubleConv(nb[3] + nb[4], nb[3])
        self.conv0_2 = DoubleConv(nb[0] * 2 + nb[1], nb[0])
        self.conv1_2 = DoubleConv(nb[1] * 2 + nb[2], nb[1])
        self.conv2_2 = DoubleConv(nb[2] * 2 + nb[3], nb[2])
        self.conv0_3 = DoubleConv(nb[0] * 3 + nb[1], nb[0])
        self.conv1_3 = DoubleConv(nb[1] * 3 + nb[2], nb[1])
        self.conv0_4 = DoubleConv(nb[0] * 4 + nb[1], nb[0])
        self.head1 = nn.Conv2d(nb[0], 1, 1)
        self.head2 = nn.Conv2d(nb[0], 1, 1)
        self.head3 = nn.Conv2d(nb[0], 1, 1)
        self.head4 = nn.Conv2d(nb[0], 1, 1)

    def forward(self, x):
        x0_0 = self.conv0_0(x)
        x1_0 = self.conv1_0(self.pool(x0_0))
        x0_1 = self.conv0_1(torch.cat([x0_0, self.up(x1_0)], 1))
        x2_0 = self.conv2_0(self.pool(x1_0))
        x1_1 = self.conv1_1(torch.cat([x1_0, self.up(x2_0)], 1))
        x0_2 = self.conv0_2(torch.cat([x0_0, x0_1, self.up(x1_1)], 1))
        x3_0 = self.conv3_0(self.pool(x2_0))
        x2_1 = self.conv2_1(torch.cat([x2_0, self.up(x3_0)], 1))
        x1_2 = self.conv1_2(torch.cat([x1_0, x1_1, self.up(x2_1)], 1))
        x0_3 = self.conv0_3(torch.cat([x0_0, x0_1, x0_2, self.up(x1_2)], 1))
        x4_0 = self.conv4_0(self.pool(x3_0))
        x3_1 = self.conv3_1(torch.cat([x3_0, self.up(x4_0)], 1))
        x2_2 = self.conv2_2(torch.cat([x2_0, x2_1, self.up(x3_1)], 1))
        x1_3 = self.conv1_3(torch.cat([x1_0, x1_1, x1_2, self.up(x2_2)], 1))
        x0_4 = self.conv0_4(torch.cat([x0_0, x0_1, x0_2, x0_3, self.up(x1_3)], 1))
        full = self.head4(x0_4)
        if not self.deep_sup:
            return [full]
        return [full, self.head3(x0_3), self.head2(x0_2), self.head1(x0_1)]


def _build_model(name: str) -> nn.Module:
    if name == "unet":
        return UNet(deep_sup=False)
    if name == "unet_ds":
        return UNet(deep_sup=True)
    if name == "attunet":
        return AttUNet()
    if name == "unetpp":
        return UNetPP(deep_sup=True)
    if name == "unetpp_nods":
        return UNetPP(deep_sup=False)
    raise KeyError(name)


MODELS = {"unet": UNet, "attunet": AttUNet, "unetpp": UNetPP, "unet_ds": UNet, "unetpp_nods": UNetPP}


def dice_coef(prob, target, eps=1e-6):
    p = prob.reshape(prob.size(0), -1)
    t = target.reshape(target.size(0), -1)
    inter = (p * t).sum(1)
    return ((2 * inter + eps) / (p.sum(1) + t.sum(1) + eps)).mean()


def focal_dice(logits, target):
    prob = torch.sigmoid(logits)
    p = prob.detach()
    pt = p * target + (1 - p) * (1 - target)
    focal = ((1 - pt) ** 2 * F.binary_cross_entropy_with_logits(logits, target, reduction="none")).mean()
    return focal + 2.0 * (1.0 - dice_coef(prob, target))


def deepsup_loss(outs, target):
    weights = [1.0, 0.5, 0.25, 0.125]
    loss = 0.0
    for w, o in zip(weights, outs):
        loss = loss + w * focal_dice(o, target)
    return loss / sum(weights[: len(outs)])


def laterality(mask: np.ndarray, spacing: np.ndarray) -> dict:
    labeled, n = ndimage.label(mask > 0)
    if n == 0:
        return {"tkv_ml": 0.0, "left_ml": 0.0, "right_ml": 0.0, "laterality": 0.0, "elongation": 0.0}
    sizes = ndimage.sum(mask > 0, labeled, index=list(range(1, n + 1)))
    order = np.argsort(sizes)[::-1]
    keep = order[:2]
    vox_ml = float(np.prod(spacing) / 1000.0)
    comps = []
    for idx in keep:
        sel = labeled == (idx + 1)
        coords = np.argwhere(sel)
        centroid = coords.mean(0)
        comps.append((sel.sum() * vox_ml, centroid, sel))
    comps = sorted(comps, key=lambda c: c[1][0])
    left_ml = float(comps[-1][0]) if len(comps) == 2 else 0.0
    right_ml = float(comps[0][0]) if len(comps) == 2 else float(comps[0][0])
    tkv = left_ml + right_ml if len(comps) == 2 else float(comps[0][0])
    lat = (left_ml - right_ml) / (tkv + 1e-6)
    coords = np.argwhere(mask > 0) * spacing
    elong = 0.0
    if len(coords) > 10:
        cov = np.cov(coords.T)
        w = np.linalg.eigvalsh(cov)
        elong = float(np.sqrt(w[-1] / (w[0] + 1e-8)))
    return {"tkv_ml": tkv, "left_ml": left_ml, "right_ml": right_ml, "laterality": float(lat), "elongation": elong}


@torch.no_grad()
def predict_volumes(model, npz_dir: Path, scan_ids: list[str], device, scans_meta: dict):
    model.eval()
    rows = []
    for sid in scan_ids:
        with np.load(npz_dir / f"{sid}.npz") as z:
            img, gt, sp = z["image"], z["mask"] > 0, z["spacing"]
        axis = int(np.argmin(img.shape))
        sl = np.moveaxis(img, axis, 0)
        preds = []
        for i in range(sl.shape[0]):
            x = torch.from_numpy(resize2d(sl[i], 256)[None, None]).to(device)
            logit = model(x)[0]
            pr = F.interpolate(torch.sigmoid(logit), size=sl[i].shape, mode="bilinear", align_corners=False)
            preds.append((pr[0, 0].cpu().numpy() > 0.5).astype(np.uint8))
        pred = np.stack(preds, 0)
        pred = np.moveaxis(pred, 0, axis)
        if pred.shape != gt.shape:
            pred = pred[: gt.shape[0], : gt.shape[1], : gt.shape[2]]
        inter = float((pred & gt).sum())
        dice = (2 * inter + 1e-6) / (pred.sum() + gt.sum() + 1e-6)
        gm, pm = laterality(gt, sp), laterality(pred, sp)
        meta = scans_meta.get(sid, {})
        rows.append(
            {
                "scan_id": sid,
                "subject": meta.get("subject", sid.rsplit("_", 1)[0]),
                "cohort": meta.get("cohort"),
                "repeat": meta.get("repeat"),
                "ckd_stage": meta.get("ckd_stage"),
                "dice": float(dice),
                "gt": gm,
                "pr": pm,
                "tkv_abs_ml": abs(pm["tkv_ml"] - gm["tkv_ml"]),
            }
        )
    return rows


def summarize(rows: list[dict]) -> dict:
    dices = [r["dice"] for r in rows]
    tkv_err = [r["tkv_abs_ml"] for r in rows]
    by_subj = {}
    for r in rows:
        by_subj.setdefault(r["subject"], []).append(r["pr"]["tkv_ml"])
    covs = []
    for vals in by_subj.values():
        if len(vals) >= 3 and np.mean(vals) > 0:
            covs.append(float(np.std(vals, ddof=1) / np.mean(vals)))
    gt_tkv = np.array([r["gt"]["tkv_ml"] for r in rows])
    pr_tkv = np.array([r["pr"]["tkv_ml"] for r in rows])
    corr = float(np.corrcoef(gt_tkv, pr_tkv)[0, 1]) if gt_tkv.std() > 1e-6 and pr_tkv.std() > 1e-6 else None
    if corr is not None and not np.isfinite(corr):
        corr = None
    return {
        "n": len(rows),
        "dice_mean": float(np.mean(dices)),
        "dice_std": float(np.std(dices)),
        "tkv_mae_ml": float(np.mean(tkv_err)),
        "tkv_corr": corr,
        "repeat_cov_mean": float(np.mean(covs)) if covs else None,
        "n_repeat_subjects": len(covs),
    }


def train_model(name, data, runs, epochs, batch, device, smoke=False, split_path=None):
    split = json.loads((split_path or (data / "split.json")).read_text())
    scans = {r["scan_id"]: r for r in json.loads((data / "scans.json").read_text())}
    npz_dir = data / "npz"
    tr = DataLoader(SliceSet(npz_dir, split["scans"]["train"], True), batch_size=batch, shuffle=True, num_workers=2)
    va_ids = split["scans"]["val"]
    te_ids = split["scans"]["test"]
    if smoke:
        epochs = 1
        va_ids, te_ids = va_ids[:2], te_ids[:2]
        tr = DataLoader(SliceSet(npz_dir, split["scans"]["train"][:2], True), batch_size=2, shuffle=True)
    model = _build_model(name).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=2e-4, weight_decay=1e-4)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs)
    outdir = runs / name
    outdir.mkdir(parents=True, exist_ok=True)
    best, stale, best_state = -1.0, 0, None
    for ep in range(epochs):
        model.train()
        total, n = 0.0, 0
        for x, y, *_ in tr:
            x, y = x.to(device), y.to(device)
            opt.zero_grad(set_to_none=True)
            loss = deepsup_loss(model(x), y)
            loss.backward()
            opt.step()
            total += float(loss.detach())
            n += 1
            if smoke and n >= 2:
                break
        sched.step()
        val_rows = predict_volumes(model, npz_dir, va_ids, device, scans)
        val = summarize(val_rows)
        improved = val["dice_mean"] > best + 1e-5
        if improved:
            best, stale, best_state = val["dice_mean"], 0, {k: v.cpu() for k, v in model.state_dict().items()}
        else:
            stale += 1
        rec = {"epoch": ep + 1, "loss": total / max(n, 1), "val": val}
        with (outdir / "history.jsonl").open("a") as f:
            f.write(json.dumps(rec) + "\n")
        print(json.dumps(rec), flush=True)
        if stale >= 12 and not smoke:
            break
    if best_state:
        model.load_state_dict(best_state)
    torch.save({"model": model.state_dict(), "name": name}, outdir / "best.pt")
    test_rows = predict_volumes(model, npz_dir, te_ids, device, scans)
    summary = {"model": name, "val_best_dice": best, "test": summarize(test_rows)}
    (outdir / "summary.json").write_text(json.dumps(summary, indent=2))
    (outdir / "test_rows.json").write_text(json.dumps(test_rows, indent=2))
    print(json.dumps(summary, indent=2), flush=True)
    return summary


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", type=Path, required=True)
    ap.add_argument("--runs", type=Path, required=True)
    ap.add_argument("--split", type=Path, default=None)
    ap.add_argument("--models", default="unet,attunet,unetpp")
    ap.add_argument("--epochs", type=int, default=80)
    ap.add_argument("--batch", type=int, default=12)
    ap.add_argument("--smoke", action="store_true")
    args = ap.parse_args()
    set_seed(42)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    args.runs.mkdir(parents=True, exist_ok=True)
    names = [n.strip() for n in args.models.split(",") if n.strip()]
    split_path = args.split or (args.data / "split.json")
    all_sum = []
    for name in names:
        all_sum.append(
            train_model(name, args.data, args.runs, args.epochs, args.batch, device, args.smoke, split_path)
        )
    out_name = "compare_ablation.json" if any(n in {"unet_ds", "unetpp_nods"} for n in names) else "compare.json"
    (args.runs / out_name).write_text(json.dumps(all_sum, indent=2))


if __name__ == "__main__":
    main()
