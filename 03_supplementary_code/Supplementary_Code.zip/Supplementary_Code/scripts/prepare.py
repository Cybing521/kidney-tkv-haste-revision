#!/usr/bin/env python3
"""Unpack Nottingham T2 kidney MRI and write per-scan npz + split.json."""
from __future__ import annotations

import argparse
import csv
import io
import json
import re
import zipfile
from collections import defaultdict
from pathlib import Path

import nibabel as nib
import numpy as np

SCAN_RE = re.compile(r"^(HC|CKD)_(\d{2})_T2W(?:_(\d))?$", re.I)


def window_volume(vol: np.ndarray) -> np.ndarray:
    x = vol.astype(np.float32)
    mu, sd = float(x.mean()), float(x.std() + 1e-6)
    lo, hi = mu - 0.5 * sd, mu + 4.0 * sd
    return np.clip((x - lo) / (hi - lo), 0, 1)


def extract_raw(raw: Path, unpacked: Path) -> Path:
    unpacked.mkdir(parents=True, exist_ok=True)
    csv_path = unpacked / "subject_information.csv"
    archives = list(raw.glob("*.zip"))
    for zpath in archives:
        with zipfile.ZipFile(zpath) as zf:
            names = zf.namelist()
            if any(n.endswith(".zip") for n in names) and "subject_information.csv" in names:
                csv_path.write_bytes(zf.read("subject_information.csv"))
                for inner in ("Healthy_Control.zip", "CKD.zip"):
                    dest = unpacked / inner
                    if not dest.exists():
                        dest.write_bytes(zf.read(inner))
            elif any(n.endswith(".nii.gz") for n in names):
                zf.extractall(unpacked / zpath.stem)
    for inner in list(unpacked.glob("*.zip")):
        with zipfile.ZipFile(inner) as zf:
            zf.extractall(unpacked / inner.stem)
    if not csv_path.exists():
        src = raw / "subject_information.csv"
        if src.exists():
            csv_path.write_bytes(src.read_bytes())
    return csv_path


def parse_scan_id(name: str) -> tuple[str, str, int] | None:
    stem = name.replace(".nii.gz", "")
    m = SCAN_RE.match(stem)
    if not m:
        return None
    cohort, num, rep = m.group(1).upper(), m.group(2), m.group(3)
    repeat = int(rep) if rep else 1
    subject = f"{cohort}_{num}"
    scan_id = f"{subject}_r{repeat}"
    return subject, scan_id, repeat


def load_csv(path: Path) -> dict[str, dict]:
    if not path.exists():
        return {}
    text = path.read_text(encoding="utf-8-sig")
    rows = list(csv.DictReader(io.StringIO(text)))
    return {r["Label"].strip(): r for r in rows if r.get("Label")}


def pair_from_unpacked(unpacked: Path) -> list[tuple[Path, Path, dict]]:
    niftis = [p for p in unpacked.rglob("*.nii.gz") if p.is_file()]
    masks = {p.name.replace("_mask.nii.gz", ".nii.gz"): p for p in niftis if "_mask.nii.gz" in p.name}
    pairs = []
    for img in niftis:
        if "_mask.nii.gz" in img.name:
            continue
        mask = masks.get(img.name)
        parsed = parse_scan_id(img.name)
        if mask is None or parsed is None:
            continue
        subject, scan_id, repeat = parsed
        cohort = "ckd" if subject.startswith("CKD") else "hc"
        pairs.append((img, mask, {"subject": subject, "scan_id": scan_id, "repeat": repeat, "cohort": cohort}))
    if len(pairs) != 100:
        raise SystemExit(f"expected 100 scans, got {len(pairs)}")
    return pairs


def write_npz(img_p: Path, mask_p: Path, dest: Path) -> dict:
    img_nii, mask_nii = nib.load(str(img_p)), nib.load(str(mask_p))
    img = np.squeeze(np.asanyarray(img_nii.dataobj))
    mask = np.squeeze(np.asanyarray(mask_nii.dataobj))
    if img.shape != mask.shape:
        raise ValueError(f"shape mismatch {img_p} {img.shape} vs {mask.shape}")
    zooms = [float(z) for z in img_nii.header.get_zooms()[:3]]
    dest.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        dest,
        image=window_volume(img).astype(np.float32),
        mask=(mask > 0).astype(np.uint8),
        spacing=np.array(zooms, dtype=np.float32),
    )
    return {"shape": [int(x) for x in img.shape], "spacing": zooms, "tkv_vox": int((mask > 0).sum())}


def make_split(records: list[dict]) -> dict:
    by_subj = defaultdict(list)
    for r in records:
        by_subj[r["subject"]].append(r["scan_id"])
    test_subj = sorted(s for s, ids in by_subj.items() if len(ids) >= 5)
    if len(test_subj) != 10:
        raise SystemExit(f"expected 10 repeated test subjects, got {test_subj}")
    rest = sorted(s for s in by_subj if s not in set(test_subj))
    # 4 HC + 4 CKD val, rest train; keep seedless deterministic by label order
    hc = [s for s in rest if s.startswith("HC")]
    ckd = [s for s in rest if s.startswith("CKD")]
    val_subj = set(hc[:4] + ckd[:4])
    train_subj = set(rest) - val_subj
    split_scans = {"train": [], "val": [], "test": []}
    for r in records:
        if r["subject"] in test_subj:
            split_scans["test"].append(r["scan_id"])
        elif r["subject"] in val_subj:
            split_scans["val"].append(r["scan_id"])
        else:
            split_scans["train"].append(r["scan_id"])
    return {
        "protocol": "Daniel holdout: 10 subjects with 5 same-session repeats as test",
        "n_subject": {"train": len(train_subj), "val": len(val_subj), "test": len(test_subj)},
        "n_scan": {k: len(v) for k, v in split_scans.items()},
        "test_subjects": test_subj,
        "val_subjects": sorted(val_subj),
        "train_subjects": sorted(train_subj),
        "scans": split_scans,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()
    unpacked = args.out / "unpacked"
    npz_dir = args.out / "npz"
    csv_path = extract_raw(args.raw, unpacked)
    info = load_csv(csv_path)
    records = []
    for img_p, mask_p, meta in pair_from_unpacked(unpacked):
        rec = {**meta, **write_npz(img_p, mask_p, npz_dir / f"{meta['scan_id']}.npz")}
        row = info.get(meta["subject"], {})
        rec["age"] = row.get("Age")
        rec["sex"] = row.get("Sex")
        rec["ckd_stage"] = row.get("CKD_Stage")
        records.append(rec)
    split = make_split(records)
    (args.out / "scans.json").write_text(json.dumps(records, indent=2))
    (args.out / "split.json").write_text(json.dumps(split, indent=2))
    print(json.dumps({"n_scan": len(records), "split": split["n_scan"], "test_subjects": split["test_subjects"]}, indent=2))


if __name__ == "__main__":
    main()
