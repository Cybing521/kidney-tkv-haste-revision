#!/usr/bin/env python3
"""Polar-slice Dice vs scan Dice, and CHAOS native vs intensity-matched transfer."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
SKILL_SCRIPTS = Path.home() / ".claude/skills/scientific-figures/scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from publication_style import (  # noqa: E402
    PALETTE,
    FigureStyle,
    apply_publication_style,
    create_subplots,
    finalize_figure,
    make_scatter,
    qa_before_save,
)

OUT = Path(__file__).resolve().parent
DATA = json.loads((ROOT / "05_验证记录/protocol_boundary_partial.json").read_text())


def main() -> Path:
    apply_publication_style(FigureStyle(font_size=11, axes_linewidth=1.4, cjk=False))
    fig, axes = create_subplots(1, 2, figsize=(9.6, 4.2))
    ax0, ax1 = axes

    polar_rows = DATA["haste_polar_log"]
    scan = np.array([r["dice"] for r in polar_rows], dtype=float)
    polar = np.array([r["dice_polar"] for r in polar_rows], dtype=float)
    finite = np.isfinite(polar)
    ax0.scatter(
        scan[finite],
        polar[finite],
        s=36,
        color=PALETTE["blue_main"],
        edgecolors="black",
        linewidths=0.4,
        zorder=3,
        label=f"n={int(finite.sum())} of 50 scans",
    )
    ax0.plot([0.0, 1.0], [0.0, 1.0], color="black", linewidth=1.0, linestyle="--", zorder=0)
    polar_mean = float(np.mean(polar[finite]))
    ax0.axhline(polar_mean, color=PALETTE["red_strong"], linewidth=1.1, linestyle=":", zorder=1)
    ax0.set_xlim(0.85, 1.0)
    ax0.set_ylim(0.0, 1.0)
    ax0.set_xlabel("Scan Dice")
    ax0.set_ylabel("Polar-slice Dice")
    ax0.legend(loc="lower left", fontsize=8, frameon=False)
    ax0.text(
        0.86,
        polar_mean + 0.03,
        f"mean polar Dice {polar_mean:.2f}",
        color=PALETTE["red_strong"],
        fontsize=8,
        va="bottom",
    )
    ax0.text(-0.14, 1.06, "A", transform=ax0.transAxes, fontweight="bold", fontsize=13)

    native = {r["scan_id"]: r["dice"] for r in DATA["chaos_by_condition"]["native"]}
    matched = {r["scan_id"]: r["dice"] for r in DATA["chaos_by_condition"]["hist_match"]}
    keys = sorted(native)
    x = np.array([native[k] for k in keys], dtype=float)
    y = np.array([matched[k] for k in keys], dtype=float)
    make_scatter(ax1, x, y, label="CHAOS T2-SPIR (n=20)", color=PALETTE["red_strong"], size=36)
    hi = float(max(x.max(), y.max()) + 0.05)
    ax1.plot([0, hi], [0, hi], color="black", linewidth=1.0, linestyle="--", zorder=0)
    ax1.set_xlim(0, hi)
    ax1.set_ylim(0, hi)
    ax1.set_xlabel("Zero-shot Dice")
    ax1.set_ylabel("Intensity-matched Dice")
    ax1.set_aspect("equal", adjustable="box")
    ax1.legend(loc="upper left", fontsize=8, frameon=False)
    ax1.text(-0.14, 1.06, "B", transform=ax1.transAxes, fontweight="bold", fontsize=13)

    qa = qa_before_save(fig)
    if qa.get("defects"):
        print("qa", qa)
    out = OUT / "fig_polar_protocol"
    finalize_figure(fig, out, formats=["png", "pdf"], dpi=300)
    return Path(str(out) + ".png")


if __name__ == "__main__":
    print("wrote", main())
