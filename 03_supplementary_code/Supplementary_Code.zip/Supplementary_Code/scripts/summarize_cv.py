#!/usr/bin/env python3
"""Pool 5-fold OOF rows and compare models on 50 independent single-scan subjects."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.stats import wilcoxon


def load_rows(runs: Path, fold: int, model: str) -> list[dict]:
    path = runs / f"fold{fold}" / model / "test_rows.json"
    return json.loads(path.read_text())


def summarize(rows: list[dict]) -> dict:
    dice = np.array([r["dice"] for r in rows], dtype=float)
    mae = np.array([r["tkv_abs_ml"] for r in rows], dtype=float)
    gt = np.array([r["gt"]["tkv_ml"] for r in rows], dtype=float)
    pr = np.array([r["pr"]["tkv_ml"] for r in rows], dtype=float)
    corr = float(np.corrcoef(gt, pr)[0, 1]) if gt.std() > 1e-6 and pr.std() > 1e-6 else None
    return {
        "n": len(rows),
        "dice_mean": float(dice.mean()),
        "dice_std": float(dice.std(ddof=0)),
        "tkv_mae_ml": float(mae.mean()),
        "tkv_mae_std": float(mae.std(ddof=0)),
        "tkv_corr": corr,
    }


def paired(a: np.ndarray, b: np.ndarray, n_boot: int = 10000, seed: int = 42) -> dict:
    diff = a - b
    rng = np.random.RandomState(seed)
    boots = [float(diff[rng.randint(0, len(diff), len(diff))].mean()) for _ in range(n_boot)]
    stat, p = wilcoxon(a, b, alternative="two-sided", zero_method="wilcox")
    return {
        "mean_diff": float(diff.mean()),
        "ci95": [float(np.percentile(boots, 2.5)), float(np.percentile(boots, 97.5))],
        "wilcoxon_stat": float(stat),
        "p": float(p),
        "n": int(len(diff)),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()
    models = ["unet", "attunet", "unetpp"]
    pooled = {m: [] for m in models}
    per_fold = []
    for k in range(5):
        fold_rec = {"fold": k}
        for m in models:
            rows = load_rows(args.runs, k, m)
            pooled[m].extend(rows)
            fold_rec[m] = summarize(rows)
        per_fold.append(fold_rec)
    oof = {m: summarize(pooled[m]) for m in models}
    mae = {m: np.array([r["tkv_abs_ml"] for r in pooled[m]], dtype=float) for m in models}
    dice = {m: np.array([r["dice"] for r in pooled[m]], dtype=float) for m in models}
    pairwise = {
        "unet_minus_unetpp_mae": paired(mae["unet"], mae["unetpp"]),
        "attunet_minus_unetpp_mae": paired(mae["attunet"], mae["unetpp"]),
        "unet_minus_attunet_mae": paired(mae["unet"], mae["attunet"]),
        "unet_minus_unetpp_dice": paired(dice["unet"], dice["unetpp"]),
    }
    out = {"n_oof_scans": 50, "per_fold": per_fold, "oof": oof, "pairwise_n50": pairwise}
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(out, indent=2))
    print(json.dumps({"oof": oof, "pairwise_n50": pairwise}, indent=2))


if __name__ == "__main__":
    main()
