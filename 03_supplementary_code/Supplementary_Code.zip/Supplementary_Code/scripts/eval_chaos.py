#!/usr/bin/env python3
"""CHAOS MRI kidney-only cross-domain eval. Anatomy transfer, not a CKD cohort."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import nibabel as nib
import numpy as np
import torch

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from prepare import window_volume  # noqa: E402
from train import MODELS, predict_volumes, summarize  # noqa: E402


def kidney_mask(lab: np.ndarray) -> np.ndarray:
    if lab.ndim == 4:
        # one-hot (C,H,W,D) CHAOS: liver, right kidney, left kidney, spleen
        if lab.shape[0] <= 8:
            if lab.shape[0] >= 3:
                return (lab[1] > 0.5) | (lab[2] > 0.5)
            return lab[0] > 0.5
        if lab.shape[-1] <= 8:
            return (lab[..., 1] > 0.5) | (lab[..., 2] > 0.5)
    u = set(np.unique(lab).tolist())
    u.discard(0)
    if not u:
        return lab > 0
    if u <= {1}:
        return lab > 0
    if {2, 3} <= u:
        return np.isin(lab, [2, 3])
    if {126, 189} <= u:
        return np.isin(lab, [126, 189])
    vals = sorted(u)
    if len(vals) >= 3:
        return np.isin(lab, vals[1:3])
    return np.isin(lab, vals)


def collect_pairs(root: Path) -> list[tuple[Path, Path, str]]:
    pairs = []
    for img in sorted(root.glob("Train_Sets/MR/*/T2SPIR/**/*.nii.gz")):
        pid = img.parts[img.parts.index("MR") + 1]
        mask = root / "Train_Sets" / "MR" / pid / "t2_label.nii.gz"
        if mask.exists():
            pairs.append((img, mask, f"chaos_t2_{pid}"))
    return pairs


def to_npz(pairs: list[tuple[Path, Path, str]], dest: Path) -> list[str]:
    dest.mkdir(parents=True, exist_ok=True)
    ids = []
    meta = {}
    for img_p, mask_p, pid in pairs:
        img_nii, mask_nii = nib.load(str(img_p)), nib.load(str(mask_p))
        img = np.squeeze(np.asanyarray(img_nii.dataobj))
        lab = np.asanyarray(mask_nii.dataobj)
        kidney = kidney_mask(lab)
        kidney = np.squeeze(kidney)
        if img.ndim != 3 or kidney.ndim != 3:
            continue
        if img.shape != kidney.shape:
            continue
        if kidney.sum() < 100:
            continue
        sid = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in pid)
        zooms = [float(z) for z in img_nii.header.get_zooms()[:3]]
        np.savez_compressed(
            dest / f"{sid}.npz",
            image=window_volume(img).astype(np.float32),
            mask=kidney.astype(np.uint8),
            spacing=np.array(zooms, dtype=np.float32),
        )
        ids.append(sid)
        meta[sid] = {"subject": sid, "cohort": "chaos_t2", "repeat": 1, "ckd_stage": None}
    (dest.parent / "chaos_meta.json").write_text(json.dumps(meta, indent=2))
    return ids


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--chaos-root", type=Path, required=True)
    ap.add_argument("--npz", type=Path, required=True)
    ap.add_argument("--ckpt", type=Path, required=True)
    ap.add_argument("--model", default="unetpp")
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()
    pairs = collect_pairs(args.chaos_root)
    ids = to_npz(pairs, args.npz)
    if not ids:
        niftis = list(args.chaos_root.rglob("*.nii.gz"))
        raise SystemExit(f"no CHAOS T2 pairs; niftis={len(niftis)} sample={[str(p) for p in niftis[:8]]}")
    meta = json.loads((args.npz.parent / "chaos_meta.json").read_text())
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = MODELS[args.model]().to(device)
    ck = torch.load(args.ckpt, map_location="cpu", weights_only=False)
    model.load_state_dict(ck["model"])
    rows = predict_volumes(model, args.npz, ids, device, meta)
    summary = {
        "dataset": "CHAOS MRI T2",
        "claim": "anatomy transfer only; no CKD labels",
        "n_pair_found": len(pairs),
        "n_eval": len(ids),
        "model": args.model,
        "metrics": summarize(rows),
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(summary, indent=2))
    (args.out.parent / "chaos_rows.json").write_text(json.dumps(rows, indent=2))
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
