#!/usr/bin/env python3
"""5-fold subject-level splits on the 50 single-scan people; 10 repeat subjects stay out."""
from __future__ import annotations

import argparse
import json
from collections import defaultdict
from pathlib import Path

import numpy as np


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()
    records = json.loads((args.data / "scans.json").read_text())
    by_subj = defaultdict(list)
    cohort = {}
    for r in records:
        by_subj[r["subject"]].append(r["scan_id"])
        cohort[r["subject"]] = r["cohort"]
    repeat_subj = sorted(s for s, ids in by_subj.items() if len(ids) >= 5)
    singles = sorted(s for s in by_subj if s not in set(repeat_subj))
    hc = [s for s in singles if s.startswith("HC")]
    ckd = [s for s in singles if s.startswith("CKD")]
    if len(hc) != 25 or len(ckd) != 25:
        raise SystemExit(f"expected 25+25 singles, got HC={len(hc)} CKD={len(ckd)}")
    rng = np.random.RandomState(args.seed)
    rng.shuffle(hc)
    rng.shuffle(ckd)
    args.out.mkdir(parents=True, exist_ok=True)
    meta = []
    for k in range(5):
        test_subj = sorted(hc[k * 5 : (k + 1) * 5] + ckd[k * 5 : (k + 1) * 5])
        rest = [s for s in singles if s not in set(test_subj)]
        rest_hc = sorted(s for s in rest if s.startswith("HC"))
        rest_ckd = sorted(s for s in rest if s.startswith("CKD"))
        val_subj = sorted(rest_hc[:4] + rest_ckd[:4])
        train_subj = sorted(set(rest) - set(val_subj))
        split_scans = {"train": [], "val": [], "test": []}
        for r in records:
            sid, subj = r["scan_id"], r["subject"]
            if subj in test_subj:
                split_scans["test"].append(sid)
            elif subj in val_subj:
                split_scans["val"].append(sid)
            elif subj in train_subj:
                split_scans["train"].append(sid)
        split = {
            "protocol": "5-fold subject CV on 50 single-scan subjects; 10 repeat subjects held out",
            "fold": k,
            "seed": args.seed,
            "n_subject": {"train": len(train_subj), "val": len(val_subj), "test": len(test_subj)},
            "n_scan": {key: len(v) for key, v in split_scans.items()},
            "test_subjects": test_subj,
            "val_subjects": val_subj,
            "train_subjects": train_subj,
            "held_out_repeat_subjects": repeat_subj,
            "scans": split_scans,
        }
        path = args.out / f"fold{k}.json"
        path.write_text(json.dumps(split, indent=2))
        meta.append(
            {
                "fold": k,
                "path": str(path),
                "test_subjects": test_subj,
                "n_scan": split["n_scan"],
            }
        )
        print(json.dumps({"fold": k, "n_scan": split["n_scan"], "test_subjects": test_subj}))
    (args.out / "folds.json").write_text(json.dumps({"repeat_subjects": repeat_subj, "folds": meta}, indent=2))


if __name__ == "__main__":
    main()
