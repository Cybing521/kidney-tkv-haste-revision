#!/usr/bin/env python3
"""Protocol flowchart at print width so labels do not collide when scaled.

MRI crops: Fig. 3A (HC_28_r1), Fig. 3D–F (HC_29_r3), Fig. 6 (chaos_t2_5).
OOF bars: verified mean MAE (mL). Intensity curves are schematic.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.lines import Line2D
from matplotlib.patches import Circle, Ellipse, FancyArrowPatch, FancyBboxPatch, Polygon, Rectangle

OUT_DIR = Path(__file__).resolve().parent
FIG_DIR = OUT_DIR.parent / "01_方案/BSPC_Elsevier_template/work/elsarticle/figures"
HASTE = OUT_DIR / "fig_overlay_nottingham.png"
CHAOS = OUT_DIR / "fig_overlay_chaos.png"

FILL = {
    "standard": "#EAF0F6",
    "transform": "#EDE9F4",
    "task": "#F4EEDC",
    "contrib": "#F1D7D4",
    "output": "#E5F1E3",
}
STROKE = {
    "standard": "#63758A",
    "transform": "#7B6A9A",
    "task": "#9A7B3F",
    "contrib": "#B44948",
    "output": "#5A8A55",
}
ARROW = {
    "contrib": "#C0392B",
    "haste": "#6B7C8A",
    "control": "#2E8B57",
    "flow": "#5B4B8A",
}
OOF_MAE = (("U-Net++", 21.3), ("AttUNet", 21.2), ("U-Net", 23.0))

W, H = 7.16, 6.15


@dataclass
class Box:
    x: float
    y: float
    w: float
    h: float

    @property
    def cx(self) -> float:
        return self.x + 0.5 * self.w

    @property
    def cy(self) -> float:
        return self.y + 0.5 * self.h

    @property
    def r(self) -> float:
        return self.x + self.w

    @property
    def t(self) -> float:
        return self.y + self.h


def _add_box(ax, b: Box, fill: str, stroke: str, lw: float = 1.15) -> None:
    ax.add_patch(
        FancyBboxPatch(
            (b.x, b.y),
            b.w,
            b.h,
            boxstyle="round,pad=0.012,rounding_size=0.05",
            facecolor=fill,
            edgecolor=stroke,
            linewidth=lw,
            zorder=2,
        )
    )


def _txt(ax, x, y, s, size=7.2, weight="normal", ha="center", va="center", color="#1A1A1A"):
    ax.text(
        x,
        y,
        s,
        fontsize=size,
        fontweight=weight,
        color=color,
        ha=ha,
        va=va,
        zorder=6,
        linespacing=1.22,
        clip_on=False,
    )


def _arrow(ax, p0, p1, color, lw=1.2) -> None:
    ax.add_patch(
        FancyArrowPatch(
            p0,
            p1,
            arrowstyle="-|>",
            mutation_scale=9,
            lw=lw,
            color=color,
            zorder=4,
            shrinkA=0.5,
            shrinkB=0.5,
        )
    )


def _grid_cell(img: np.ndarray, row: int, col: int, title_frac: float = 0.17) -> np.ndarray:
    h, w = img.shape[:2]
    y0 = int((row + title_frac) / 2 * h)
    y1 = int((row + 1) / 2 * h) - 8
    x0 = int(col / 3 * w) + 14
    x1 = int((col + 1) / 3 * w) - 14
    return img[y0:y1, x0:x1]


def _chaos_body(img: np.ndarray) -> np.ndarray:
    h, w = img.shape[:2]
    return img[int(0.16 * h) : int(0.98 * h), int(0.20 * w) : int(0.80 * w)]


def _stack(ax, img, x, y, w, h, n=3, dx=0.045, dy=0.05) -> None:
    for i in range(n - 1, 0, -1):
        ox, oy = i * dx, i * dy
        ax.imshow(
            img,
            extent=[x + ox, x + w + ox, y + oy, y + h + oy],
            aspect="auto",
            origin="upper",
            zorder=1,
            interpolation="bilinear",
            alpha=0.38,
        )
    ax.imshow(
        img,
        extent=[x, x + w, y, y + h],
        aspect="auto",
        origin="upper",
        zorder=3,
        interpolation="bilinear",
    )
    ax.add_patch(Rectangle((x, y), w, h, fill=False, ec="#111111", lw=0.7, zorder=5))


def _thumb(ax, img, x, y, w, h) -> None:
    ax.imshow(img, extent=[x, x + w, y, y + h], aspect="auto", origin="upper", zorder=5, interpolation="bilinear")
    ax.add_patch(Rectangle((x, y), w, h, fill=False, ec="#263238", lw=0.55, zorder=6))


def _unet_glyph(ax, x, y, w, h) -> None:
    heights = np.array([0.42, 0.58, 0.74, 0.90]) * h
    bw = 0.07 * w
    gap = 0.03 * w
    x_left = x + 0.04 * w
    x_right = x + 0.58 * w
    for i, hi in enumerate(heights):
        ax.add_patch(
            Rectangle((x_left + i * (bw + gap), y), bw, hi, fc="#D98984", ec="#8E3A38", lw=0.45, zorder=5)
        )
        ax.add_patch(
            Rectangle(
                (x_right + (len(heights) - 1 - i) * (bw + gap), y),
                bw,
                hi,
                fc="#E3A39F",
                ec="#8E3A38",
                lw=0.45,
                zorder=5,
            )
        )
    ax.plot(
        [x_left, x_right + 3 * (bw + gap) + bw],
        [y + 0.96 * h, y + 0.96 * h],
        color="#8E3A38",
        lw=0.6,
        ls="--",
        zorder=5,
        solid_capstyle="butt",
    )


def _cube(ax, cx, cy, s=0.22) -> None:
    top = np.array(
        [[cx, cy + 0.18 * s], [cx + 0.55 * s, cy + 0.50 * s], [cx + 1.10 * s, cy + 0.18 * s], [cx + 0.55 * s, cy - 0.14 * s]]
    )
    left = np.array(
        [[cx, cy + 0.18 * s], [cx + 0.55 * s, cy - 0.14 * s], [cx + 0.55 * s, cy - 0.72 * s], [cx, cy - 0.40 * s]]
    )
    right = np.array(
        [
            [cx + 0.55 * s, cy - 0.14 * s],
            [cx + 1.10 * s, cy + 0.18 * s],
            [cx + 1.10 * s, cy - 0.40 * s],
            [cx + 0.55 * s, cy - 0.72 * s],
        ]
    )
    ax.add_patch(Polygon(top, closed=True, fc="#8FBF88", ec="#3F6B3C", lw=0.55, zorder=5))
    ax.add_patch(Polygon(left, closed=True, fc="#6FA86A", ec="#3F6B3C", lw=0.55, zorder=5))
    ax.add_patch(Polygon(right, closed=True, fc="#4E8A4A", ec="#3F6B3C", lw=0.55, zorder=5))


def _people(ax, cx, cy, s=0.85) -> None:
    for x in (cx - 0.20 * s, cx, cx + 0.20 * s):
        ax.add_patch(Circle((x, cy + 0.11 * s), 0.055 * s, fc="#6B5428", ec="none", zorder=5))
        ax.add_patch(
            FancyBboxPatch(
                (x - 0.065 * s, cy - 0.12 * s),
                0.13 * s,
                0.18 * s,
                boxstyle="round,pad=0.002,rounding_size=0.04",
                facecolor="#C4A35A",
                edgecolor="none",
                zorder=5,
            )
        )


def _cylinder(ax, x, y, w, h) -> None:
    ax.add_patch(Rectangle((x, y + 0.12 * h), w, 0.70 * h, fc="#E8C4C2", ec="#8E3A38", lw=0.6, zorder=5))
    ax.add_patch(Ellipse((x + w / 2, y + 0.82 * h), w, 0.26 * h, fc="#F3D6D4", ec="#8E3A38", lw=0.6, zorder=6))
    ax.add_patch(Ellipse((x + w / 2, y + 0.12 * h), w, 0.26 * h, fc="#D98984", ec="#8E3A38", lw=0.6, zorder=6))


def _gauss(ax, x, y, w, h) -> None:
    t = np.linspace(-3.0, 3.0, 220)
    xs = x + (t - t[0]) / (t[-1] - t[0]) * w
    y1 = y + 0.08 * h + 0.90 * h * np.exp(-0.5 * ((t + 0.55) / 0.95) ** 2)
    y2 = y + 0.08 * h + 0.72 * h * np.exp(-0.5 * ((t - 0.70) / 0.72) ** 2)
    y1 = np.clip(y1, y, y + h)
    y2 = np.clip(y2, y, y + h)
    ax.fill_between(xs, y, y1, color="#9BB7C9", alpha=0.55, zorder=5, linewidth=0)
    ax.fill_between(xs, y, y2, color="#6B7C8A", alpha=0.40, zorder=5, linewidth=0)
    ax.plot([x + 0.52 * w, x + 0.52 * w], [y, y + h], color="#4A5560", ls="--", lw=0.55, zorder=6)


def _oof_bars(ax, x, y, w, h) -> None:
    label_w = 0.62
    vmax = 28.0
    row = h / 3.0
    for i, (name, val) in enumerate(OOF_MAE):
        yi = y + h - (i + 1) * row + 0.05 * row
        bh = 0.48 * row
        _txt(ax, x + label_w - 0.04, yi + 0.5 * bh, name, size=6.2, ha="right", va="center")
        bw = (val / vmax) * (w - label_w - 0.06)
        ax.add_patch(Rectangle((x + label_w, yi), bw, bh, fc="#E8D5A3", ec="#9A7B3F", lw=0.5, zorder=5))
    ax.plot([x + label_w, x + w], [y, y], color="#9A7B3F", lw=0.5, zorder=5)
    _txt(ax, x + label_w + 0.5 * (w - label_w), y - 0.11, "MAE (mL)", size=5.8, va="top")


def main() -> Path:
    haste = plt.imread(HASTE)
    chaos = plt.imread(CHAOS)
    sl_a = _grid_cell(haste, 0, 0)
    polar = [_grid_cell(haste, 1, c) for c in range(3)]
    chaos_img = _chaos_body(chaos)

    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 7.2})
    fig, ax = plt.subplots(figsize=(W, H))
    fig.subplots_adjust(left=0.015, right=0.985, top=0.975, bottom=0.025)
    ax.set_xlim(0, W)
    ax.set_ylim(0, H)
    ax.axis("off")
    fig.patch.set_facecolor("white")
    ax.set_facecolor("white")

    _txt(ax, 0.08, 5.98, "A   Coronal T2-HASTE protocol (intended use)", size=9.6, weight="bold", ha="left")
    legend = [
        Line2D([0], [0], color=ARROW["contrib"], lw=1.6, label="Contribution / labelled transfer"),
        Line2D([0], [0], color=ARROW["haste"], lw=1.6, label="HASTE-internal readout"),
        Line2D([0], [0], color=ARROW["control"], lw=1.6, label="Zero-shot / intensity control"),
        Line2D([0], [0], color=ARROW["flow"], lw=1.6, label="Data flow"),
    ]
    ax.legend(
        handles=legend,
        loc="upper right",
        bbox_to_anchor=(0.995, 0.995),
        frameon=False,
        fontsize=6.0,
        handlelength=1.35,
        ncol=2,
        columnspacing=0.9,
        handletextpad=0.35,
        labelspacing=0.18,
        borderaxespad=0.0,
    )

    # --- A top row ---
    stack = Box(0.10, 3.55, 1.18, 1.72)
    unet = Box(1.58, 3.48, 1.72, 1.86)
    tkv = Box(3.44, 3.50, 1.18, 1.84)
    oof = Box(4.76, 3.48, 2.28, 1.86)

    _stack(ax, sl_a, stack.x, stack.y, stack.w, stack.h)
    _txt(ax, stack.cx, 3.22, "Public HASTE + expert mask\nHC_28_r1   Dice 0.95", size=6.5, va="top")

    _add_box(ax, unet, FILL["contrib"], STROKE["contrib"], lw=1.35)
    _txt(ax, unet.cx, unet.t - 0.16, "2D U-Net++ engine", size=8.0, weight="bold")
    _unet_glyph(ax, unet.x + 0.10, unet.y + 0.68, unet.w - 0.20, 0.66)
    _txt(
        ax,
        unet.cx,
        unet.y + 0.36,
        "Focal Dice + deep supervision\nthrough-plane slices 256×256\ncheckpoint named on CoV split",
        size=6.4,
    )

    _add_box(ax, tkv, FILL["output"], STROKE["output"])
    _txt(ax, tkv.cx, tkv.t - 0.16, "TKV (mL)", size=8.0, weight="bold")
    _cube(ax, tkv.cx - 0.12, tkv.y + 1.02, s=0.24)
    _txt(ax, tkv.cx, tkv.y + 0.28, "voxel count ×\nvoxel volume", size=6.2)

    _add_box(ax, oof, FILL["task"], STROKE["task"])
    _txt(ax, oof.cx, oof.t - 0.16, "OOF millilitre readout", size=8.0, weight="bold")
    _oof_bars(ax, oof.x + 0.08, oof.y + 0.42, 1.12, 0.92)
    _txt(
        ax,
        oof.x + 1.30,
        oof.y + 0.88,
        "50 single-scan people\n(5-fold)\nMAE 21–23 mL\nmedian 15–17 mL\nidentity does not\nrank MAE",
        size=6.3,
        ha="left",
        va="center",
    )

    _arrow(ax, (stack.r + 0.09, stack.cy), (unet.x - 0.03, unet.cy + 0.12), ARROW["haste"])
    _arrow(ax, (unet.r + 0.02, tkv.cy), (tkv.x - 0.03, tkv.cy), ARROW["contrib"])
    _arrow(ax, (tkv.r + 0.02, tkv.cy), (oof.x - 0.03, tkv.cy), ARROW["haste"])

    # --- A second row ---
    cov = Box(1.58, 2.18, 1.48, 1.16)
    polar_b = Box(3.20, 2.18, 3.84, 1.16)

    _add_box(ax, cov, FILL["task"], STROKE["task"])
    _txt(ax, cov.cx, cov.t - 0.15, "Same-session CoV", size=7.6, weight="bold")
    _people(ax, cov.cx, cov.y + 0.72, s=0.82)
    _txt(ax, cov.cx, cov.y + 0.26, "10 subjects × 5 repeats\nCoV 1.9%  (band 1.5%±0.5%)\nclustered MAE 11.1 mL", size=6.2)

    _add_box(ax, polar_b, FILL["transform"], STROKE["transform"])
    _txt(ax, polar_b.cx, polar_b.t - 0.15, "Polar-slice Dice map", size=7.6, weight="bold")
    tw, th = 0.58, 0.58
    gap = 0.06
    x0 = polar_b.x + 0.10
    y0 = polar_b.y + 0.22
    for i, im in enumerate(polar):
        _thumb(ax, im, x0 + i * (tw + gap), y0, tw, th)
    _txt(
        ax,
        polar_b.x + 2.10,
        polar_b.y + 0.50,
        "mid-kidney  0.945±0.013\npolar  0.60  (IQR 0.41–0.90)\n≠ signed millilitre error",
        size=6.5,
        ha="left",
        va="center",
    )

    _arrow(ax, (unet.cx, unet.y - 0.02), (unet.cx, cov.t + 0.03), ARROW["contrib"])
    _arrow(ax, (tkv.cx, tkv.y - 0.02), (tkv.cx, polar_b.t + 0.03), ARROW["flow"])

    # --- B ---
    _txt(
        ax,
        0.08,
        1.96,
        "B   Axial T2-SPIR transfer (overlap recovery, not a TKV working point)",
        size=9.6,
        weight="bold",
        ha="left",
    )

    cstack = Box(0.12, 0.38, 1.12, 1.28)
    zero = Box(1.58, 0.22, 1.78, 1.56)
    budget = Box(3.52, 0.18, 3.52, 1.60)

    _stack(ax, chaos_img, cstack.x, cstack.y, cstack.w, cstack.h, dx=0.04, dy=0.045)
    _txt(ax, cstack.cx, 0.08, "CHAOS T2-SPIR  n=20\nzero-shot Dice 0.098", size=6.4, va="bottom")

    _add_box(ax, zero, FILL["standard"], STROKE["standard"], lw=1.0)
    _txt(ax, zero.cx, zero.t - 0.15, "Zero-shot / intensity", size=7.6, weight="bold")
    _gauss(ax, zero.x + 0.12, zero.y + 0.62, zero.w - 0.24, 0.52)
    _txt(ax, zero.cx, zero.y + 0.28, "median Dice 0.07 → 0.098\npaired Δ +0.006   p=0.12\nMAE 227 → 180 mL", size=6.3)

    _add_box(ax, budget, FILL["contrib"], STROKE["contrib"], lw=1.35)
    _txt(ax, budget.cx, budget.t - 0.16, "Held-out label budget  (independent draws)", size=7.6, weight="bold")
    _cylinder(ax, budget.x + 0.14, budget.y + 0.22, 0.46, 0.88)
    _txt(
        ax,
        budget.x + 0.78,
        budget.cy - 0.04,
        "1 label     Dice 0.72    MAE 120 mL    19/20 ≥0.50\n"
        "4 labels    Dice 0.83    MAE  92 mL    20/20 ≥0.50\n"
        "16 labels   Dice 0.90    MAE  46 mL    train-Dice checkpoint",
        size=6.5,
        ha="left",
    )

    _arrow(ax, (cstack.r + 0.08, cstack.cy), (zero.x - 0.03, zero.cy + 0.06), ARROW["haste"])
    _arrow(ax, (zero.r + 0.02, zero.cy), (budget.x - 0.03, zero.cy), ARROW["contrib"])

    png = OUT_DIR / "fig_workflow.png"
    pdf = OUT_DIR / "fig_workflow.pdf"
    fig.savefig(png, dpi=400, facecolor="white")
    fig.savefig(pdf, dpi=400, facecolor="white")
    plt.close(fig)
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    for dest in (FIG_DIR / "fig_workflow.png", FIG_DIR / "fig_workflow.pdf"):
        dest.write_bytes((OUT_DIR / dest.name).read_bytes())
    return png


if __name__ == "__main__":
    print("wrote", main())
