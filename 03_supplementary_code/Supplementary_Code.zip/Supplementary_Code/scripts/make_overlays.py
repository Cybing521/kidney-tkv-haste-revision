#!/usr/bin/env python3
"""Save kidney-slice overlays (GT vs predicted contours). Run on llm_01."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from train import MODELS, laterality, resize2d  # noqa: E402

GT_COLOR = "#8BCF8B"
PR_COLOR = "#B64342"


@torch.no_grad()
def predict_mask(model, img: np.ndarray, device) -> np.ndarray:
    axis = int(np.argmin(img.shape))
    sl = np.moveaxis(img, axis, 0)
    preds = []
    for i in range(sl.shape[0]):
        x = torch.from_numpy(resize2d(sl[i], 256)[None, None]).to(device)
        logit = model(x)[0]
        pr = F.interpolate(torch.sigmoid(logit), size=sl[i].shape, mode="bilinear", align_corners=False)
        preds.append((pr[0, 0].cpu().numpy() > 0.5).astype(np.uint8))
    pred = np.stack(preds, 0)
    return np.moveaxis(pred, 0, axis)


def slice_areas(gt: np.ndarray) -> tuple[int, np.ndarray]:
    axis = int(np.argmin(gt.shape))
    sl = np.moveaxis(gt, axis, 0)
    areas = sl.reshape(sl.shape[0], -1).sum(1)
    return axis, areas


def best_slice(gt: np.ndarray) -> tuple[int, int]:
    axis, areas = slice_areas(gt)
    return axis, int(np.argmax(areas))


def pole_slices(gt: np.ndarray, frac: float = 0.05) -> tuple[int, int, int, int]:
    """Return axis and (first, mid, last) indices with GT area ≥ frac × max area."""
    axis, areas = slice_areas(gt)
    max_a = float(areas.max())
    keep = np.where(areas >= frac * max_a)[0]
    if keep.size == 0:
        mid = int(np.argmax(areas))
        return axis, mid, mid, mid
    return axis, int(keep[0]), int(np.argmax(areas)), int(keep[-1])


def draw_slice(ax, img, gt, pr, axis: int, idx: int, title: str, letter: str = "") -> None:
    im = np.moveaxis(img, axis, 0)[idx]
    g = np.moveaxis(gt.astype(np.uint8), axis, 0)[idx]
    p = np.moveaxis(pr.astype(np.uint8), axis, 0)[idx]
    lo, hi = np.percentile(im, (1, 99))
    ax.imshow(np.clip((im - lo) / (hi - lo + 1e-6), 0, 1), cmap="gray", origin="lower")
    if g.any():
        ax.contour(g, levels=[0.5], colors=[GT_COLOR], linewidths=1.4, origin="lower")
    if p.any():
        ax.contour(p, levels=[0.5], colors=[PR_COLOR], linewidths=1.4, origin="lower")
    ax.set_title((f"{letter}  {title}" if letter else title), fontsize=9, loc="left")
    ax.set_axis_off()


def show_overlay(ax, img, gt, pr, title: str) -> None:
    axis, idx = best_slice(gt)
    draw_slice(ax, img, gt, pr, axis, idx, title)


def load_volume(npz_dir: Path, sid: str):
    with np.load(npz_dir / f"{sid}.npz") as z:
        return z["image"].copy(), z["mask"] > 0, z["spacing"].copy()


def metrics(gt, pr, spacing) -> tuple[float, float, float, float]:
    inter = float((pr & gt).sum())
    dice = (2 * inter + 1e-6) / (float(pr.sum()) + float(gt.sum()) + 1e-6)
    gt_ml = float(laterality(gt, spacing)["tkv_ml"])
    pr_ml = float(laterality(pr, spacing)["tkv_ml"])
    return dice, gt_ml, pr_ml, abs(pr_ml - gt_ml)


def load_model(ckpt_path: Path, device):
    ckpt = torch.load(ckpt_path, map_location=device, weights_only=False)
    name = ckpt.get("name", "unetpp")
    model = MODELS[name]().to(device)
    model.load_state_dict(ckpt["model"])
    model.eval()
    return model


def infer(model, npz_dir: Path, sid: str, device):
    img, gt, sp = load_volume(npz_dir, sid)
    pred = predict_mask(model, img, device)
    if pred.shape != gt.shape:
        pred = pred[: gt.shape[0], : gt.shape[1], : gt.shape[2]]
    dice, gt_ml, pr_ml, err = metrics(gt, pred, sp)
    return img, gt, pred, {"scan_id": sid, "dice": dice, "gt_ml": gt_ml, "pr_ml": pr_ml, "tkv_abs_ml": err}


def fig_i12(model, npz_dir: Path, device, out: Path) -> dict:
    """2×3 HASTE overlay: two median first-repeats, lowest Dice, largest |TKV| poles."""
    hc_med = infer(model, npz_dir, "HC_28_r1", device)
    ckd_med = infer(model, npz_dir, "CKD_27_r1", device)
    low_dice = infer(model, npz_dir, "CKD_27_r5", device)
    hi_err = infer(model, npz_dir, "HC_29_r3", device)

    fig, axes = plt.subplots(2, 3, figsize=(12.6, 8.2))
    img, gt, pr, m = hc_med
    axis, idx = best_slice(gt)
    draw_slice(
        axes[0, 0],
        img,
        gt,
        pr,
        axis,
        idx,
        f"HC_28_r1  first-repeat median Dice\nDice {m['dice']:.3f}   |ΔTKV| {m['tkv_abs_ml']:.1f} mL",
        "A",
    )
    img, gt, pr, m = ckd_med
    axis, idx = best_slice(gt)
    draw_slice(
        axes[0, 1],
        img,
        gt,
        pr,
        axis,
        idx,
        f"CKD_27_r1  first-repeat median Dice\nDice {m['dice']:.3f}   |ΔTKV| {m['tkv_abs_ml']:.1f} mL",
        "B",
    )
    img, gt, pr, m = low_dice
    axis, idx = best_slice(gt)
    draw_slice(
        axes[0, 2],
        img,
        gt,
        pr,
        axis,
        idx,
        f"CKD_27_r5  lowest Dice (50 scans)\nDice {m['dice']:.3f}   |ΔTKV| {m['tkv_abs_ml']:.1f} mL",
        "C",
    )
    img, gt, pr, m = hi_err
    axis, i0, imid, i1 = pole_slices(gt, 0.05)
    for ax, idx, lab, letter in (
        (axes[1, 0], i0, "pole (first ≥5% max area)", "D"),
        (axes[1, 1], imid, "max-area slice", "E"),
        (axes[1, 2], i1, "pole (last ≥5% max area)", "F"),
    ):
        draw_slice(
            ax,
            img,
            gt,
            pr,
            axis,
            idx,
            f"HC_29_r3  largest |ΔTKV|  {lab}\nDice {m['dice']:.3f}   |ΔTKV| {m['tkv_abs_ml']:.1f} mL",
            letter,
        )
    fig.tight_layout(h_pad=1.4, w_pad=0.4)
    out.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out, dpi=300, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    axis, i0, imid, i1 = pole_slices(hi_err[1], 0.05)
    rec = {
        "rule": {
            "A_B": "first-repeat scan nearest each cohort median Dice among r1 test scans",
            "C": "lowest Dice among 50 test scans",
            "D_E_F": "largest TKV |error| among 50 test scans; pole slices = first/last GT area ≥ 0.05×max, plus argmax",
        },
        "panels": {
            "A": hc_med[3],
            "B": ckd_med[3],
            "C": low_dice[3],
            "D_E_F": {**hi_err[3], "slice_indices": [i0, imid, i1], "axis": axis},
        },
    }
    rec_path = out.with_suffix(".json")
    rec_path.write_text(json.dumps(rec, indent=2))
    print("wrote", out)
    print("wrote", rec_path)
    return rec


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", type=Path, required=True)
    ap.add_argument("--npz-dir", type=Path, required=True)
    ap.add_argument("--scan-ids", default="")
    ap.add_argument("--titles", default="")
    ap.add_argument("--preset", default="", choices=["", "i12"])
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = load_model(args.ckpt, device)

    if args.preset == "i12":
        fig_i12(model, args.npz_dir, device, args.out)
        return

    sids = [s.strip() for s in args.scan_ids.split(",") if s.strip()]
    if not sids:
        raise SystemExit("pass --scan-ids or --preset i12")
    titles = [t.strip() for t in args.titles.split("|")] if args.titles else sids
    while len(titles) < len(sids):
        titles.append(sids[len(titles)])

    n = len(sids)
    fig, axes = plt.subplots(1, n, figsize=(4.2 * n, 4.2))
    axes = np.atleast_1d(axes)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    for ax, sid, title in zip(axes, sids, titles):
        img, gt, pred, m = infer(model, args.npz_dir, sid, device)
        show_overlay(ax, img, gt, pred, f"{title}\nDice {m['dice']:.3f}   |ΔTKV| {m['tkv_abs_ml']:.1f} mL")
    fig.savefig(args.out, dpi=300, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("wrote", args.out)


if __name__ == "__main__":
    main()
