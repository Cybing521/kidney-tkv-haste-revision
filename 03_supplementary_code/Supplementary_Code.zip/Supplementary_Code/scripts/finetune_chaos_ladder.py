#!/usr/bin/env python3
"""CHAOS label-budget ladder on the 20 labeled T2-SPIR exams. Held-out evaluation only."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from train import SliceSet, _build_model, deepsup_loss, predict_volumes, set_seed, summarize  # noqa: E402


def folds_20(ids: list[str], seed: int = 42) -> list[dict]:
    rng = np.random.default_rng(seed)
    order = rng.permutation(ids).tolist()
    folds = []
    for k in range(5):
        te = order[k * 4 : (k + 1) * 4]
        remain = [i for i in order if i not in te]
        folds.append({"fold": k, "test": te, "pool": remain})
    return folds


def take_budget(pool: list[str], n: int, fold: int = 0, budget: int = 0, mode: str = "prefix", seed: int = 42) -> list[str]:
    if n >= len(pool):
        return list(pool)
    if mode == "prefix":
        return pool[:n]
    rng = np.random.default_rng(seed + 17 * (fold + 1) + budget)
    return rng.permutation(pool).tolist()[:n]


def pack_metrics(rows: list[dict]) -> dict:
    s = summarize(rows)
    d = [r["dice"] for r in rows]
    s["dice_median"] = float(np.median(d)) if d else None
    s["dice_iqr"] = [float(np.percentile(d, 25)), float(np.percentile(d, 75))] if d else [None, None]
    s["n_dice_lt_0_05"] = int(sum(x < 0.05 for x in d))
    s["n_dice_ge_0_50"] = int(sum(x >= 0.50 for x in d))
    return s


def finetune(ckpt, name, npz_dir, train_ids, val_ids, device, epochs, freeze_enc: bool, scratch: bool = False):
    model = _build_model(name).to(device)
    if scratch:
        lr = 2e-4
    else:
        ck = torch.load(ckpt, map_location="cpu", weights_only=False)
        model.load_state_dict(ck["model"])
        lr = 1e-4
        if freeze_enc and hasattr(model, "conv0_0"):
            for p in model.parameters():
                p.requires_grad = False
            for head in (model.head1, model.head2, model.head3, model.head4):
                for p in head.parameters():
                    p.requires_grad = True
    opt = torch.optim.AdamW([p for p in model.parameters() if p.requires_grad], lr=lr, weight_decay=1e-4)
    loader = DataLoader(SliceSet(npz_dir, train_ids, True), batch_size=8, shuffle=True, num_workers=0)
    best, best_state = -1.0, {k: v.cpu() for k, v in model.state_dict().items()}
    for _ep in range(epochs):
        model.train()
        for x, y, *_ in loader:
            x, y = x.to(device), y.to(device)
            opt.zero_grad(set_to_none=True)
            loss = deepsup_loss(model(x), y)
            loss.backward()
            opt.step()
        model.eval()
        rows = predict_volumes(model, npz_dir, val_ids, device, {i: {"subject": i} for i in val_ids})
        d = pack_metrics(rows)["dice_mean"]
        if d > best:
            best, best_state = d, {k: v.cpu() for k, v in model.state_dict().items()}
    model.load_state_dict(best_state)
    return model


def self_train(ckpt, name, npz_dir, unlabeled_ids, labeled_eval_ids, device, epochs):
    """Pseudo-label unlabeled CHAOS with the HASTE checkpoint, then one fine-tune pass."""
    model = _build_model(name).to(device)
    ck = torch.load(ckpt, map_location="cpu", weights_only=False)
    model.load_state_dict(ck["model"])
    model.eval()
    pseudo_dir = npz_dir.parent / "chaos_pseudo"
    pseudo_dir.mkdir(parents=True, exist_ok=True)
    ids = []
    with torch.no_grad():
        for sid in unlabeled_ids:
            with np.load(npz_dir / f"{sid}.npz") as z:
                img, sp = z["image"], z["spacing"]
            from train import resize2d
            import torch.nn.functional as F

            axis = int(np.argmin(img.shape))
            sl = np.moveaxis(img, axis, 0)
            preds = []
            for i in range(sl.shape[0]):
                x = torch.from_numpy(resize2d(sl[i], 256)[None, None]).to(device)
                logit = model(x)[0]
                pr = F.interpolate(torch.sigmoid(logit), size=sl[i].shape, mode="bilinear", align_corners=False)
                preds.append((pr[0, 0].cpu().numpy() > 0.6).astype(np.uint8))
            pred = np.moveaxis(np.stack(preds, 0), 0, axis)
            np.savez_compressed(pseudo_dir / f"{sid}.npz", image=img.astype(np.float32), mask=pred, spacing=sp)
            ids.append(sid)
    if not ids:
        return model
    loader = DataLoader(SliceSet(pseudo_dir, ids, True), batch_size=8, shuffle=True, num_workers=0)
    opt = torch.optim.AdamW(model.parameters(), lr=5e-5, weight_decay=1e-4)
    model.train()
    for _ep in range(epochs):
        for x, y, *_ in loader:
            x, y = x.to(device), y.to(device)
            opt.zero_grad(set_to_none=True)
            loss = deepsup_loss(model(x), y)
            loss.backward()
            opt.step()
    return model


def run_one(ckpt, name, npz, meta, device, epochs, te, tr, val_ids, b, tag, scratch: bool):
    if b == 0:
        model = _build_model(name).to(device)
        ck = torch.load(ckpt, map_location="cpu", weights_only=False)
        model.load_state_dict(ck["model"])
    else:
        model = finetune(ckpt, name, npz, tr, val_ids, device, epochs, freeze_enc=False, scratch=scratch)
    rows = predict_volumes(model, npz, te, device, meta)
    rec = {
        "budget": b,
        "tag": tag,
        "init": "scratch" if scratch and b > 0 else "haste",
        "test_ids": te,
        "train_ids": tr,
        "val_ids": val_ids,
        "metrics": pack_metrics(rows),
        "rows": rows,
    }
    print(
        json.dumps(
            {
                "budget": b,
                "tag": tag,
                "init": rec["init"],
                "train_ids": tr,
                "dice_mean": rec["metrics"]["dice_mean"],
                "dice_median": rec["metrics"]["dice_median"],
                "tkv_mae_ml": rec["metrics"]["tkv_mae_ml"],
            }
        ),
        flush=True,
    )
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", type=Path, required=True)
    ap.add_argument("--ckpt", type=Path, default=None)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--model", default="unetpp")
    ap.add_argument("--epochs", type=int, default=20)
    ap.add_argument("--budgets", default="0,1,4,16")
    ap.add_argument("--init", choices=["haste", "scratch"], default="haste")
    ap.add_argument("--sample", choices=["prefix", "independent"], default="prefix")
    ap.add_argument("--splits-from", type=Path, default=None)
    args = ap.parse_args()
    scratch = args.init == "scratch"
    if not scratch and args.ckpt is None:
        raise SystemExit("--ckpt is required unless --init scratch")
    set_seed(42)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    npz = args.data / "chaos_npz"
    ids = sorted(p.stem for p in npz.glob("*.npz"))
    meta = {i: {"subject": i, "cohort": "chaos_t2"} for i in ids}
    unlabeled = sorted(p.stem for p in (args.data / "chaos_unlabeled").glob("*.npz")) if (args.data / "chaos_unlabeled").exists() else []
    budgets = [int(x) for x in args.budgets.split(",") if x.strip()]
    table = []
    if args.splits_from:
        prior = json.loads(args.splits_from.read_text())
        for rec0 in prior:
            b = rec0["budget"]
            if b not in budgets:
                continue
            if scratch and b == 0:
                continue
            tag = rec0.get("tag", f"ft_{b}")
            if scratch and b > 0:
                tag = f"scratch_{b}"
            rec = run_one(
                args.ckpt,
                args.model,
                npz,
                meta,
                device,
                args.epochs,
                rec0["test_ids"],
                rec0.get("train_ids") or [],
                rec0.get("val_ids") or rec0["test_ids"],
                b,
                tag,
                scratch=scratch and b > 0,
            )
            rec["fold"] = rec0["fold"]
            rec["sample"] = "reused_splits"
            table.append(rec)
    else:
        for fold in folds_20(ids):
            te, pool = fold["test"], fold["pool"]
            val_hold = pool[-4:] if len(pool) > 4 else list(pool)
            train_pool = [i for i in pool if i not in val_hold]
            for b in budgets:
                if b == 0:
                    if scratch:
                        continue
                    tr, val_ids, tag = [], val_hold, "zero_shot"
                elif b <= len(train_pool):
                    tr = take_budget(train_pool, b, fold["fold"], b, args.sample)
                    val_ids = val_hold
                    tag = f"{'scratch' if scratch else 'ft'}_{b}"
                    if args.sample == "independent":
                        tag = f"{tag}_indep"
                else:
                    tr = list(pool)
                    val_ids = list(pool)
                    tag = f"{'scratch' if scratch else 'ft'}_{b}_train_ckpt"
                    if args.sample == "independent":
                        tag = f"{tag}_indep"
                rec = run_one(
                    args.ckpt,
                    args.model,
                    npz,
                    meta,
                    device,
                    args.epochs,
                    te,
                    tr,
                    val_ids,
                    b,
                    tag,
                    scratch=scratch and b > 0,
                )
                rec["fold"] = fold["fold"]
                rec["sample"] = args.sample
                table.append(rec)
            if unlabeled and not scratch and args.sample == "prefix":
                model = self_train(args.ckpt, args.model, args.data / "chaos_unlabeled", unlabeled, te, device, max(8, args.epochs // 2))
                rows = predict_volumes(model, npz, te, device, meta)
                rec = {
                    "fold": fold["fold"],
                    "budget": "self_train",
                    "tag": "self_train",
                    "test_ids": te,
                    "metrics": pack_metrics(rows),
                    "rows": rows,
                }
                table.append(rec)
                print(json.dumps({"fold": rec["fold"], "budget": "self_train", "dice_median": rec["metrics"]["dice_median"]}), flush=True)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(table, indent=2))


if __name__ == "__main__":
    main()
