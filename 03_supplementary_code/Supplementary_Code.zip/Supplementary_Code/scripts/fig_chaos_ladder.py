#!/usr/bin/env python3
"""CHAOS label-budget ladder: held-out Dice and TKV MAE (n=20 pooled)."""
from __future__ import annotations

import json
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path.home() / ".claude/skills/scientific-figures/scripts"))

from publication_style import (  # noqa: E402
    PALETTE,
    FigureStyle,
    apply_publication_style,
    create_subplots,
    finalize_figure,
    qa_before_save,
)

OUT = Path(__file__).resolve().parent
PREFIX = json.loads((ROOT / "05_验证记录/chaos_ladder.json").read_text())
RESAMPLE = json.loads((ROOT / "05_验证记录/chaos_ladder_resample.json").read_text())
BUDGETS = [0, 1, 4, 16]


def rows_by_budget() -> dict[int, list]:
    by = defaultdict(list)
    for rec in PREFIX:
        if rec["budget"] == 0:
            by[0].extend(rec["rows"])
    for rec in RESAMPLE:
        by[rec["budget"]].extend(rec["rows"])
    return by


def strip(ax, values, color, ylabel):
    rng = np.random.default_rng(42)
    for i, b in enumerate(BUDGETS):
        y = np.asarray(values[b], dtype=float)
        x = i + rng.uniform(-0.12, 0.12, size=len(y))
        ax.scatter(x, y, s=28, color=color, edgecolors="black", linewidths=0.35, zorder=3)
        ax.scatter([i], [np.median(y)], s=70, marker="D", color="black", zorder=4)
    med = [float(np.median(values[b])) for b in BUDGETS]
    ax.plot(range(len(BUDGETS)), med, color="black", linewidth=1.2, zorder=2)
    ax.set_xticks(range(len(BUDGETS)), [str(b) for b in BUDGETS])
    ax.set_xlabel("CHAOS labels in the training pool")
    ax.set_ylabel(ylabel)


def main() -> Path:
    by = rows_by_budget()
    dice = {b: [r["dice"] for r in by[b]] for b in BUDGETS}
    mae = {b: [r["tkv_abs_ml"] for r in by[b]] for b in BUDGETS}
    apply_publication_style(FigureStyle(font_size=11, axes_linewidth=1.4, cjk=False))
    fig, axes = create_subplots(1, 2, figsize=(9.6, 4.2))
    strip(axes[0], dice, PALETTE["blue_main"], "Held-out Dice")
    axes[0].set_ylim(-0.02, 1.02)
    axes[0].text(-0.14, 1.06, "A", transform=axes[0].transAxes, fontweight="bold", fontsize=13)
    strip(axes[1], mae, PALETTE["red_strong"], "Held-out TKV MAE (mL)")
    axes[1].text(-0.14, 1.06, "B", transform=axes[1].transAxes, fontweight="bold", fontsize=13)
    qa = qa_before_save(fig)
    if qa.get("defects"):
        print("qa", qa)
    out = OUT / "fig_chaos_ladder"
    finalize_figure(fig, out, formats=["png", "pdf"], dpi=300)
    return Path(str(out) + ".png")


if __name__ == "__main__":
    print("wrote", main())
