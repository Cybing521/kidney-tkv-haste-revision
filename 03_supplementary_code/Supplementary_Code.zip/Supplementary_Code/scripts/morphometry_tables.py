#!/usr/bin/env python3
"""Stratify Nottingham test morphometry by cohort and CKD stage. No training."""
from __future__ import annotations

import argparse
import json
from collections import defaultdict
from pathlib import Path

import numpy as np


def mean_std(xs):
    xs = [float(x) for x in xs]
    if not xs:
        return None
    return {"n": len(xs), "mean": float(np.mean(xs)), "std": float(np.std(xs))}


def group_rows(rows, key_fn):
    g = defaultdict(list)
    for r in rows:
        g[key_fn(r)].append(r)
    return g


def pack(rows):
    return {
        "dice": mean_std([r["dice"] for r in rows]),
        "tkv_gt_ml": mean_std([r["gt"]["tkv_ml"] for r in rows]),
        "tkv_pr_ml": mean_std([r["pr"]["tkv_ml"] for r in rows]),
        "tkv_mae_ml": mean_std([r["tkv_abs_ml"] for r in rows]),
        "laterality_gt": mean_std([r["gt"]["laterality"] for r in rows]),
        "elongation_gt": mean_std([r["gt"]["elongation"] for r in rows]),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()
    report = {}
    for model in ("unet", "attunet", "unetpp"):
        path = args.runs / model / "test_rows.json"
        rows = json.loads(path.read_text())
        by_cohort = {k: pack(v) for k, v in sorted(group_rows(rows, lambda r: r["cohort"]).items())}
        by_stage = {str(k): pack(v) for k, v in sorted(group_rows(rows, lambda r: str(r.get("ckd_stage"))).items())}
        # one scan per subject (repeat==1) for phenotype, avoid inflating n with 5 repeats
        once = [r for r in rows if int(r.get("repeat") or 1) == 1]
        report[model] = {
            "all_scans": pack(rows),
            "by_cohort_all_scans": by_cohort,
            "by_stage_all_scans": by_stage,
            "repeat1_only": pack(once),
            "repeat1_by_cohort": {k: pack(v) for k, v in sorted(group_rows(once, lambda r: r["cohort"]).items())},
        }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, indent=2))
    print(json.dumps({m: report[m]["repeat1_by_cohort"] for m in report}, indent=2))


if __name__ == "__main__":
    main()
