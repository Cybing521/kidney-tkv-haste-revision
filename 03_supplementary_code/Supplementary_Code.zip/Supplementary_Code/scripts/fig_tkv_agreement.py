#!/usr/bin/env python3
"""TKV identity scatter and Bland-Altman from U-Net++ test_rows.json."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
SKILL_SCRIPTS = Path.home() / ".claude/skills/scientific-figures/scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from publication_style import (  # noqa: E402
    PALETTE,
    FigureStyle,
    apply_publication_style,
    create_subplots,
    finalize_figure,
    make_scatter,
)

ROWS = json.loads((ROOT / "05_验证记录/unetpp_test_rows.json").read_text())
OUT = Path(__file__).resolve().parent / "fig_tkv_agreement"


def main() -> None:
    apply_publication_style(FigureStyle(font_size=11, axes_linewidth=1.4))
    fig, axes = create_subplots(1, 2, figsize=(9.4, 4.2))
    ax0, ax1 = axes
    gt = np.array([r["gt"]["tkv_ml"] for r in ROWS], dtype=float)
    pr = np.array([r["pr"]["tkv_ml"] for r in ROWS], dtype=float)
    coh = [r["cohort"] for r in ROWS]
    hc = np.array([c == "hc" for c in coh])
    make_scatter(ax0, gt[hc], pr[hc], label="HC (5 × 5 repeats)", color=PALETTE["blue_main"], size=36)
    make_scatter(ax0, gt[~hc], pr[~hc], label="CKD (5 × 5 repeats)", color=PALETTE["red_strong"], size=36)
    lo = float(min(gt.min(), pr.min()) - 15)
    hi = float(max(gt.max(), pr.max()) + 15)
    ax0.plot([lo, hi], [lo, hi], color="black", linewidth=1.0, linestyle="--", zorder=0)
    ax0.set_xlim(lo, hi)
    ax0.set_ylim(lo, hi)
    ax0.set_xlabel("Manual TKV (mL)")
    ax0.set_ylabel("U-Net++ TKV (mL)")
    ax0.set_aspect("equal", adjustable="box")
    ax0.legend(loc="upper left", fontsize=9)
    ax0.text(-0.12, 1.06, "A", transform=ax0.transAxes, fontweight="bold", fontsize=13)

    mean = 0.5 * (gt + pr)
    diff = pr - gt
    md = float(np.mean(diff))
    sd = float(np.std(diff, ddof=1))
    make_scatter(ax1, mean[hc], diff[hc], label="HC", color=PALETTE["blue_main"], size=36)
    make_scatter(ax1, mean[~hc], diff[~hc], label="CKD", color=PALETTE["red_strong"], size=36)
    ax1.axhline(md, color="black", linewidth=1.2)
    ax1.axhline(md + 1.96 * sd, color="black", linewidth=1.0, linestyle="--")
    ax1.axhline(md - 1.96 * sd, color="black", linewidth=1.0, linestyle="--")
    ax1.set_xlabel("Mean TKV (mL)")
    ax1.set_ylabel("U-Net++ − manual (mL)")
    ax1.text(
        0.03,
        0.97,
        f"n = 10 subjects × 5 repeats\n(not 50 independent people)\nmean {md:+.1f} mL\n±1.96 SD {1.96 * sd:.1f} mL",
        transform=ax1.transAxes,
        ha="left",
        va="top",
        fontsize=8,
    )
    ax1.text(-0.12, 1.06, "B", transform=ax1.transAxes, fontweight="bold", fontsize=13)

    finalize_figure(fig, OUT, formats=["png", "pdf"], dpi=300)
    print("wrote", Path(str(OUT) + ".png"))
    print("n", len(ROWS), "bias", round(md, 2), "loa", round(1.96 * sd, 2), "r", round(float(np.corrcoef(gt, pr)[0, 1]), 3))


if __name__ == "__main__":
    main()
