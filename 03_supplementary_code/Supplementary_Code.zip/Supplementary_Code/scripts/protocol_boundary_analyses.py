#!/usr/bin/env python3
"""Polar-slice TKV error and CHAOS orientation/intensity factors. CPU-safe."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from scipy.ndimage import zoom

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from train import _build_model, laterality, resize2d  # noqa: E402

POLAR_FRAC = 0.20
MID_FRAC = 0.50


def load_model(ckpt: Path, name: str, device: torch.device):
    model = _build_model(name).to(device)
    ck = torch.load(ckpt, map_location="cpu", weights_only=False)
    model.load_state_dict(ck["model"])
    model.eval()
    return model


@torch.no_grad()
def predict_stack(model, slices: np.ndarray, device, batch: int = 8) -> np.ndarray:
    """slices: (N, H, W) float32 in [0,1]. Returns binary mask at native HxW."""
    n, h, w = slices.shape
    out = []
    for i in range(0, n, batch):
        chunk = slices[i : i + batch]
        x = np.stack([resize2d(s, 256) for s in chunk], 0)[:, None]
        t = torch.from_numpy(x).to(device)
        logit = model(t)[0]
        pr = torch.sigmoid(logit)
        pr = F.interpolate(pr, size=(h, w), mode="bilinear", align_corners=False)
        out.append((pr[:, 0].cpu().numpy() > 0.5).astype(np.uint8))
    return np.concatenate(out, 0)


def slice_axis(img: np.ndarray) -> int:
    return int(np.argmin(img.shape))


def as_slices(vol: np.ndarray, axis: int) -> np.ndarray:
    return np.moveaxis(vol, axis, 0)


def from_slices(sl: np.ndarray, axis: int) -> np.ndarray:
    return np.moveaxis(sl, 0, axis)


def dice_np(a: np.ndarray, b: np.ndarray) -> float:
    inter = float((a & b).sum())
    return (2 * inter + 1e-6) / (float(a.sum()) + float(b.sum()) + 1e-6)


def region_dice(pred_sl: np.ndarray, gt_sl: np.ndarray, sel: np.ndarray) -> float:
    if not np.any(sel):
        return float("nan")
    return dice_np(pred_sl[sel].astype(bool), gt_sl[sel].astype(bool))


def polar_row(pred, gt, spacing, scan_id, meta) -> dict:
    axis = slice_axis(gt)
    gt_sl = as_slices(gt.astype(bool), axis)
    pr_sl = as_slices(pred.astype(bool), axis)
    areas = gt_sl.reshape(gt_sl.shape[0], -1).sum(1).astype(np.float64)
    amax = float(areas.max()) if areas.size else 0.0
    polar = (areas > 0) & (areas < POLAR_FRAC * amax) if amax > 0 else np.zeros(len(areas), dtype=bool)
    mid = areas >= MID_FRAC * amax if amax > 0 else np.zeros(len(areas), dtype=bool)
    vox_ml = float(np.prod(spacing) / 1000.0)
    polar_fp = float(((pr_sl[polar] > 0) & (gt_sl[polar] == 0)).sum()) * vox_ml if np.any(polar) else 0.0
    polar_fn = float(((pr_sl[polar] == 0) & (gt_sl[polar] > 0)).sum()) * vox_ml if np.any(polar) else 0.0
    mid_fp = float(((pr_sl[mid] > 0) & (gt_sl[mid] == 0)).sum()) * vox_ml if np.any(mid) else 0.0
    gm, pm = laterality(gt.astype(np.uint8), spacing), laterality(pred.astype(np.uint8), spacing)
    signed = float(pm["tkv_ml"] - gm["tkv_ml"])
    return {
        "scan_id": scan_id,
        "subject": meta.get("subject", scan_id.rsplit("_", 1)[0]),
        "cohort": meta.get("cohort"),
        "dice": dice_np(pred.astype(bool), gt.astype(bool)),
        "dice_polar": region_dice(pr_sl, gt_sl, polar),
        "dice_mid": region_dice(pr_sl, gt_sl, mid),
        "n_polar": int(polar.sum()),
        "n_mid": int(mid.sum()),
        "tkv_abs_ml": abs(signed),
        "tkv_signed_ml": signed,
        "polar_fp_ml": polar_fp,
        "polar_fn_ml": polar_fn,
        "polar_net_ml": polar_fp - polar_fn,
        "mid_fp_ml": mid_fp,
        "gt_tkv_ml": gm["tkv_ml"],
        "pr_tkv_ml": pm["tkv_ml"],
    }


def hist_match_volume(src: np.ndarray, ref_vals: np.ndarray, ref_cdf: np.ndarray) -> np.ndarray:
    s = src.ravel()
    order = np.argsort(s)
    cdf = np.linspace(0, 1, s.size, endpoint=True)
    matched = np.empty_like(s)
    matched[order] = np.interp(cdf, ref_cdf, ref_vals)
    return matched.reshape(src.shape).astype(np.float32)


def build_ref_cdf(npz_dir: Path, ids: list[str], stride: int = 17) -> tuple[np.ndarray, np.ndarray]:
    samples = []
    for sid in ids:
        with np.load(npz_dir / f"{sid}.npz") as z:
            samples.append(z["image"].ravel()[::stride])
    ref = np.concatenate(samples)
    vals, counts = np.unique(np.round(ref, 5), return_counts=True)
    cdf = np.cumsum(counts).astype(np.float64)
    cdf /= cdf[-1]
    return vals.astype(np.float64), cdf


def coronal_reformat(img: np.ndarray, mask: np.ndarray, spacing: np.ndarray):
    """Slice along a pre-declared in-plane axis; upsample the native thick axis to ~1.5 mm."""
    native = slice_axis(img)
    others = [i for i in range(3) if i != native]
    new_slice = others[0]
    target_inplane = 1.5
    zoom_factors = [spacing[i] / target_inplane if i == native else 1.0 for i in range(3)]
    img_z = zoom(img, zoom_factors, order=1)
    mask_z = zoom(mask.astype(np.float32), zoom_factors, order=0) > 0.5
    sp = spacing.copy()
    sp[native] = target_inplane
    return img_z.astype(np.float32), mask_z.astype(np.uint8), sp, new_slice, native


def summarize_polar(rows: list[dict]) -> dict:
    def mean_finite(key):
        v = [r[key] for r in rows if r[key] is not None and np.isfinite(r[key])]
        return float(np.mean(v)) if v else None

    tkv = np.array([r["tkv_abs_ml"] for r in rows], dtype=float)
    polar_net = np.array([r["polar_net_ml"] for r in rows], dtype=float)
    polar_fp = np.array([r["polar_fp_ml"] for r in rows], dtype=float)
    if tkv.std() > 1e-6 and polar_fp.std() > 1e-6:
        corr = float(np.corrcoef(tkv, polar_fp)[0, 1])
    else:
        corr = None
    return {
        "n": len(rows),
        "dice_mean": mean_finite("dice"),
        "dice_polar_mean": mean_finite("dice_polar"),
        "dice_mid_mean": mean_finite("dice_mid"),
        "tkv_mae_ml": float(np.mean(tkv)),
        "polar_fp_mae_ml": float(np.mean(polar_fp)),
        "polar_net_mae_ml": float(np.mean(np.abs(polar_net))),
        "corr_abs_tkv_polar_fp": corr,
        "polar_frac": POLAR_FRAC,
        "mid_frac": MID_FRAC,
    }


def summarize_chaos(rows: list[dict]) -> dict:
    d = np.array([r["dice"] for r in rows], dtype=float)
    mae = np.array([r["tkv_abs_ml"] for r in rows], dtype=float)
    return {
        "n": len(rows),
        "dice_median": float(np.median(d)),
        "dice_mean": float(np.mean(d)),
        "dice_iqr": [float(np.percentile(d, 25)), float(np.percentile(d, 75))],
        "n_dice_lt_0_05": int((d < 0.05).sum()),
        "tkv_mae_ml": float(np.mean(mae)),
        "tkv_mae_median_ml": float(np.median(mae)),
    }


def run_haste_polar(model, npz_dir, ids, meta, device, batch):
    rows = []
    for sid in ids:
        with np.load(npz_dir / f"{sid}.npz") as z:
            img, gt, sp = z["image"], z["mask"] > 0, z["spacing"]
        axis = slice_axis(img)
        sl = as_slices(img, axis)
        pred_sl = predict_stack(model, sl, device, batch)
        pred = from_slices(pred_sl, axis)
        if pred.shape != gt.shape:
            pred = pred[: gt.shape[0], : gt.shape[1], : gt.shape[2]]
        rows.append(polar_row(pred, gt, sp, sid, meta.get(sid, {})))
        print(
            json.dumps(
                {
                    "scan": sid,
                    "dice": rows[-1]["dice"],
                    "dice_polar": rows[-1]["dice_polar"],
                    "dice_mid": rows[-1]["dice_mid"],
                    "polar_fp_ml": rows[-1]["polar_fp_ml"],
                    "tkv_abs_ml": rows[-1]["tkv_abs_ml"],
                }
            ),
            flush=True,
        )
    return rows


def run_chaos_condition(model, npz_dir, ids, meta, device, batch, condition, ref=None):
    rows = []
    for sid in ids:
        with np.load(npz_dir / f"{sid}.npz") as z:
            img = z["image"].astype(np.float32)
            gt = z["mask"] > 0
            sp = z["spacing"].astype(np.float32)
        axis = slice_axis(img)
        if condition == "hist_match":
            img = hist_match_volume(img, ref[0], ref[1])
        elif condition == "coronal_reformat":
            img, gt, sp, axis, _native = coronal_reformat(img, gt, sp)
        sl = as_slices(img, axis)
        pred_sl = predict_stack(model, sl, device, batch)
        pred = from_slices(pred_sl, axis)
        if pred.shape != gt.shape:
            d = tuple(min(a, b) for a, b in zip(pred.shape, gt.shape))
            pred = pred[: d[0], : d[1], : d[2]]
            gt = gt[: d[0], : d[1], : d[2]]
        gm, pm = laterality(gt.astype(np.uint8), sp), laterality(pred.astype(np.uint8), sp)
        rows.append(
            {
                "scan_id": sid,
                "condition": condition,
                "dice": dice_np(pred.astype(bool), gt.astype(bool)),
                "tkv_abs_ml": abs(pm["tkv_ml"] - gm["tkv_ml"]),
                "pred_over_gt": float(pm["tkv_ml"] / (gm["tkv_ml"] + 1e-6)),
                "abs_laterality_pred": abs(pm["laterality"]),
                "abs_laterality_gt": abs(gm["laterality"]),
            }
        )
        print(json.dumps(rows[-1]), flush=True)
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", type=Path, required=True)
    ap.add_argument("--ckpt", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--model", default="unetpp")
    ap.add_argument("--batch", type=int, default=8)
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--skip-coronal", action="store_true")
    args = ap.parse_args()
    device = torch.device(args.device)
    data = args.data
    split = json.loads((data / "split.json").read_text())
    scans = {r["scan_id"]: r for r in json.loads((data / "scans.json").read_text())}
    chaos_meta = json.loads((data / "chaos_meta.json").read_text())
    model = load_model(args.ckpt, args.model, device)

    haste_ids = split["scans"]["test"]
    polar_rows = run_haste_polar(model, data / "npz", haste_ids, scans, device, args.batch)

    train_ids = split["scans"]["train"]
    ref = build_ref_cdf(data / "npz", train_ids)
    chaos_ids = sorted(p.stem for p in (data / "chaos_npz").glob("*.npz"))
    chaos = {}
    conditions = ("native", "hist_match") if args.skip_coronal else ("native", "hist_match", "coronal_reformat")
    for cond in conditions:
        chaos[cond] = run_chaos_condition(
            model,
            data / "chaos_npz",
            chaos_ids,
            chaos_meta,
            device,
            args.batch,
            cond,
            ref=ref,
        )

    payload = {
        "polar_rule": {
            "polar": f"0 < expert_slice_area < {POLAR_FRAC} * max_area",
            "mid": f"expert_slice_area >= {MID_FRAC} * max_area",
            "coronal_reformat": "slice along first in-plane axis; upsample native thick axis to 1.5 mm",
            "hist_match": "CHAOS volume CDF matched to pooled HASTE training intensities",
        },
        "haste_polar": {"summary": summarize_polar(polar_rows), "rows": polar_rows},
        "chaos_factors": {k: {"summary": summarize_chaos(v), "rows": v} for k, v in chaos.items()},
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(payload, indent=2))
    print(json.dumps({k: payload[k] if k == "polar_rule" else {kk: vv.get("summary") if isinstance(vv, dict) and "summary" in vv else vv for kk, vv in payload[k].items()} for k in payload}, indent=2))


if __name__ == "__main__":
    main()
