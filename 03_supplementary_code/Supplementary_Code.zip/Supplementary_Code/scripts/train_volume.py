#!/usr/bin/env python3
"""Scan-level U-Net++ with optional soft volume loss and polar Dice reweight."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from train import (  # noqa: E402
    _build_model,
    deepsup_loss,
    predict_volumes,
    resize2d,
    set_seed,
    summarize,
)


class ScanSet(Dataset):
    def __init__(self, npz_dir: Path, scan_ids: list[str], augment: bool = False):
        self.npz_dir = npz_dir
        self.scan_ids = list(scan_ids)
        self.augment = augment

    def __len__(self):
        return len(self.scan_ids)

    def __getitem__(self, idx):
        sid = self.scan_ids[idx]
        with np.load(self.npz_dir / f"{sid}.npz") as z:
            img, mask, sp = z["image"].astype(np.float32), z["mask"].astype(np.float32), z["spacing"].astype(np.float32)
        axis = int(np.argmin(img.shape))
        sl = np.moveaxis(img, axis, 0)
        mk = np.moveaxis(mask, axis, 0)
        if self.augment and np.random.rand() < 0.5:
            sl = sl[:, :, ::-1].copy()
            mk = mk[:, :, ::-1].copy()
        xs, ys = [], []
        areas = mk.reshape(mk.shape[0], -1).sum(1)
        amax = float(areas.max()) if areas.size else 1.0
        weights = []
        for i in range(sl.shape[0]):
            xs.append(resize2d(sl[i], 256))
            ys.append(resize2d(mk[i], 256, mask=True))
            a = float(areas[i])
            if amax <= 0 or a <= 0:
                weights.append(0.0)
            else:
                weights.append(float(np.clip(amax / (a + 1e-3), 1.0, 8.0)))
        x = torch.from_numpy(np.stack(xs, 0)[:, None])
        y = torch.from_numpy(np.stack(ys, 0)[:, None])
        w = torch.tensor(weights, dtype=torch.float32)
        vox_ml = float(np.prod(sp) / 1000.0)
        tkv = float((mask > 0).sum()) * vox_ml
        return x, y, w, torch.tensor(vox_ml, dtype=torch.float32), torch.tensor(tkv, dtype=torch.float32), sid


def polar_dice_loss(logits, target, weights):
    prob = torch.sigmoid(logits)
    p = prob.reshape(prob.size(0), -1)
    t = target.reshape(target.size(0), -1)
    inter = (p * t).sum(1)
    dice = (2 * inter + 1e-6) / (p.sum(1) + t.sum(1) + 1e-6)
    w = weights.to(dice.device)
    if float(w.sum()) <= 0:
        return 1.0 - dice.mean()
    w = w / w.sum()
    return 1.0 - (dice * w).sum()


def volume_l1(logits, target):
    """Relative mass error on the resized grid; native vox_ml is not valid after 256 resampling."""
    pred = torch.sigmoid(logits).sum()
    gt = target.sum()
    return (pred - gt).abs() / (gt.abs() + 1.0)


def train_one(name, data, runs, split_path, epochs, device, lam_vol, polar_w, tag):
    split = json.loads(split_path.read_text())
    scans = {r["scan_id"]: r for r in json.loads((data / "scans.json").read_text())}
    npz_dir = data / "npz"
    tr = DataLoader(ScanSet(npz_dir, split["scans"]["train"], True), batch_size=1, shuffle=True, num_workers=0)
    model = _build_model(name).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=2e-4, weight_decay=1e-4)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs)
    outdir = runs / tag
    if outdir.exists():
        hist = outdir / "history.jsonl"
        if hist.exists():
            hist.unlink()
    outdir.mkdir(parents=True, exist_ok=True)
    best, stale, best_state = -1.0, 0, None
    for ep in range(epochs):
        model.train()
        total, n = 0.0, 0
        for x, y, w, vox_ml, tkv, _sid in tr:
            x, y = x[0].to(device), y[0].to(device)
            w = w[0].to(device)
            opt.zero_grad(set_to_none=True)
            outs = model(x)
            loss = deepsup_loss(outs, y)
            if polar_w > 0:
                loss = loss + polar_w * polar_dice_loss(outs[0], y, w)
            if lam_vol > 0:
                loss = loss + lam_vol * volume_l1(outs[0], y)
            loss.backward()
            opt.step()
            total += float(loss.detach())
            n += 1
        sched.step()
        val_rows = predict_volumes(model, npz_dir, split["scans"]["val"], device, scans)
        val = summarize(val_rows)
        improved = val["dice_mean"] > best + 1e-5
        if improved:
            best, stale, best_state = val["dice_mean"], 0, {k: v.cpu() for k, v in model.state_dict().items()}
        else:
            stale += 1
        rec = {"epoch": ep + 1, "loss": total / max(n, 1), "val": val}
        with (outdir / "history.jsonl").open("a") as f:
            f.write(json.dumps(rec) + "\n")
        print(json.dumps(rec), flush=True)
        if stale >= 12:
            break
    if best_state:
        model.load_state_dict(best_state)
    torch.save({"model": model.state_dict(), "name": name, "tag": tag}, outdir / "best.pt")
    test_rows = predict_volumes(model, npz_dir, split["scans"]["test"], device, scans)
    summary = {"model": tag, "val_best_dice": best, "test": summarize(test_rows)}
    (outdir / "summary.json").write_text(json.dumps(summary, indent=2))
    (outdir / "test_rows.json").write_text(json.dumps(test_rows, indent=2))
    print(json.dumps(summary, indent=2), flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", type=Path, required=True)
    ap.add_argument("--runs", type=Path, required=True)
    ap.add_argument("--split", type=Path, default=None)
    ap.add_argument("--epochs", type=int, default=80)
    ap.add_argument("--lam-vol", type=float, default=0.1)
    ap.add_argument("--polar-w", type=float, default=0.0)
    ap.add_argument("--tag", default="unetpp_vol")
    ap.add_argument("--model", default="unetpp")
    ap.add_argument("--cv-dir", type=Path, default=None)
    args = ap.parse_args()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if args.cv_dir:
        fold_files = sorted(p for p in args.cv_dir.glob("fold*.json") if p.stem[4:].isdigit())
        if not fold_files:
            raise SystemExit(f"no fold*.json in {args.cv_dir}")
        for sp in fold_files:
            k = sp.stem.replace("fold", "")
            tag = f"{args.tag}_f{k}"
            print(json.dumps({"event": "fold_start", "fold": k, "tag": tag, "lam_vol": args.lam_vol}), flush=True)
            set_seed(42)
            train_one(args.model, args.data, args.runs, sp, args.epochs, device, args.lam_vol, args.polar_w, tag)
        return
    set_seed(42)
    split_path = args.split or (args.data / "split.json")
    train_one(args.model, args.data, args.runs, split_path, args.epochs, device, args.lam_vol, args.polar_w, args.tag)


if __name__ == "__main__":
    main()
