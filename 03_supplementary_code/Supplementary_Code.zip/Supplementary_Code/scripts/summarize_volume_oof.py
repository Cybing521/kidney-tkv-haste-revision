#!/usr/bin/env python3
"""Pool scan-level volume-loss OOF rows against the existing slice-level U-Net++ OOF."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.stats import wilcoxon


def summarize(rows: list[dict]) -> dict:
    dice = np.array([r["dice"] for r in rows], dtype=float)
    mae = np.array([r["tkv_abs_ml"] for r in rows], dtype=float)
    gt = np.array([r["gt"]["tkv_ml"] for r in rows], dtype=float)
    pr = np.array([r["pr"]["tkv_ml"] for r in rows], dtype=float)
    corr = float(np.corrcoef(gt, pr)[0, 1]) if gt.std() > 1e-6 and pr.std() > 1e-6 else None
    return {
        "n": len(rows),
        "dice_mean": float(dice.mean()),
        "dice_std": float(dice.std(ddof=0)),
        "tkv_mae_ml": float(mae.mean()),
        "tkv_mae_std": float(mae.std(ddof=0)),
        "tkv_corr": corr,
    }


def paired(a: np.ndarray, b: np.ndarray, n_boot: int = 10000, seed: int = 42) -> dict:
    diff = a - b
    rng = np.random.RandomState(seed)
    boots = [float(diff[rng.randint(0, len(diff), len(diff))].mean()) for _ in range(n_boot)]
    stat, p = wilcoxon(a, b, alternative="two-sided", zero_method="wilcox")
    return {
        "mean_diff": float(diff.mean()),
        "ci95": [float(np.percentile(boots, 2.5)), float(np.percentile(boots, 97.5))],
        "wilcoxon_stat": float(stat),
        "p": float(p),
        "n": int(len(diff)),
    }


def load_arm(runs: Path, prefix: str) -> list[dict]:
    rows = []
    for k in range(5):
        path = runs / f"{prefix}_f{k}" / "test_rows.json"
        rows.extend(json.loads(path.read_text()))
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--slice-oof", type=Path, default=None)
    args = ap.parse_args()
    scan = load_arm(args.runs, "unetpp_scan")
    vol = load_arm(args.runs, "unetpp_vol01")
    out = {
        "n_oof_scans": len(scan),
        "scan_level_no_vol": summarize(scan),
        "scan_level_lam0.1": summarize(vol),
        "scan_minus_vol_mae": paired(
            np.array([r["tkv_abs_ml"] for r in scan], dtype=float),
            np.array([r["tkv_abs_ml"] for r in vol], dtype=float),
        ),
    }
    if args.slice_oof and args.slice_oof.exists():
        sl = json.loads(args.slice_oof.read_text())
        out["slice_level_unetpp_oof_mae"] = sl.get("oof", {}).get("unetpp")
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(out, indent=2))
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
